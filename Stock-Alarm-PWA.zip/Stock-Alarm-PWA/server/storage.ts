import { db } from "./db";
import {
  stocks, targets, stockNotes, appSettings, alarmNotifications,
  type Stock, type InsertStock, type Target, type InsertTarget, type StockNote, type InsertStockNote,
  type AppSetting, type AlarmNotification
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Stocks
  getStocks(): Promise<(Stock & { targets: Target[] })[]>;
  getStock(id: number): Promise<(Stock & { targets: Target[], notes: StockNote[] }) | undefined>;
  getStockBySymbol(symbol: string): Promise<Stock | undefined>;
  createStock(stock: InsertStock): Promise<Stock>;
  createManyStocks(stocks: InsertStock[]): Promise<Stock[]>;
  updateStockPrice(id: number, price: number): Promise<void>;
  deleteStock(id: number): Promise<void>;
  getAllStocksSimple(): Promise<Stock[]>;

  // Targets
  createTarget(target: InsertTarget): Promise<Target>;
  deleteTarget(id: number): Promise<void>;
  getActiveTargets(): Promise<(Target & { stock: Stock })[]>;

  // Notes
  createStockNote(note: InsertStockNote): Promise<StockNote>;
  updateStockNoteAnalysis(id: number, analysis: string): Promise<void>;

  // Settings
  getSetting(key: string): Promise<string | null>;
  setSetting(key: string, value: string): Promise<void>;

  // Alarm notifications
  logAlarmNotification(targetId: number, stockId: number, triggeredPrice: number, channel: string): Promise<void>;
  getAlarmHistory(limit?: number): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  async getStocks(): Promise<(Stock & { targets: Target[] })[]> {
    const allStocks = await db.query.stocks.findMany({
      with: {
        targets: true
      },
      orderBy: (stocks, { asc }) => [asc(stocks.symbol)]
    });
    return allStocks;
  }

  async getStock(id: number): Promise<(Stock & { targets: Target[], notes: StockNote[] }) | undefined> {
    const stock = await db.query.stocks.findFirst({
      where: eq(stocks.id, id),
      with: {
        targets: true,
        notes: true
      }
    });
    return stock;
  }

  async getStockBySymbol(symbol: string): Promise<Stock | undefined> {
    const stock = await db.query.stocks.findFirst({
      where: eq(stocks.symbol, symbol)
    });
    return stock;
  }

  async createStock(insertStock: InsertStock): Promise<Stock> {
    const [stock] = await db.insert(stocks).values(insertStock).returning();
    return stock;
  }

  async createManyStocks(insertStocks: InsertStock[]): Promise<Stock[]> {
    if (insertStocks.length === 0) return [];
    const result = await db.insert(stocks).values(insertStocks).returning();
    return result;
  }

  async updateStockPrice(id: number, price: number): Promise<void> {
    await db.update(stocks)
      .set({ currentPrice: price, lastUpdated: new Date() })
      .where(eq(stocks.id, id));
  }

  async deleteStock(id: number): Promise<void> {
    await db.delete(targets).where(eq(targets.stockId, id));
    await db.delete(stockNotes).where(eq(stockNotes.stockId, id));
    await db.delete(stocks).where(eq(stocks.id, id));
  }

  async createTarget(insertTarget: InsertTarget): Promise<Target> {
    const [target] = await db.insert(targets).values(insertTarget).returning();
    return target;
  }

  async deleteTarget(id: number): Promise<void> {
    await db.delete(targets).where(eq(targets.id, id));
  }

  async createStockNote(insertNote: InsertStockNote): Promise<StockNote> {
    const [note] = await db.insert(stockNotes).values(insertNote).returning();
    return note;
  }

  async updateStockNoteAnalysis(id: number, analysis: string): Promise<void> {
    await db.update(stockNotes)
      .set({ aiAnalysis: analysis })
      .where(eq(stockNotes.id, id));
  }

  async getAllStocksSimple(): Promise<Stock[]> {
    return db.query.stocks.findMany({
      orderBy: (stocks, { asc }) => [asc(stocks.symbol)]
    });
  }

  async getActiveTargets(): Promise<(Target & { stock: Stock })[]> {
    const activeTargets = await db.query.targets.findMany({
      where: eq(targets.isActive, true),
      with: {
        stock: true
      }
    });
    return activeTargets as (Target & { stock: Stock })[];
  }

  async getSetting(key: string): Promise<string | null> {
    const setting = await db.query.appSettings.findFirst({
      where: eq(appSettings.key, key)
    });
    return setting?.value ?? null;
  }

  async setSetting(key: string, value: string): Promise<void> {
    const existing = await this.getSetting(key);
    if (existing !== null) {
      await db.update(appSettings)
        .set({ value, updatedAt: new Date() })
        .where(eq(appSettings.key, key));
    } else {
      await db.insert(appSettings).values({ key, value });
    }
  }

  async logAlarmNotification(targetId: number, stockId: number, triggeredPrice: number, channel: string): Promise<void> {
    await db.insert(alarmNotifications).values({
      targetId,
      stockId,
      triggeredPrice,
      channel
    });
  }

  async getAlarmHistory(limit: number = 20): Promise<any[]> {
    const notifications = await db.query.alarmNotifications.findMany({
      orderBy: (n, { desc }) => [desc(n.sentAt)],
      limit,
      with: {
        stock: true,
        target: true
      }
    });
    return notifications;
  }
}

export const storage = new DatabaseStorage();
