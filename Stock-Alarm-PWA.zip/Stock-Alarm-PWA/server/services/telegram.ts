import https from 'https';
import fs from 'fs';
import FormData from 'form-data';

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "5747202724:AAHLfOnWPZE0TAyvFO0vEaJUYyVYYOOodC4";
const DEFAULT_CHAT_IDS = ["860174169"];

interface TelegramSettings {
  botToken: string;
  chatIds: string[];
  enabled: boolean;
}

let settings: TelegramSettings = {
  botToken: BOT_TOKEN,
  chatIds: DEFAULT_CHAT_IDS,
  enabled: true
};

export function updateTelegramSettings(newSettings: Partial<TelegramSettings>) {
  settings = { ...settings, ...newSettings };
}

export function getTelegramSettings(): TelegramSettings {
  return { ...settings };
}

export async function sendTelegramMessage(text: string, chatId?: string): Promise<boolean> {
  if (!settings.enabled || !settings.botToken) {
    console.log("Telegram disabled or no bot token");
    return false;
  }

  const targetChatIds = chatId ? [chatId] : settings.chatIds;
  const results: boolean[] = [];

  for (const id of targetChatIds) {
    try {
      const url = `https://api.telegram.org/bot${settings.botToken}/sendMessage`;
      const body = JSON.stringify({
        chat_id: id,
        text: text,
        parse_mode: 'Markdown'
      });

      const result = await new Promise<boolean>((resolve) => {
        const req = https.request(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body)
          }
        }, (res) => {
          res.on('data', () => {});
          res.on('end', () => {
            resolve(res.statusCode === 200);
          });
        });

        req.on('error', (err) => {
          console.error(`Telegram send error for ${id}:`, err.message);
          resolve(false);
        });

        req.write(body);
        req.end();
      });

      results.push(result);
      await new Promise(r => setTimeout(r, 500));
    } catch (e) {
      console.error(`Failed to send to ${id}:`, e);
      results.push(false);
    }
  }

  return results.some(r => r);
}

export async function sendPriceAlert(
  symbol: string,
  currentPrice: number,
  targetPrice: number,
  note?: string
): Promise<boolean> {
  const direction = currentPrice >= targetPrice ? "📈 YUKARI" : "📉 AŞAĞI";
  const message = `
🚨 *FİYAT ALARMI*

*${symbol}* ${direction} hedefine ulaştı!

📊 *Güncel Fiyat:* ₺${currentPrice.toFixed(2)}
🎯 *Hedef Fiyat:* ₺${targetPrice.toFixed(2)}
${note ? `📝 *Not:* ${note}` : ''}

⏰ ${new Date().toLocaleString('tr-TR')}
`;

  return sendTelegramMessage(message);
}

export async function sendScanResult(
  title: string,
  stocks: { symbol: string; price: number; signal: string }[]
): Promise<boolean> {
  if (stocks.length === 0) return true;

  let message = `🔍 *${title}*\n\n`;
  
  for (const stock of stocks.slice(0, 20)) {
    message += `• *${stock.symbol}* - ₺${stock.price.toFixed(2)} - ${stock.signal}\n`;
  }

  if (stocks.length > 20) {
    message += `\n... ve ${stocks.length - 20} hisse daha`;
  }

  message += `\n\n⏰ ${new Date().toLocaleString('tr-TR')}`;

  return sendTelegramMessage(message);
}

export async function sendTelegramPhoto(
  imagePath: string, 
  caption: string, 
  chatId?: string
): Promise<boolean> {
  if (!settings.enabled || !settings.botToken) {
    console.log("Telegram disabled or no bot token");
    return false;
  }

  if (!fs.existsSync(imagePath)) {
    console.error("Image file not found:", imagePath);
    return false;
  }

  const targetChatIds = chatId ? [chatId] : settings.chatIds;
  const results: boolean[] = [];

  for (const id of targetChatIds) {
    try {
      const form = new FormData();
      form.append('chat_id', id);
      form.append('photo', fs.createReadStream(imagePath));
      form.append('caption', caption);
      form.append('parse_mode', 'Markdown');

      const result = await new Promise<boolean>((resolve) => {
        const req = https.request({
          hostname: 'api.telegram.org',
          path: `/bot${settings.botToken}/sendPhoto`,
          method: 'POST',
          headers: form.getHeaders()
        }, (res) => {
          let data = '';
          res.on('data', (chunk) => { data += chunk; });
          res.on('end', () => {
            if (res.statusCode === 200) {
              resolve(true);
            } else {
              console.error(`Telegram photo send failed for ${id}:`, data);
              resolve(false);
            }
          });
        });

        req.on('error', (err) => {
          console.error(`Telegram photo error for ${id}:`, err.message);
          resolve(false);
        });

        form.pipe(req);
      });

      results.push(result);
      await new Promise(r => setTimeout(r, 1000));
    } catch (e) {
      console.error(`Failed to send photo to ${id}:`, e);
      results.push(false);
    }
  }

  return results.some(r => r);
}

export async function sendActiveAlarms(
  alarms: Array<{
    symbol: string;
    currentPrice: number;
    targetPrice: number;
    percentDiff: number;
    note?: string;
  }>
): Promise<boolean> {
  if (alarms.length === 0) {
    return sendTelegramMessage("📋 *AKTİF ALARMLAR*\n\nŞu anda aktif alarm bulunmuyor.");
  }

  let message = `📋 *AKTİF ALARMLAR* (${alarms.length} adet)\n\n`;
  
  for (const alarm of alarms) {
    const direction = alarm.percentDiff >= 0 ? "📈" : "📉";
    const percentText = alarm.percentDiff >= 0 ? `+${alarm.percentDiff.toFixed(1)}%` : `${alarm.percentDiff.toFixed(1)}%`;
    message += `${direction} *${alarm.symbol}*\n`;
    message += `   Güncel: ₺${alarm.currentPrice.toFixed(2)} → Hedef: ₺${alarm.targetPrice.toFixed(2)}\n`;
    message += `   Fark: ${percentText}${alarm.note ? ` | ${alarm.note}` : ''}\n\n`;
  }

  message += `⏰ ${new Date().toLocaleString('tr-TR')}`;

  return sendTelegramMessage(message);
}

export async function sendBestSignals(
  signals: Array<{
    symbol: string;
    price: number;
    buySignals: number;
    sellSignals: number;
    neutralSignals: number;
    recommendation: string;
  }>
): Promise<boolean> {
  if (signals.length === 0) {
    return sendTelegramMessage("🔍 *EN İYİ SİNYALLER*\n\nSinyal bulunamadı.");
  }

  let message = `🔍 *EN İYİ AL SİNYALLERİ* (Top ${signals.length})\n\n`;
  
  for (let i = 0; i < signals.length; i++) {
    const s = signals[i];
    const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "•";
    message += `${medal} *${s.symbol}* - ₺${s.price.toFixed(2)}\n`;
    message += `   🟢 Al: ${s.buySignals} | ⚪ Nötr: ${s.neutralSignals} | 🔴 Sat: ${s.sellSignals}\n`;
    message += `   📊 Öneri: ${s.recommendation}\n\n`;
  }

  message += `⏰ ${new Date().toLocaleString('tr-TR')}`;

  return sendTelegramMessage(message);
}

export async function sendScanResultWithChart(
  scanType: string,
  symbol: string,
  imagePath: string,
  analysisData: {
    price: number;
    signal: string;
    trend?: string;
    trendStrength?: number;
    supports?: number[];
    resistances?: number[];
    patterns?: string[];
    reasons?: string[];
  }
): Promise<boolean> {
  let caption = `📊 *${scanType}*\n\n`;
  caption += `*${symbol}* - ₺${analysisData.price.toFixed(2)}\n`;
  caption += `📍 Sinyal: *${analysisData.signal}*\n`;
  
  if (analysisData.trend) {
    const trendEmoji = analysisData.trend === 'bullish' ? '📈' : analysisData.trend === 'bearish' ? '📉' : '➡️';
    const trendText = analysisData.trend === 'bullish' ? 'Yükselen' : analysisData.trend === 'bearish' ? 'Düşen' : 'Yatay';
    caption += `${trendEmoji} Trend: ${trendText}`;
    if (analysisData.trendStrength) {
      caption += ` (%${analysisData.trendStrength.toFixed(0)})`;
    }
    caption += '\n';
  }
  
  if (analysisData.supports && analysisData.supports.length > 0) {
    caption += `🟢 Destek: ${analysisData.supports.slice(0, 2).map(s => `₺${s.toFixed(2)}`).join(', ')}\n`;
  }
  
  if (analysisData.resistances && analysisData.resistances.length > 0) {
    caption += `🔴 Direnç: ${analysisData.resistances.slice(0, 2).map(r => `₺${r.toFixed(2)}`).join(', ')}\n`;
  }
  
  if (analysisData.patterns && analysisData.patterns.length > 0) {
    caption += `🕯️ Formasyonlar: ${analysisData.patterns.slice(0, 3).join(', ')}\n`;
  }
  
  if (analysisData.reasons && analysisData.reasons.length > 0) {
    caption += `\n💡 ${analysisData.reasons.slice(0, 3).join('\n💡 ')}\n`;
  }
  
  caption += `\n⏰ ${new Date().toLocaleString('tr-TR')}`;
  
  return sendTelegramPhoto(imagePath, caption);
}
