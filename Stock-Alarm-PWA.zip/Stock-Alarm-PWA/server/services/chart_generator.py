import sys
import json
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import numpy as np

plt.style.use('dark_background')

def generate_stock_chart(symbol, candles, analysis=None, scan_type=None, output_path=None):
    """Generate a stock chart image with technical analysis overlays"""
    
    if not candles or len(candles) < 5:
        return {"error": "Yetersiz veri"}
    
    fig, axes = plt.subplots(2, 1, figsize=(12, 8), gridspec_kw={'height_ratios': [3, 1]})
    fig.patch.set_facecolor('#0a0a0a')
    
    ax_price = axes[0]
    ax_volume = axes[1]
    
    for ax in axes:
        ax.set_facecolor('#0a0a0a')
        ax.tick_params(colors='#666666')
        ax.spines['top'].set_color('#333333')
        ax.spines['bottom'].set_color('#333333')
        ax.spines['left'].set_color('#333333')
        ax.spines['right'].set_color('#333333')
        ax.grid(True, color='#1a1a1a', linestyle='-', linewidth=0.5)
    
    dates = list(range(len(candles)))
    opens = [c['open'] for c in candles]
    highs = [c['high'] for c in candles]
    lows = [c['low'] for c in candles]
    closes = [c['close'] for c in candles]
    volumes = [c.get('volume', 0) for c in candles]
    
    for i in range(len(candles)):
        color = '#10b981' if closes[i] >= opens[i] else '#ef4444'
        ax_price.plot([dates[i], dates[i]], [lows[i], highs[i]], color=color, linewidth=1)
        ax_price.plot([dates[i], dates[i]], [opens[i], closes[i]], color=color, linewidth=4)
    
    if len(closes) >= 20:
        sma20 = []
        for i in range(len(closes)):
            if i >= 19:
                sma20.append(sum(closes[i-19:i+1]) / 20)
            else:
                sma20.append(None)
        valid_dates = [d for d, s in zip(dates, sma20) if s is not None]
        valid_sma = [s for s in sma20 if s is not None]
        if valid_sma:
            ax_price.plot(valid_dates, valid_sma, color='#3b82f6', linewidth=1.5, label='SMA20', alpha=0.8)
    
    if len(closes) >= 50:
        sma50 = []
        for i in range(len(closes)):
            if i >= 49:
                sma50.append(sum(closes[i-49:i+1]) / 50)
            else:
                sma50.append(None)
        valid_dates = [d for d, s in zip(dates, sma50) if s is not None]
        valid_sma = [s for s in sma50 if s is not None]
        if valid_sma:
            ax_price.plot(valid_dates, valid_sma, color='#f59e0b', linewidth=1.5, label='SMA50', alpha=0.8)
    
    if analysis:
        if 'support_resistance' in analysis:
            sr = analysis['support_resistance']
            for level in sr.get('resistance', [])[:2]:
                ax_price.axhline(y=level, color='#ef4444', linestyle='--', linewidth=1, alpha=0.7)
                ax_price.text(len(dates)-1, level, f' R: ₺{level:.2f}', color='#ef4444', fontsize=9, va='center')
            for level in sr.get('support', [])[:2]:
                ax_price.axhline(y=level, color='#10b981', linestyle='--', linewidth=1, alpha=0.7)
                ax_price.text(len(dates)-1, level, f' S: ₺{level:.2f}', color='#10b981', fontsize=9, va='center')
        
        if 'fibonacci' in analysis:
            fib = analysis['fibonacci']
            fib_colors = {'fib_38': '#a855f7', 'fib_50': '#ec4899', 'fib_61': '#f97316'}
            for key, color in fib_colors.items():
                if key in fib and fib[key]:
                    level = fib[key]
                    ax_price.axhline(y=level, color=color, linestyle=':', linewidth=1, alpha=0.5)
        
        if 'order_blocks' in analysis:
            obs = analysis['order_blocks']
            for ob in obs.get('bullish_ob', [])[-2:]:
                ax_price.axhspan(ob['low'], ob['high'], alpha=0.2, color='#10b981')
            for ob in obs.get('bearish_ob', [])[-2:]:
                ax_price.axhspan(ob['low'], ob['high'], alpha=0.2, color='#ef4444')
        
        if 'fair_value_gaps' in analysis:
            fvg = analysis['fair_value_gaps']
            for gap in fvg.get('bullish_fvg', [])[-2:]:
                ax_price.axhspan(gap['bottom'], gap['top'], alpha=0.15, color='#06b6d4')
            for gap in fvg.get('bearish_fvg', [])[-2:]:
                ax_price.axhspan(gap['bottom'], gap['top'], alpha=0.15, color='#f97316')
    
    colors = ['#10b981' if closes[i] >= opens[i] else '#ef4444' for i in range(len(closes))]
    ax_volume.bar(dates, volumes, color=colors, alpha=0.7, width=0.8)
    ax_volume.set_ylabel('Hacim', color='#666666', fontsize=10)
    
    current_price = closes[-1]
    price_change = ((closes[-1] - closes[0]) / closes[0]) * 100 if closes[0] != 0 else 0
    change_color = '#10b981' if price_change >= 0 else '#ef4444'
    change_symbol = '+' if price_change >= 0 else ''
    
    title = f'{symbol}'
    if scan_type:
        title += f' - {scan_type}'
    title += f'\n₺{current_price:.2f} ({change_symbol}{price_change:.1f}%)'
    
    ax_price.set_title(title, color='white', fontsize=14, fontweight='bold', pad=15)
    ax_price.set_ylabel('Fiyat (₺)', color='#666666', fontsize=10)
    
    if analysis and 'signal' in analysis:
        signal = analysis['signal']
        rec = signal.get('recommendation', 'NÖTR')
        rec_color = '#10b981' if 'AL' in rec else '#ef4444' if 'SAT' in rec else '#6b7280'
        ax_price.text(0.02, 0.98, rec, transform=ax_price.transAxes, 
                     fontsize=14, fontweight='bold', color=rec_color,
                     verticalalignment='top', bbox=dict(boxstyle='round', facecolor='#1a1a1a', edgecolor=rec_color))
    
    if analysis and 'trend' in analysis:
        trend = analysis['trend']
        trend_text = f"Trend: {trend.get('trend', 'neutral').capitalize()} ({trend.get('strength', 0):.0f}%)"
        ax_price.text(0.98, 0.02, trend_text, transform=ax_price.transAxes,
                     fontsize=9, color='#9ca3af', ha='right', va='bottom')
    
    ax_price.legend(loc='upper left', fontsize=8, framealpha=0.3)
    
    plt.tight_layout()
    
    if not output_path:
        output_path = f'/tmp/chart_{symbol}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.png'
    
    plt.savefig(output_path, dpi=150, facecolor='#0a0a0a', edgecolor='none', bbox_inches='tight')
    plt.close()
    
    return {"success": True, "path": output_path}

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(json.dumps({"error": "Usage: chart_generator.py <symbol> <candles_json> <output_path> [analysis_json] [scan_type]"}))
        sys.exit(1)
    
    symbol = sys.argv[1]
    candles_json = sys.argv[2]
    output_path = sys.argv[3]
    analysis_json = sys.argv[4] if len(sys.argv) > 4 else None
    scan_type = sys.argv[5] if len(sys.argv) > 5 else None
    
    try:
        candles = json.loads(candles_json)
        analysis = json.loads(analysis_json) if analysis_json else None
        
        result = generate_stock_chart(symbol, candles, analysis, scan_type, output_path)
        print(json.dumps(result))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)
