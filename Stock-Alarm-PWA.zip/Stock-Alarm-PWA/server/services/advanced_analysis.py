import sys
import json
import numpy as np
from scipy import stats
from scipy.signal import argrelextrema

def find_pivot_points(highs, lows, closes, order=5):
    """Find pivot high and low points in the price data"""
    pivot_highs = argrelextrema(np.array(highs), np.greater, order=order)[0]
    pivot_lows = argrelextrema(np.array(lows), np.less, order=order)[0]
    return pivot_highs.tolist(), pivot_lows.tolist()

def calculate_support_resistance(highs, lows, closes, num_levels=3):
    """Calculate support and resistance levels using clustering"""
    if len(highs) < 10:
        return {"support": [], "resistance": []}
    
    pivot_highs_idx, pivot_lows_idx = find_pivot_points(highs, lows, closes)
    
    resistance_levels = [highs[i] for i in pivot_highs_idx] if pivot_highs_idx else []
    support_levels = [lows[i] for i in pivot_lows_idx] if pivot_lows_idx else []
    
    def cluster_levels(levels, tolerance=0.02):
        if not levels:
            return []
        levels = sorted(levels)
        clusters = [[levels[0]]]
        for level in levels[1:]:
            if abs(level - clusters[-1][-1]) / clusters[-1][-1] < tolerance:
                clusters[-1].append(level)
            else:
                clusters.append([level])
        return [round(sum(c) / len(c), 2) for c in sorted(clusters, key=len, reverse=True)]
    
    resistance = cluster_levels(resistance_levels)[:num_levels]
    support = cluster_levels(support_levels)[:num_levels]
    
    return {
        "support": support,
        "resistance": resistance
    }

def calculate_fibonacci_levels(highs, lows, trend="up"):
    """Calculate Fibonacci retracement levels"""
    if len(highs) < 2:
        return {}
    
    swing_high = max(highs)
    swing_low = min(lows)
    diff = swing_high - swing_low
    
    fib_ratios = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0]
    
    if trend == "up":
        levels = {f"fib_{int(r*100)}": round(swing_high - diff * r, 2) for r in fib_ratios}
    else:
        levels = {f"fib_{int(r*100)}": round(swing_low + diff * r, 2) for r in fib_ratios}
    
    levels["swing_high"] = round(swing_high, 2)
    levels["swing_low"] = round(swing_low, 2)
    
    return levels

def detect_trend(closes, period=20):
    """Detect current trend using linear regression"""
    if len(closes) < period:
        return {"trend": "neutral", "strength": 0}
    
    recent_closes = closes[-period:]
    x = np.arange(len(recent_closes))
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, recent_closes)
    
    slope_pct = (slope / np.mean(recent_closes)) * 100
    
    if slope_pct > 0.5:
        trend = "bullish"
    elif slope_pct < -0.5:
        trend = "bearish"
    else:
        trend = "neutral"
    
    strength = min(abs(r_value) * 100, 100)
    
    return {
        "trend": trend,
        "strength": round(strength, 1),
        "slope_pct": round(slope_pct, 3),
        "r_squared": round(r_value ** 2, 3)
    }

def detect_order_blocks(opens, highs, lows, closes, volumes):
    """Detect order blocks (Smart Money Concepts)"""
    if len(closes) < 10:
        return {"bullish_ob": [], "bearish_ob": []}
    
    bullish_obs = []
    bearish_obs = []
    
    avg_volume = np.mean(volumes) if volumes else 0
    
    for i in range(2, len(closes) - 1):
        prev_close = closes[i-1]
        curr_close = closes[i]
        curr_open = opens[i]
        curr_high = highs[i]
        curr_low = lows[i]
        curr_vol = volumes[i] if volumes else 0
        
        is_bullish_candle = curr_close > curr_open
        is_bearish_candle = curr_close < curr_open
        
        body_size = abs(curr_close - curr_open)
        candle_range = curr_high - curr_low
        
        if candle_range == 0:
            continue
            
        body_ratio = body_size / candle_range
        
        if is_bullish_candle and body_ratio > 0.6:
            if curr_vol > avg_volume * 1.2:
                if i >= 2 and closes[i-1] < opens[i-1] and closes[i-2] < opens[i-2]:
                    bullish_obs.append({
                        "index": i - 1,
                        "high": round(highs[i-1], 2),
                        "low": round(lows[i-1], 2),
                        "type": "bullish",
                        "strength": "strong" if curr_vol > avg_volume * 1.5 else "normal"
                    })
        
        elif is_bearish_candle and body_ratio > 0.6:
            if curr_vol > avg_volume * 1.2:
                if i >= 2 and closes[i-1] > opens[i-1] and closes[i-2] > opens[i-2]:
                    bearish_obs.append({
                        "index": i - 1,
                        "high": round(highs[i-1], 2),
                        "low": round(lows[i-1], 2),
                        "type": "bearish",
                        "strength": "strong" if curr_vol > avg_volume * 1.5 else "normal"
                    })
    
    return {
        "bullish_ob": bullish_obs[-3:],
        "bearish_ob": bearish_obs[-3:]
    }

def detect_fair_value_gaps(opens, highs, lows, closes):
    """Detect Fair Value Gaps (FVG) - imbalance zones"""
    if len(closes) < 3:
        return {"bullish_fvg": [], "bearish_fvg": []}
    
    bullish_fvgs = []
    bearish_fvgs = []
    
    for i in range(2, len(closes)):
        prev_high = highs[i-2]
        curr_low = lows[i]
        
        if curr_low > prev_high:
            bullish_fvgs.append({
                "index": i - 1,
                "top": round(curr_low, 2),
                "bottom": round(prev_high, 2),
                "gap_size": round(curr_low - prev_high, 2),
                "type": "bullish"
            })
        
        prev_low = lows[i-2]
        curr_high = highs[i]
        
        if curr_high < prev_low:
            bearish_fvgs.append({
                "index": i - 1,
                "top": round(prev_low, 2),
                "bottom": round(curr_high, 2),
                "gap_size": round(prev_low - curr_high, 2),
                "type": "bearish"
            })
    
    return {
        "bullish_fvg": bullish_fvgs[-5:],
        "bearish_fvg": bearish_fvgs[-5:]
    }

def detect_candlestick_patterns(opens, highs, lows, closes):
    """Detect common candlestick patterns"""
    if len(closes) < 3:
        return {"patterns": []}
    
    patterns = []
    
    for i in range(len(closes) - 1):
        o, h, l, c = opens[i], highs[i], lows[i], closes[i]
        body = abs(c - o)
        upper_wick = h - max(o, c)
        lower_wick = min(o, c) - l
        candle_range = h - l
        
        if candle_range == 0:
            continue
        
        if lower_wick > body * 2 and upper_wick < body * 0.5 and c > o:
            patterns.append({"index": i, "pattern": "hammer", "type": "bullish", "name_tr": "Çekiç"})
        
        if upper_wick > body * 2 and lower_wick < body * 0.5 and c < o:
            patterns.append({"index": i, "pattern": "shooting_star", "type": "bearish", "name_tr": "Kayan Yıldız"})
        
        if body < candle_range * 0.1:
            patterns.append({"index": i, "pattern": "doji", "type": "neutral", "name_tr": "Doji"})
        
        if i >= 1:
            prev_o, prev_h, prev_l, prev_c = opens[i-1], highs[i-1], lows[i-1], closes[i-1]
            
            if prev_c < prev_o and c > o and c > prev_o and o < prev_c:
                patterns.append({"index": i, "pattern": "bullish_engulfing", "type": "bullish", "name_tr": "Boğa Yutma"})
            
            if prev_c > prev_o and c < o and c < prev_o and o > prev_c:
                patterns.append({"index": i, "pattern": "bearish_engulfing", "type": "bearish", "name_tr": "Ayı Yutma"})
    
    return {"patterns": patterns[-10:]}

def calculate_volume_profile(closes, volumes, num_levels=10):
    """Calculate volume profile levels"""
    if len(closes) < 5 or not volumes or sum(volumes) == 0:
        return {"poc": None, "value_area_high": None, "value_area_low": None}
    
    price_min = min(closes)
    price_max = max(closes)
    
    if price_min == price_max:
        return {"poc": round(price_min, 2), "value_area_high": round(price_max, 2), "value_area_low": round(price_min, 2)}
    
    level_size = (price_max - price_min) / num_levels
    volume_by_level = {}
    
    for price, vol in zip(closes, volumes):
        level = int((price - price_min) / level_size)
        level = min(level, num_levels - 1)
        volume_by_level[level] = volume_by_level.get(level, 0) + vol
    
    if not volume_by_level:
        return {"poc": None, "value_area_high": None, "value_area_low": None}
    
    poc_level = max(volume_by_level, key=volume_by_level.get)
    poc_price = price_min + (poc_level + 0.5) * level_size
    
    total_volume = sum(volume_by_level.values())
    target_volume = total_volume * 0.7
    
    sorted_levels = sorted(volume_by_level.items(), key=lambda x: x[1], reverse=True)
    cumulative = 0
    value_area_levels = []
    
    for level, vol in sorted_levels:
        value_area_levels.append(level)
        cumulative += vol
        if cumulative >= target_volume:
            break
    
    if value_area_levels:
        va_low = price_min + min(value_area_levels) * level_size
        va_high = price_min + (max(value_area_levels) + 1) * level_size
    else:
        va_low, va_high = price_min, price_max
    
    return {
        "poc": round(poc_price, 2),
        "value_area_high": round(va_high, 2),
        "value_area_low": round(va_low, 2)
    }

def generate_trading_signal(closes, trend_data, sr_levels, fib_levels, patterns):
    """Generate an overall trading signal based on all analyses"""
    current_price = closes[-1] if closes else 0
    signals = []
    score = 0
    
    if trend_data["trend"] == "bullish":
        score += 2
        signals.append("Yükselen trend")
    elif trend_data["trend"] == "bearish":
        score -= 2
        signals.append("Düşen trend")
    
    if sr_levels["support"]:
        nearest_support = min(sr_levels["support"], key=lambda x: abs(x - current_price))
        if current_price < nearest_support * 1.02:
            score += 1
            signals.append(f"Destek yakını: ₺{nearest_support}")
    
    if sr_levels["resistance"]:
        nearest_resistance = min(sr_levels["resistance"], key=lambda x: abs(x - current_price))
        if current_price > nearest_resistance * 0.98:
            score -= 1
            signals.append(f"Direnç yakını: ₺{nearest_resistance}")
    
    if fib_levels:
        fib_50 = fib_levels.get("fib_50")
        fib_61 = fib_levels.get("fib_61")
        if fib_50 and abs(current_price - fib_50) / current_price < 0.02:
            signals.append("Fib %50 seviyesinde")
        if fib_61 and abs(current_price - fib_61) / current_price < 0.02:
            signals.append("Fib %61.8 seviyesinde (altın oran)")
            score += 1
    
    bullish_patterns = [p for p in patterns.get("patterns", []) if p["type"] == "bullish"]
    bearish_patterns = [p for p in patterns.get("patterns", []) if p["type"] == "bearish"]
    
    if bullish_patterns:
        recent_bullish = [p for p in bullish_patterns if p["index"] >= len(closes) - 5]
        if recent_bullish:
            score += len(recent_bullish)
            signals.append(f"{len(recent_bullish)} boğa formasyonu")
    
    if bearish_patterns:
        recent_bearish = [p for p in bearish_patterns if p["index"] >= len(closes) - 5]
        if recent_bearish:
            score -= len(recent_bearish)
            signals.append(f"{len(recent_bearish)} ayı formasyonu")
    
    if score >= 3:
        recommendation = "GÜÇLÜ AL"
    elif score >= 1:
        recommendation = "AL"
    elif score <= -3:
        recommendation = "GÜÇLÜ SAT"
    elif score <= -1:
        recommendation = "SAT"
    else:
        recommendation = "NÖTR"
    
    return {
        "recommendation": recommendation,
        "score": score,
        "signals": signals
    }

def analyze(candles_json):
    """Main analysis function"""
    try:
        candles = json.loads(candles_json) if isinstance(candles_json, str) else candles_json
        
        if not candles or len(candles) < 5:
            return {"error": "Yetersiz veri", "status": "error"}
        
        opens = [c["open"] for c in candles]
        highs = [c["high"] for c in candles]
        lows = [c["low"] for c in candles]
        closes = [c["close"] for c in candles]
        volumes = [c.get("volume", 0) for c in candles]
        
        sr_levels = calculate_support_resistance(highs, lows, closes)
        trend_data = detect_trend(closes)
        fib_levels = calculate_fibonacci_levels(highs[-50:], lows[-50:], trend_data["trend"][:2] if trend_data["trend"] != "neutral" else "up")
        order_blocks = detect_order_blocks(opens, highs, lows, closes, volumes)
        fvg = detect_fair_value_gaps(opens, highs, lows, closes)
        patterns = detect_candlestick_patterns(opens, highs, lows, closes)
        volume_profile = calculate_volume_profile(closes, volumes)
        signal = generate_trading_signal(closes, trend_data, sr_levels, fib_levels, patterns)
        
        return {
            "status": "success",
            "current_price": round(closes[-1], 2),
            "support_resistance": sr_levels,
            "trend": trend_data,
            "fibonacci": fib_levels,
            "order_blocks": order_blocks,
            "fair_value_gaps": fvg,
            "candlestick_patterns": patterns,
            "volume_profile": volume_profile,
            "signal": signal
        }
        
    except Exception as e:
        return {"error": str(e), "status": "error"}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No candle data provided"}))
        sys.exit(1)
    
    candles_json = sys.argv[1]
    result = analyze(candles_json)
    print(json.dumps(result))
