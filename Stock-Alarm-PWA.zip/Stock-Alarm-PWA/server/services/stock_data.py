import sys
import json
import os
import random
import string
import re
from tradingview_ta import TA_Handler, Interval

# TradingView WebSocket imports
import websocket
import requests

def get_exchange_and_screener(symbol):
    """Parse symbol and return exchange, symbol, and screener"""
    exchange = "BIST"
    t_symbol = symbol
    screener = "turkey"

    if ":" in symbol:
        parts = symbol.split(":")
        exchange = parts[0]
        t_symbol = parts[1]
        if exchange in ["NASDAQ", "NYSE"]:
            screener = "america"
        elif exchange == "BINANCE":
            screener = "crypto"
    
    return exchange, t_symbol, screener

def get_analysis_and_price(symbol):
    """Get technical analysis and current price"""
    try:
        exchange, t_symbol, screener = get_exchange_and_screener(symbol)
        
        handler = TA_Handler(
            symbol=t_symbol,
            screener=screener,
            exchange=exchange,
            interval=Interval.INTERVAL_1_DAY
        )
        analysis = handler.get_analysis()
        
        current_price = analysis.indicators["close"]
        rsi = analysis.indicators.get("RSI")
        macd = analysis.indicators.get("MACD.macd")
        signal = analysis.summary.get("RECOMMENDATION")
        
        return {
            "symbol": symbol,
            "price": round(current_price, 2),
            "recommendation": signal,
            "rsi": round(rsi, 2) if rsi else None,
            "macd": round(macd, 4) if macd else None,
            "status": "success",
            "indicators": {
                "sma20": analysis.indicators.get("SMA20"),
                "sma50": analysis.indicators.get("SMA50"),
                "bb_upper": analysis.indicators.get("BB.upper"),
                "bb_lower": analysis.indicators.get("BB.lower"),
            }
        }
        
    except Exception as e:
        return {"error": str(e), "status": "error"}

def generate_session():
    """Generate a random session string"""
    return ''.join(random.choice(string.ascii_lowercase) for _ in range(12))

def prepend_header(st):
    """Prepend message header for TradingView protocol"""
    return "~m~" + str(len(st)) + "~m~" + st

def construct_message(func, param_list):
    """Construct a TradingView WebSocket message"""
    return json.dumps({"m": func, "p": param_list}, separators=(',', ':'))

def create_message(func, param_list):
    """Create a complete message with header"""
    return prepend_header(construct_message(func, param_list))

def send_message(ws, func, args):
    """Send a message through the WebSocket"""
    ws.send(create_message(func, args))

def get_auth_token():
    """Get TradingView auth token using credentials from environment"""
    username = os.environ.get('TRADINGVIEW_USERNAME', '')
    password = os.environ.get('TRADINGVIEW_PASSWORD', '')
    
    if not username or not password:
        return None
    
    try:
        session = requests.Session()
        
        # Login to TradingView
        login_url = "https://www.tradingview.com/accounts/signin/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Referer": "https://www.tradingview.com/",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        data = {
            "username": username,
            "password": password,
            "remember": "on"
        }
        
        response = session.post(login_url, headers=headers, data=data)
        
        if response.status_code == 200:
            cookies = session.cookies.get_dict()
            if 'sessionid' in cookies:
                # Get auth token from chart-token endpoint
                token_response = session.get(
                    "https://www.tradingview.com/chart-token/",
                    headers=headers
                )
                if token_response.status_code == 200:
                    token_data = token_response.json()
                    return token_data.get('token')
        
        return None
    except Exception as e:
        return None

def get_historical_candles(symbol, bars=100):
    """Get historical OHLCV data from TradingView WebSocket"""
    try:
        exchange, t_symbol, screener = get_exchange_and_screener(symbol)
        full_symbol = f"{exchange}:{t_symbol}"
        
        # Generate sessions
        chart_session = "cs_" + generate_session()
        
        # Connect to TradingView WebSocket
        ws_url = "wss://data.tradingview.com/socket.io/websocket"
        headers = {
            "Origin": "https://www.tradingview.com",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        
        candles = []
        received_data = []
        
        def on_message(ws, message):
            nonlocal received_data
            # Parse messages (may be multiple in one)
            pattern = re.compile(r'~m~\d+~m~')
            parts = pattern.split(message)
            
            for part in parts:
                if not part:
                    continue
                if part.startswith('{"m":'):
                    try:
                        data = json.loads(part)
                        if data.get('m') == 'timescale_update' or data.get('m') == 'du':
                            received_data.append(data)
                    except json.JSONDecodeError:
                        pass
                elif '~h~' in part:
                    # Heartbeat - respond
                    ws.send(message)
        
        def on_open(ws):
            # Set auth token if available
            auth_token = get_auth_token()
            if auth_token:
                send_message(ws, "set_auth_token", [auth_token])
            else:
                send_message(ws, "set_auth_token", ["unauthorized_user_token"])
            
            # Create chart session
            send_message(ws, "chart_create_session", [chart_session, ""])
            
            # Resolve symbol
            send_message(ws, "resolve_symbol", [
                chart_session,
                "sds_sym_1",
                f'={{"symbol":"{full_symbol}","adjustment":"splits","session":"regular"}}'
            ])
            
            # Create series
            send_message(ws, "create_series", [
                chart_session,
                "sds_1",
                "s1",
                "sds_sym_1",
                "1D",
                bars,
                ""
            ])
        
        ws = websocket.WebSocketApp(
            ws_url,
            header=headers,
            on_open=on_open,
            on_message=on_message
        )
        
        # Run with timeout
        import threading
        ws_thread = threading.Thread(target=lambda: ws.run_forever())
        ws_thread.daemon = True
        ws_thread.start()
        
        # Wait for data (max 10 seconds)
        import time
        timeout = 10
        start_time = time.time()
        while time.time() - start_time < timeout:
            if len(received_data) >= 1:
                time.sleep(0.5)  # Wait a bit more for all data
                break
            time.sleep(0.1)
        
        ws.close()
        
        # Process received data
        for data in received_data:
            if data.get('p') and len(data['p']) > 1:
                series_data = data['p'][1]
                if isinstance(series_data, dict):
                    for key, val in series_data.items():
                        if isinstance(val, dict) and 's' in val:
                            bars_data = val['s']
                            for bar in bars_data:
                                if 'v' in bar:
                                    v = bar['v']
                                    if len(v) >= 6:
                                        candles.append({
                                            "time": int(v[0]) * 1000,  # Convert to milliseconds
                                            "open": round(v[1], 2),
                                            "high": round(v[2], 2),
                                            "low": round(v[3], 2),
                                            "close": round(v[4], 2),
                                            "volume": int(v[5])
                                        })
        
        # Sort by time
        candles.sort(key=lambda x: x['time'])
        
        return candles[-bars:] if len(candles) > bars else candles
        
    except Exception as e:
        return []

def get_candles(symbol, bars=100):
    """Get OHLCV candlestick data using TradingView"""
    import time
    max_retries = 3
    retry_delay = 2
    last_error = None
    
    for attempt in range(max_retries):
        try:
            exchange, t_symbol, screener = get_exchange_and_screener(symbol)
            
            if attempt > 0:
                time.sleep(retry_delay * (attempt + 1))
            
            handler = TA_Handler(
                symbol=t_symbol,
                screener=screener,
                exchange=exchange,
                interval=Interval.INTERVAL_1_DAY
            )
            analysis = handler.get_analysis()
            indicators = analysis.indicators
            
            historical_candles = get_historical_candles(symbol, bars)
            
            current_candle = {
                "time": None,
                "open": round(indicators.get("open", 0), 2),
                "high": round(indicators.get("high", 0), 2),
                "low": round(indicators.get("low", 0), 2),
                "close": round(indicators.get("close", 0), 2),
                "volume": int(indicators.get("volume", 0))
            }
            
            tech_data = {
                "sma20": round(indicators.get("SMA20", 0), 2) if indicators.get("SMA20") else None,
                "sma50": round(indicators.get("SMA50", 0), 2) if indicators.get("SMA50") else None,
                "sma200": round(indicators.get("SMA200", 0), 2) if indicators.get("SMA200") else None,
                "ema20": round(indicators.get("EMA20", 0), 2) if indicators.get("EMA20") else None,
                "rsi": round(indicators.get("RSI", 0), 2) if indicators.get("RSI") else None,
                "macd": round(indicators.get("MACD.macd", 0), 4) if indicators.get("MACD.macd") else None,
                "macd_signal": round(indicators.get("MACD.signal", 0), 4) if indicators.get("MACD.signal") else None,
                "bb_upper": round(indicators.get("BB.upper", 0), 2) if indicators.get("BB.upper") else None,
                "bb_lower": round(indicators.get("BB.lower", 0), 2) if indicators.get("BB.lower") else None,
                "bb_middle": round(indicators.get("BB.middle", 0), 2) if indicators.get("BB.middle") else None,
                "atr": round(indicators.get("ATR", 0), 2) if indicators.get("ATR") else None,
                "adx": round(indicators.get("ADX", 0), 2) if indicators.get("ADX") else None,
                "cci": round(indicators.get("CCI20", 0), 2) if indicators.get("CCI20") else None,
                "stoch_k": round(indicators.get("Stoch.K", 0), 2) if indicators.get("Stoch.K") else None,
                "stoch_d": round(indicators.get("Stoch.D", 0), 2) if indicators.get("Stoch.D") else None,
                "recommendation": analysis.summary.get("RECOMMENDATION"),
                "buy_signals": analysis.summary.get("BUY", 0),
                "sell_signals": analysis.summary.get("SELL", 0),
                "neutral_signals": analysis.summary.get("NEUTRAL", 0),
            }
            
            return {
                "symbol": symbol,
                "candles": historical_candles,
                "candle": current_candle,
                "indicators": tech_data,
                "status": "success"
            }
            
        except Exception as e:
            last_error = str(e)
            if "429" in str(e):
                continue
            return {"error": str(e), "status": "error"}
    
    return {"error": last_error or "Max retries exceeded", "status": "error"}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No symbol provided"}))
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "candles" and len(sys.argv) >= 3:
        symbol = sys.argv[2]
        bars = int(sys.argv[3]) if len(sys.argv) > 3 else 100
        result = get_candles(symbol, bars)
    else:
        # Default: get price and analysis
        symbol = command
        result = get_analysis_and_price(symbol)
    
    print(json.dumps(result))
