import type { Express } from "express";
import { createServer, type Server } from "http";
import fs from "fs";
import path from "path";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { fetchStockPrice, fetchStockCandles, runAdvancedAnalysis, generateStockChart } from "./lib/python_bridge";
import { ai } from "./replit_integrations/image/client"; // Reusing the initialized client
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { sendPriceAlert, updateTelegramSettings, getTelegramSettings, sendScanResultWithChart, sendActiveAlarms, sendBestSignals } from "./services/telegram";
import fs from "fs";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Register Integration Routes
  registerChatRoutes(app);
  registerImageRoutes(app);

  // === STOCKS ===
  app.get(api.stocks.list.path, async (req, res) => {
    const stocks = await storage.getStocks();
    res.json(stocks);
  });

  app.post(api.stocks.create.path, async (req, res) => {
    try {
      const input = api.stocks.create.input.parse(req.body);
      
      // Fetch initial price
      let initialPrice = 0;
      try {
        initialPrice = await fetchStockPrice(input.symbol);
      } catch (e) {
        console.warn(`Could not fetch initial price for ${input.symbol}:`, e);
      }

      const stock = await storage.createStock({
        symbol: input.symbol,
        name: input.name || input.symbol,
        currentPrice: initialPrice
      });
      res.status(201).json(stock);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.stocks.get.path, async (req, res) => {
    const stock = await storage.getStock(Number(req.params.id));
    if (!stock) {
      return res.status(404).json({ message: 'Stock not found' });
    }
    res.json(stock);
  });

  app.delete(api.stocks.delete.path, async (req, res) => {
    try {
        await storage.deleteStock(Number(req.params.id));
        res.status(204).send();
    } catch (e) {
        res.status(404).json({ message: "Stock not found" });
    }
  });

  app.post(api.stocks.refresh.path, async (req, res) => {
    const stock = await storage.getStock(Number(req.params.id));
    if (!stock) {
      return res.status(404).json({ message: 'Stock not found' });
    }

    try {
      const price = await fetchStockPrice(stock.symbol);
      await storage.updateStockPrice(stock.id, price);
      res.json({ price });
    } catch (e) {
      res.status(500).json({ message: "Failed to fetch price from Python service" });
    }
  });

  // Fetch candle data and technical indicators for a stock
  app.get("/api/stocks/:id/candles", async (req, res) => {
    const stock = await storage.getStock(Number(req.params.id));
    if (!stock) {
      return res.status(404).json({ message: 'Stock not found' });
    }

    try {
      const data = await fetchStockCandles(stock.symbol);
      res.json(data);
    } catch (e) {
      console.error("Candle fetch error:", e);
      res.status(500).json({ message: "Failed to fetch candle data from TradingView" });
    }
  });

  // Advanced technical analysis for a stock
  app.get("/api/stocks/:id/advanced-analysis", async (req, res) => {
    const stock = await storage.getStock(Number(req.params.id));
    if (!stock) {
      return res.status(404).json({ message: 'Stock not found' });
    }

    try {
      const candleData = await fetchStockCandles(stock.symbol);
      if (!candleData.candles || candleData.candles.length < 10) {
        return res.status(400).json({ message: "Yetersiz mum verisi" });
      }
      
      const analysis = await runAdvancedAnalysis(candleData.candles);
      res.json({
        symbol: stock.symbol,
        ...analysis,
        basicIndicators: candleData.indicators
      });
    } catch (e) {
      console.error("Advanced analysis error:", e);
      res.status(500).json({ message: "Gelişmiş analiz yapılamadı" });
    }
  });

  // Batch advanced analysis for scanner
  app.post("/api/scanner/advanced", async (req, res) => {
    const { symbols } = req.body;
    
    if (!Array.isArray(symbols) || symbols.length === 0) {
      return res.status(400).json({ message: "Symbols array required" });
    }

    const allStocks = await storage.getStocks();
    const stockMap = new Map(allStocks.map(s => [s.symbol, s]));
    const results: any[] = [];
    
    for (const symbol of symbols.slice(0, 10)) {
      try {
        const stock = stockMap.get(symbol);
        if (!stock) continue;

        const candleData = await fetchStockCandles(stock.symbol);
        if (!candleData.candles || candleData.candles.length < 10) continue;
        
        const analysis = await runAdvancedAnalysis(candleData.candles);
        results.push({
          symbol: stock.symbol,
          name: stock.name,
          currentPrice: stock.currentPrice,
          ...analysis,
          basicIndicators: candleData.indicators
        });
      } catch (e) {
        console.error(`Analysis failed for ${symbol}:`, e);
      }
    }

    res.json(results);
  });

  // Send scan results with charts to Telegram
  app.post("/api/scanner/send-telegram", async (req, res) => {
    const { scanType, symbols } = req.body;
    
    if (!Array.isArray(symbols) || symbols.length === 0) {
      return res.status(400).json({ message: "Symbols array required" });
    }

    const scanTypeNames: Record<string, string> = {
      "volume_surge": "Hacim Patlaması",
      "green_candles": "3 Yeşil Mum",
      "rsi_oversold": "RSI Aşırı Satım",
      "macd_cross": "MACD Kesişimi",
      "support_resistance": "Destek/Direnç Analizi",
      "fibonacci": "Fibonacci Seviyeleri",
      "order_blocks": "Order Block Analizi",
      "fvg": "Fair Value Gap",
      "volume_profile": "Hacim Profili",
      "patterns": "Mum Formasyonları",
      "trend": "Trend Analizi",
      "advanced": "Gelişmiş Teknik Analiz"
    };

    const scanTypeName = scanTypeNames[scanType] || scanType || "Tarama Sonucu";
    const allStocks = await storage.getStocks();
    const stockMap = new Map(allStocks.map(s => [s.symbol, s]));
    let sentCount = 0;

    for (const symbol of symbols.slice(0, 5)) {
      try {
        const stock = stockMap.get(symbol);
        if (!stock) continue;

        const candleData = await fetchStockCandles(stock.symbol);
        if (!candleData.candles || candleData.candles.length < 10) continue;
        
        const analysis = await runAdvancedAnalysis(candleData.candles);
        
        const chartPath = await generateStockChart(
          stock.symbol, 
          candleData.candles, 
          analysis, 
          scanTypeName
        );
        
        const patterns = analysis.candlestick_patterns?.patterns?.map(p => p.name_tr) || [];
        
        await sendScanResultWithChart(scanTypeName, stock.symbol, chartPath, {
          price: analysis.current_price || stock.currentPrice || 0,
          signal: analysis.signal?.recommendation || "NÖTR",
          trend: analysis.trend?.trend,
          trendStrength: analysis.trend?.strength,
          supports: analysis.support_resistance?.support,
          resistances: analysis.support_resistance?.resistance,
          patterns: patterns,
          reasons: analysis.signal?.signals
        });
        
        if (fs.existsSync(chartPath)) {
          fs.unlinkSync(chartPath);
        }
        
        sentCount++;
        await new Promise(r => setTimeout(r, 2000));
      } catch (e) {
        console.error(`Failed to send chart for ${symbol}:`, e);
      }
    }

    res.json({ success: true, sentCount });
  });

  // Batch refresh all stock prices
  app.post("/api/stocks/batch-refresh", async (req, res) => {
    const allStocks = await storage.getAllStocksSimple();
    const results: { symbol: string; price: number; error?: string }[] = [];
    const activeTargets = await storage.getActiveTargets();
    
    // Process in batches to avoid rate limits
    const batchSize = 5;
    const delayBetweenBatches = 3000; // 3 seconds between batches
    
    for (let i = 0; i < allStocks.length; i += batchSize) {
      const batch = allStocks.slice(i, i + batchSize);
      
      await Promise.all(batch.map(async (stock) => {
        try {
          const price = await fetchStockPrice(stock.symbol);
          await storage.updateStockPrice(stock.id, price);
          results.push({ symbol: stock.symbol, price });
          
          // Check if any targets are triggered
          const stockTargets = activeTargets.filter(t => t.stockId === stock.id);
          for (const target of stockTargets) {
            const triggered = (stock.currentPrice ?? 0) < target.targetPrice && price >= target.targetPrice ||
                             (stock.currentPrice ?? 0) > target.targetPrice && price <= target.targetPrice;
            if (triggered) {
              await sendPriceAlert(stock.symbol, price, target.targetPrice, target.note ?? undefined);
              await storage.logAlarmNotification(target.id, stock.id, price, "telegram");
            }
          }
        } catch (e) {
          results.push({ symbol: stock.symbol, price: 0, error: "fetch_failed" });
        }
      }));
      
      // Delay between batches if not the last batch
      if (i + batchSize < allStocks.length) {
        await new Promise(r => setTimeout(r, delayBetweenBatches));
      }
    }
    
    res.json({ 
      total: allStocks.length, 
      updated: results.filter(r => !r.error).length,
      failed: results.filter(r => r.error).length,
      results 
    });
  });

  // === TELEGRAM SETTINGS ===
  app.get("/api/settings/telegram", async (req, res) => {
    const settings = getTelegramSettings();
    res.json({
      enabled: settings.enabled,
      chatIds: settings.chatIds
    });
  });

  app.post("/api/settings/telegram", async (req, res) => {
    const { chatIds, enabled } = req.body;
    updateTelegramSettings({ 
      chatIds: chatIds ?? undefined, 
      enabled: enabled ?? undefined 
    });
    res.json({ success: true });
  });

  app.post("/api/settings/telegram/test", async (req, res) => {
    try {
      const success = await sendPriceAlert("TEST", 100, 95, "Bu bir test bildirimidir");
      res.json({ success });
    } catch (e) {
      res.status(500).json({ success: false, error: "Failed to send test message" });
    }
  });

  // Auto-refresh settings (in-memory for now)
  let autoRefreshSettings = { enabled: false, intervalMinutes: 30 };
  let autoRefreshTimer: NodeJS.Timeout | null = null;

  app.post("/api/settings/auto-refresh", async (req, res) => {
    const { enabled, intervalMinutes } = req.body;
    autoRefreshSettings = { enabled, intervalMinutes };
    
    if (autoRefreshTimer) {
      clearInterval(autoRefreshTimer);
      autoRefreshTimer = null;
    }
    
    if (enabled && intervalMinutes > 0) {
      console.log(`Auto-refresh enabled: every ${intervalMinutes} minutes`);
    }
    
    res.json({ success: true, settings: autoRefreshSettings });
  });

  // Periodic Telegram settings
  let periodicTelegramSettings = { enabled: false, intervalHours: 4, scanType: "best_signals" };
  let periodicTelegramTimer: NodeJS.Timeout | null = null;

  app.post("/api/settings/periodic-telegram", async (req, res) => {
    const { enabled, intervalHours, scanType } = req.body;
    periodicTelegramSettings = { enabled, intervalHours, scanType };
    
    if (periodicTelegramTimer) {
      clearInterval(periodicTelegramTimer);
      periodicTelegramTimer = null;
    }
    
    if (enabled && intervalHours > 0) {
      console.log(`Periodic Telegram enabled: every ${intervalHours} hours, scan type: ${scanType}`);
    }
    
    res.json({ success: true, settings: periodicTelegramSettings });
  });

  // Alarm history
  app.get("/api/alarm-history", async (req, res) => {
    try {
      const history = await storage.getAlarmHistory(20);
      res.json(history);
    } catch (e) {
      res.json([]);
    }
  });

  // Send active alarms to Telegram
  app.post("/api/telegram/send-alarms", async (req, res) => {
    try {
      const allStocks = await storage.getAllStocks();
      const alarms: Array<{
        symbol: string;
        currentPrice: number;
        targetPrice: number;
        percentDiff: number;
        note?: string;
      }> = [];

      for (const stock of allStocks) {
        if (stock.targets && stock.targets.length > 0 && stock.currentPrice > 0) {
          for (const target of stock.targets) {
            const percentDiff = ((Number(target.targetPrice) - stock.currentPrice) / stock.currentPrice) * 100;
            alarms.push({
              symbol: stock.symbol,
              currentPrice: stock.currentPrice,
              targetPrice: Number(target.targetPrice),
              percentDiff,
              note: target.note || undefined
            });
          }
        }
      }

      const success = await sendActiveAlarms(alarms);
      res.json({ success, count: alarms.length });
    } catch (e) {
      res.status(500).json({ success: false, error: "Failed to send alarms" });
    }
  });

  // Best signals scanner - scan for highest buy signals
  app.post("/api/scanner/best-signals", async (req, res) => {
    const { limit = 20 } = req.body;
    const allStocks = await storage.getAllStocksSimple();
    const signalResults: Array<{
      symbol: string;
      price: number;
      buySignals: number;
      sellSignals: number;
      neutralSignals: number;
      recommendation: string;
    }> = [];

    // Process ALL stocks in batches
    const batchSize = 10;
    for (let i = 0; i < allStocks.length; i += batchSize) {
      const batch = allStocks.slice(i, i + batchSize);
      
      await Promise.all(batch.map(async (stock) => {
        try {
          const candleData = await fetchStockCandles(stock.symbol);
          if (candleData && candleData.indicators) {
            signalResults.push({
              symbol: stock.symbol,
              price: candleData.candle?.close || stock.currentPrice || 0,
              buySignals: candleData.indicators.buy_signals || 0,
              sellSignals: candleData.indicators.sell_signals || 0,
              neutralSignals: candleData.indicators.neutral_signals || 0,
              recommendation: candleData.indicators.recommendation || "NÖTR"
            });
          }
        } catch (e) {
          // Skip this stock
        }
      }));

      if (i + batchSize < allStocks.length) {
        await new Promise(r => setTimeout(r, 500));
      }
    }

    // Sort by buy signals (highest first)
    signalResults.sort((a, b) => b.buySignals - a.buySignals);

    const scanTime = new Date().toISOString();
    res.json({
      results: signalResults.slice(0, limit),
      scannedCount: signalResults.length,
      totalStocks: allStocks.length,
      scanTime
    });
  });

  // Send best signals to Telegram
  app.post("/api/telegram/send-best-signals", async (req, res) => {
    const { limit = 10 } = req.body;
    
    try {
      // Fetch best signals from ALL stocks
      const allStocks = await storage.getAllStocksSimple();
      const signalResults: Array<{
        symbol: string;
        price: number;
        buySignals: number;
        sellSignals: number;
        neutralSignals: number;
        recommendation: string;
      }> = [];

      console.log(`Telegram sinyal taraması başlıyor: ${allStocks.length} hisse`);

      const batchSize = 10;
      for (let i = 0; i < allStocks.length; i += batchSize) {
        const batch = allStocks.slice(i, i + batchSize);
        
        await Promise.all(batch.map(async (stock) => {
          try {
            const candleData = await fetchStockCandles(stock.symbol);
            if (candleData && candleData.indicators) {
              signalResults.push({
                symbol: stock.symbol,
                price: candleData.candle?.close || stock.currentPrice || 0,
                buySignals: candleData.indicators.buy_signals || 0,
                sellSignals: candleData.indicators.sell_signals || 0,
                neutralSignals: candleData.indicators.neutral_signals || 0,
                recommendation: candleData.indicators.recommendation || "NÖTR"
              });
            }
          } catch (e) {
            // Skip
          }
        }));

        if (i + batchSize < allStocks.length) {
          await new Promise(r => setTimeout(r, 500));
        }
      }

      console.log(`Tarama tamamlandı: ${signalResults.length} sinyal bulundu`);

      signalResults.sort((a, b) => b.buySignals - a.buySignals);
      const topSignals = signalResults.slice(0, limit);
      
      console.log(`Telegram'a gönderilecek: ${topSignals.length} sinyal`);
      
      const success = await sendBestSignals(topSignals);
      res.json({ success, count: topSignals.length, scannedCount: signalResults.length });
    } catch (e) {
      console.error("Telegram sinyal hatası:", e);
      res.status(500).json({ success: false, error: "Failed to send signals" });
    }
  });

  // === SCANNER ===
  app.post("/api/scanner/:scanType", async (req, res) => {
    const scanType = req.params.scanType;
    const allStocks = await storage.getAllStocksSimple();
    const results: any[] = [];
    let scannedCount = 0;
    
    // Process in batches - scan all stocks
    const batchSize = 10;
    const delayBetweenBatches = 2000;
    
    for (let i = 0; i < allStocks.length; i += batchSize) {
      const batch = allStocks.slice(i, i + batchSize);
      
      await Promise.all(batch.map(async (stock) => {
        try {
          const candleData = await fetchStockCandles(stock.symbol);
          scannedCount++;
          
          if (!candleData || !candleData.candles || candleData.candles.length < 20) return;
          
          const candles = candleData.candles;
          const lastCandle = candles[candles.length - 1];
          const indicators = candleData.indicators;
          
          let matched = false;
          const reasons: string[] = [];
          let signal: "AL" | "SAT" | "NÖTR" = "NÖTR";
          
          switch (scanType) {
            case "volume_surge": {
              // MA20 Volume > MA100 Volume pattern
              if (candles.length >= 100) {
                const volumes = candles.map(c => c.volume);
                const ma20Volume = volumes.slice(-20).reduce((s, v) => s + v, 0) / 20;
                const ma100Volume = volumes.slice(-100).reduce((s, v) => s + v, 0) / 100;
                
                if (ma20Volume > ma100Volume) {
                  matched = true;
                  signal = "AL";
                  reasons.push("20 günlük hacim > 100 günlük hacim");
                  reasons.push(`MA20: ${(ma20Volume / 1e6).toFixed(1)}M`);
                  reasons.push(`MA100: ${(ma100Volume / 1e6).toFixed(1)}M`);
                }
              } else if (candles.length >= 20) {
                // Fallback for stocks with less history
                const volumes = candles.map(c => c.volume);
                const ma20Volume = volumes.slice(-20).reduce((s, v) => s + v, 0) / 20;
                const currentVolume = volumes[volumes.length - 1];
                
                if (currentVolume > ma20Volume * 1.5) {
                  matched = true;
                  signal = "AL";
                  reasons.push("Güncel hacim > Ortalama hacim x1.5");
                  reasons.push(`Hacim: ${(currentVolume / 1e6).toFixed(1)}M`);
                }
              }
              break;
            }
            
            case "green_candles": {
              // 3 consecutive green candles with increasing volume
              if (candles.length >= 3) {
                const last3 = candles.slice(-3);
                const allGreen = last3.every(c => c.close > c.open);
                const increasingPrice = last3[2].close > last3[1].close && last3[1].close > last3[0].close;
                const increasingVolume = last3[2].volume > last3[1].volume && last3[1].volume > last3[0].volume;
                
                if (allGreen && increasingPrice) {
                  matched = true;
                  signal = "AL";
                  reasons.push("3 ardışık yeşil mum");
                  reasons.push("Artan kapanış fiyatları");
                  if (increasingVolume) {
                    reasons.push("Artan hacim");
                  }
                }
              }
              break;
            }
            
            case "rsi_oversold": {
              const rsi = indicators?.RSI;
              if (rsi !== undefined && rsi !== null && rsi < 30) {
                matched = true;
                signal = "AL";
                reasons.push(`RSI aşırı satım: ${rsi.toFixed(1)}`);
              } else if (rsi === undefined || rsi === null) {
                // RSI not available - skip silently
              }
              break;
            }
            
            case "macd_cross": {
              const macd = indicators?.MACD;
              const macdSignal = indicators?.MACD_Signal;
              if (macd !== undefined && macdSignal !== undefined && macd !== null && macdSignal !== null) {
                if (macd > macdSignal) {
                  matched = true;
                  signal = "AL";
                  reasons.push("MACD sinyal çizgisinin üzerinde");
                  reasons.push(`MACD: ${macd.toFixed(3)}`);
                  reasons.push(`Sinyal: ${macdSignal.toFixed(3)}`);
                }
              }
              break;
            }
          }
          
          if (matched) {
            results.push({
              stockId: stock.id,
              symbol: stock.symbol,
              name: stock.name,
              currentPrice: lastCandle.close,
              signal,
              reasons,
              rsi: indicators?.RSI ?? undefined,
              volumeChange: candles.length > 1 
                ? ((candles[candles.length - 1].volume / candles[candles.length - 2].volume) - 1) * 100 
                : undefined
            });
          }
        } catch (e) {
          // Skip stocks that fail to fetch
        }
      }));
      
      if (i + batchSize < allStocks.length) {
        await new Promise(r => setTimeout(r, delayBetweenBatches));
      }
    }
    
    const scanTime = new Date().toISOString();
    res.json({
      results,
      scannedCount,
      matchCount: results.length,
      scanType,
      scanTime,
      totalStocks: allStocks.length
    });
  });

  // === TARGETS ===
  app.post(api.targets.create.path, async (req, res) => {
    try {
      const input = api.targets.create.input.parse(req.body);
      const target = await storage.createTarget({
        ...input,
        stockId: Number(req.params.stockId)
      });
      res.status(201).json(target);
    } catch (err) {
        if (err instanceof z.ZodError) {
            return res.status(400).json({
              message: err.errors[0].message,
              field: err.errors[0].path.join('.'),
            });
          }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.delete(api.targets.delete.path, async (req, res) => {
    await storage.deleteTarget(Number(req.params.id));
    res.status(204).send();
  });

  // === NOTES & AI ===
  app.post(api.notes.create.path, async (req, res) => {
    try {
      const input = api.notes.create.input.parse(req.body);
      const note = await storage.createStockNote({
        ...input,
        stockId: Number(req.params.stockId)
      });
      res.status(201).json(note);
    } catch (err) {
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.post(api.notes.analyze.path, async (req, res) => {
    const stockId = Number(req.params.stockId);
    const stock = await storage.getStock(stockId);
    if (!stock) return res.status(404).json({ message: "Stock not found" });

    // Fetch technical indicators from TradingView
    let technicalContext = "";
    try {
      const candleData = await fetchStockCandles(stock.symbol);
      if (candleData && candleData.indicators) {
        const ind = candleData.indicators;
        technicalContext = `
          Teknik Göstergeler (TradingView):
          - TradingView Sinyal: ${ind.recommendation}
          - Al Sinyali: ${ind.buy_signals}, Sat Sinyali: ${ind.sell_signals}, Nötr: ${ind.neutral_signals}
          - RSI(14): ${ind.rsi}
          - MACD: ${ind.macd}
          - SMA20: ${ind.sma20}, SMA50: ${ind.sma50}, SMA200: ${ind.sma200}
          - EMA20: ${ind.ema20}
          - Bollinger Bands: Alt=${ind.bb_lower}, Orta=${ind.bb_middle}, Üst=${ind.bb_upper}
          - ATR: ${ind.atr}
          - ADX: ${ind.adx}
          - CCI: ${ind.cci}
          - Stochastic K/D: ${ind.stoch_k}/${ind.stoch_d}
          
          Son Mum (OHLCV):
          - Açılış: ${candleData.candle.open}
          - Yüksek: ${candleData.candle.high}
          - Düşük: ${candleData.candle.low}
          - Kapanış: ${candleData.candle.close}
          - Hacim: ${candleData.candle.volume}
        `;
      }
    } catch (e) {
      console.log("Could not fetch technical data for analysis");
    }

    // Prepare context for Gemini
    const context = `
      Hisse: ${stock.symbol} (${stock.name})
      Güncel Fiyat: ₺${stock.currentPrice}
      Kullanıcı Alarmları: ${stock.targets.map(t => `₺${t.targetPrice} (${t.note})`).join(", ") || "Yok"}
      Kullanıcı Notları: ${stock.notes.map(n => n.content).join("\n") || "Yok"}
      ${technicalContext}
    `;

    try {
      const prompt = `
        Sen profesyonel bir borsa analistisin. Aşağıdaki BIST hissesi verilerini analiz et ve Türkçe olarak kısa bir yatırım özeti sun.
        
        Analizinde şunları değerlendir:
        1. TradingView teknik göstergeleri ne gösteriyor?
        2. RSI, MACD, SMA'lara göre trendin yönü ne?
        3. Kullanıcının belirlediği alarmlar gerçekçi mi?
        4. Kısa ve orta vadeli görünüm nasıl?
        5. Al/Sat/Bekle önerisi ver.
        
        Kısa ve öz ol, maksimum 3-4 paragraf.
        
        Veri:
        ${context}
      `;

      // Use the new GoogleGenAI SDK syntax
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      });
      
      const analysis = response.text() || "Analiz oluşturulamadı.";
      
      res.json({ analysis });
    } catch (e) {
      console.error("Gemini Error:", e);
      res.status(500).json({ message: "AI analizi başarısız oldu" });
    }
  });

  await seedDatabase();

  return httpServer;
}

// Load all BIST stocks from JSON file
function loadBistStocks(): string[] {
  const filePath = path.join(process.cwd(), "server", "data", "bist_stocks.json");
  const data = fs.readFileSync(filePath, "utf-8");
  return JSON.parse(data);
}

async function seedDatabase() {
  const existingStocks = await storage.getStocks();
  if (existingStocks.length === 0) {
    console.log("Seeding database with all BIST stocks...");
    
    const symbols = loadBistStocks();
    const stocksToAdd: { symbol: string; name: string; currentPrice: number }[] = [];
    
    // Add all stocks without fetching prices (too slow for 344 stocks)
    // Users can refresh prices on demand
    for (const symbol of symbols) {
      stocksToAdd.push({ symbol, name: symbol, currentPrice: 0 });
    }
    
    if (stocksToAdd.length > 0) {
      await storage.createManyStocks(stocksToAdd);
    }
    
    console.log(`Seeding complete. Added ${stocksToAdd.length} BIST stocks.`);
  }
}
