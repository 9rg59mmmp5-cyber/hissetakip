import { spawn } from "child_process";
import path from "path";

function normalizeSymbol(symbol: string): string {
  // For BIST stocks, add BIST: prefix if not present
  if (!symbol.includes(":") && !symbol.includes("-")) {
    return "BIST:" + symbol;
  }
  return symbol;
}

export interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  time?: number;
}

export interface CandleData {
  candle: {
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  };
  candles?: Candle[];
  indicators: {
    sma20: number | null;
    sma50: number | null;
    sma200: number | null;
    ema20: number | null;
    rsi: number | null;
    macd: number | null;
    macd_signal: number | null;
    bb_upper: number | null;
    bb_lower: number | null;
    bb_middle: number | null;
    atr: number | null;
    adx: number | null;
    cci: number | null;
    stoch_k: number | null;
    stoch_d: number | null;
    recommendation: string;
    buy_signals: number;
    sell_signals: number;
    neutral_signals: number;
  };
}

export async function fetchStockPrice(symbol: string): Promise<number> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(process.cwd(), "server", "services", "stock_data.py");
    const normalizedSymbol = normalizeSymbol(symbol);
    
    const pythonProcess = spawn("python3", [scriptPath, normalizedSymbol]);

    let dataString = "";
    let errorString = "";

    pythonProcess.stdout.on("data", (data) => {
      dataString += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      errorString += data.toString();
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error(`Python script exited with code ${code}`);
        console.error(`Error: ${errorString}`);
        reject(new Error(`Failed to fetch stock data for ${symbol}`));
        return;
      }

      try {
        // Parse the last line as it should contain the JSON
        const lines = dataString.trim().split("\n");
        const lastLine = lines[lines.length - 1];
        const result = JSON.parse(lastLine);
        
        if (result.error) {
          reject(new Error(result.error));
        } else {
          // Supports both simple price and full technical object
          resolve(result.price);
        }
      } catch (err) {
        console.error("Failed to parse Python output:", dataString);
        reject(new Error("Invalid output from Python script"));
      }
    });
  });
}

export async function fetchStockCandles(symbol: string): Promise<CandleData> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(process.cwd(), "server", "services", "stock_data.py");
    const normalizedSymbol = normalizeSymbol(symbol);
    
    const pythonProcess = spawn("python3", [scriptPath, "candles", normalizedSymbol]);

    let dataString = "";
    let errorString = "";

    pythonProcess.stdout.on("data", (data) => {
      dataString += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      errorString += data.toString();
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error(`Python script exited with code ${code}`);
        console.error(`Error: ${errorString}`);
        reject(new Error(`Failed to fetch candle data for ${symbol}`));
        return;
      }

      try {
        const lines = dataString.trim().split("\n");
        const lastLine = lines[lines.length - 1];
        const result = JSON.parse(lastLine);
        
        if (result.error) {
          reject(new Error(result.error));
        } else {
          resolve(result as CandleData);
        }
      } catch (err) {
        console.error("Failed to parse Python output:", dataString);
        reject(new Error("Invalid output from Python script"));
      }
    });
  });
}

export interface AdvancedAnalysis {
  status: string;
  current_price: number;
  support_resistance: {
    support: number[];
    resistance: number[];
  };
  trend: {
    trend: string;
    strength: number;
    slope_pct: number;
    r_squared: number;
  };
  fibonacci: {
    swing_high: number;
    swing_low: number;
    fib_0: number;
    fib_23: number;
    fib_38: number;
    fib_50: number;
    fib_61: number;
    fib_78: number;
    fib_100: number;
  };
  order_blocks: {
    bullish_ob: Array<{ index: number; high: number; low: number; type: string; strength: string }>;
    bearish_ob: Array<{ index: number; high: number; low: number; type: string; strength: string }>;
  };
  fair_value_gaps: {
    bullish_fvg: Array<{ index: number; top: number; bottom: number; gap_size: number; type: string }>;
    bearish_fvg: Array<{ index: number; top: number; bottom: number; gap_size: number; type: string }>;
  };
  candlestick_patterns: {
    patterns: Array<{ index: number; pattern: string; type: string; name_tr: string }>;
  };
  volume_profile: {
    poc: number | null;
    value_area_high: number | null;
    value_area_low: number | null;
  };
  signal: {
    recommendation: string;
    score: number;
    signals: string[];
  };
}

export async function generateStockChart(
  symbol: string, 
  candles: Candle[], 
  analysis?: any, 
  scanType?: string
): Promise<string> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(process.cwd(), "server", "services", "chart_generator.py");
    const outputPath = `/tmp/chart_${symbol}_${Date.now()}.png`;
    const candlesJson = JSON.stringify(candles);
    const analysisJson = analysis ? JSON.stringify(analysis) : "null";
    
    const pythonProcess = spawn("python3", [
      scriptPath, 
      symbol, 
      candlesJson, 
      outputPath, 
      analysisJson, 
      scanType || ""
    ]);

    let dataString = "";
    let errorString = "";

    pythonProcess.stdout.on("data", (data) => {
      dataString += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      errorString += data.toString();
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error(`Chart generation failed with code ${code}`);
        console.error(`Error: ${errorString}`);
        reject(new Error(`Failed to generate chart for ${symbol}`));
        return;
      }

      try {
        const lines = dataString.trim().split("\n");
        const lastLine = lines[lines.length - 1];
        const result = JSON.parse(lastLine);
        
        if (result.error) {
          reject(new Error(result.error));
        } else {
          resolve(result.path);
        }
      } catch (err) {
        console.error("Failed to parse chart output:", dataString);
        reject(new Error("Invalid output from chart generator"));
      }
    });
  });
}

export async function runAdvancedAnalysis(candles: any[]): Promise<AdvancedAnalysis> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(process.cwd(), "server", "services", "advanced_analysis.py");
    const candlesJson = JSON.stringify(candles);
    
    const pythonProcess = spawn("python3", [scriptPath, candlesJson]);

    let dataString = "";
    let errorString = "";

    pythonProcess.stdout.on("data", (data) => {
      dataString += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      errorString += data.toString();
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error(`Advanced analysis script exited with code ${code}`);
        console.error(`Error: ${errorString}`);
        reject(new Error(`Failed to run advanced analysis`));
        return;
      }

      try {
        const lines = dataString.trim().split("\n");
        const lastLine = lines[lines.length - 1];
        const result = JSON.parse(lastLine);
        
        if (result.error) {
          reject(new Error(result.error));
        } else {
          resolve(result as AdvancedAnalysis);
        }
      } catch (err) {
        console.error("Failed to parse Python output:", dataString);
        reject(new Error("Invalid output from advanced analysis script"));
      }
    });
  });
}
