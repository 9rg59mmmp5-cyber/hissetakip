#@title Install & Import
from IPython.display import clear_output

!pip install ta
!pip install ccxt
!pip install --upgrade --no-cache-dir git+https://github.com/giraygokirmak/tvdatafeed.git
!pip install pyrogram tgcrypto
!pip install pyrogram
!pip install mpl_finance
!pip install openpyxl
!pip install tweepy
!pip install matplotlib-inline
!pip install TAcharts
!pip install talib-binary
!pip install yfinance
!pip install --upgrade mplfinance
!pip install pandas-ta
!pip install finta==0.3.1
!pip install telepot
!pip install tqdm
!pip install telethon
!pip install pandas_ta







print("installing is complated!!!")

import numpy as np
import pandas as pd
from datetime import datetime
import ta as taa
from scipy import signal
from scipy.stats import linregress
import ccxt
from tqdm import tqdm
from tvDatafeed import TvDatafeed,Interval
from mpl_finance import candlestick_ohlc
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import plotly.graph_objs as go
from plotly.subplots import make_subplots
import matplotlib.dates as mdates
import openpyxl
import os
import time
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import sys
import math
import csv
import numpy as np
import pandas as pd
# import talib as ta
import  mplfinance as mpf
import matplotlib.pyplot as plt
from openpyxl import Workbook,load_workbook
from finta import TA
import pandas_ta as ta
import tvDatafeed
from tvDatafeed import TvDatafeed, Interval
import logging
from numpy import histogram
from matplotlib.pyplot import hist
%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import sys
import math
from numpy import histogram
from matplotlib.pyplot import hist
import matplotlib.pyplot as plt
import  tweepy
import cv2
import telepot
from tqdm import tqdm
from telethon.sync import TelegramClient
from telethon import functions, types
import pandas as pd
import pandas_ta as ta
import matplotlib.pyplot as plt
import mplfinance as mpf
import numpy as np
import pandas as pd
from datetime import datetime
import ta
import ccxt
from tqdm import tqdm
import matplotlib
from mplfinance.original_flavor import candlestick_ohlc
import matplotlib.dates as mpl_dates
# matplotlib.style.use("fivethirtyeight")
np.set_printoptions(suppress=True, formatter={'float_kind':'{:0.0f}'.format})

logging.basicConfig(level=logging.DEBUG)
username = 'otomatikbot'
password = 'Halil.1998'
tv = TvDatafeed(username, password)

np.set_printoptions(suppress=True, formatter={'float_kind':'{:0.0f}'.format})
clear_output()
df = tv.get_hist("BIST:ADEL",interval=Interval.in_daily,n_bars=100)

import ta as taa

perplist = ["BINANCE:BTCUSDTPERP", "BINANCE:ETHUSDTPERP", "BINANCE:BCHUSDTPERP", "BINANCE:XRPUSDTPERP", "BINANCE:EOSUSDTPERP", "BINANCE:LTCUSDTPERP", "BINANCE:TRXUSDTPERP", "BINANCE:ETCUSDTPERP", "BINANCE:LINKUSDTPERP", "BINANCE:XLMUSDTPERP", "BINANCE:ADAUSDTPERP", "BINANCE:XMRUSDTPERP", "BINANCE:DASHUSDTPERP", "BINANCE:ZECUSDTPERP", "BINANCE:XTZUSDTPERP", "BINANCE:BNBUSDTPERP", "BINANCE:ATOMUSDTPERP", "BINANCE:ONTUSDTPERP", "BINANCE:IOTAUSDTPERP", "BINANCE:BATUSDTPERP", "BINANCE:VETUSDTPERP", "BINANCE:NEOUSDTPERP", "BINANCE:QTUMUSDTPERP", "BINANCE:IOSTUSDTPERP", "BINANCE:THETAUSDTPERP", "BINANCE:ALGOUSDTPERP", "BINANCE:ZILUSDTPERP", "BINANCE:KNCUSDTPERP", "BINANCE:ZRXUSDTPERP", "BINANCE:COMPUSDTPERP", "BINANCE:OMGUSDTPERP", "BINANCE:DOGEUSDTPERP", "BINANCE:SXPUSDTPERP", "BINANCE:KAVAUSDTPERP", "BINANCE:BANDUSDTPERP", "BINANCE:RLCUSDTPERP", "BINANCE:WAVESUSDTPERP", "BINANCE:MKRUSDTPERP", "BINANCE:SNXUSDTPERP", "BINANCE:DOTUSDTPERP", "BINANCE:DEFIUSDTPERP", "BINANCE:YFIUSDTPERP", "BINANCE:BALUSDTPERP", "BINANCE:CRVUSDTPERP", "BINANCE:TRBUSDTPERP", "BINANCE:RUNEUSDTPERP", "BINANCE:SUSHIUSDTPERP", "BINANCE:EGLDUSDTPERP", "BINANCE:SOLUSDTPERP", "BINANCE:ICXUSDTPERP", "BINANCE:STORJUSDTPERP", "BINANCE:BLZUSDTPERP", "BINANCE:UNIUSDTPERP", "BINANCE:AVAXUSDTPERP", "BINANCE:FTMUSDTPERP", "BINANCE:ENJUSDTPERP", "BINANCE:FLMUSDTPERP", "BINANCE:TOMOUSDTPERP", "BINANCE:RENUSDTPERP", "BINANCE:KSMUSDTPERP", "BINANCE:NEARUSDTPERP", "BINANCE:AAVEUSDTPERP", "BINANCE:FILUSDTPERP", "BINANCE:RSRUSDTPERP", "BINANCE:LRCUSDTPERP", "BINANCE:MATICUSDTPERP", "BINANCE:OCEANUSDTPERP", "BINANCE:BELUSDTPERP", "BINANCE:CTKUSDTPERP", "BINANCE:AXSUSDTPERP", "BINANCE:ALPHAUSDTPERP", "BINANCE:ZENUSDTPERP", "BINANCE:SKLUSDTPERP", "BINANCE:GRTUSDTPERP", "BINANCE:1INCHUSDTPERP", "BINANCE:CHZUSDTPERP", "BINANCE:SANDUSDTPERP", "BINANCE:ANKRUSDTPERP", "BINANCE:LITUSDTPERP", "BINANCE:UNFIUSDTPERP", "BINANCE:REEFUSDTPERP", "BINANCE:RVNUSDTPERP", "BINANCE:SFPUSDTPERP", "BINANCE:XEMUSDTPERP", "BINANCE:COTIUSDTPERP", "BINANCE:CHRUSDTPERP", "BINANCE:MANAUSDTPERP", "BINANCE:ALICEUSDTPERP", "BINANCE:HBARUSDTPERP", "BINANCE:ONEUSDTPERP", "BINANCE:LINAUSDTPERP", "BINANCE:STMXUSDTPERP", "BINANCE:DENTUSDTPERP", "BINANCE:CELRUSDTPERP", "BINANCE:HOTUSDTPERP", "BINANCE:MTLUSDTPERP", "BINANCE:OGNUSDTPERP", "BINANCE:NKNUSDTPERP", "BINANCE:DGBUSDTPERP", "BINANCE:1000SHIBUSDTPERP", "BINANCE:BAKEUSDTPERP", "BINANCE:GTCUSDTPERP", "BINANCE:BTCDOMUSDTPERP", "BINANCE:IOTXUSDTPERP", "BINANCE:AUDIOUSDTPERP", "BINANCE:C98USDTPERP", "BINANCE:MASKUSDTPERP", "BINANCE:ATAUSDTPERP", "BINANCE:DYDXUSDTPERP", "BINANCE:1000XECUSDTPERP", "BINANCE:GALAUSDTPERP", "BINANCE:CELOUSDTPERP", "BINANCE:ARUSDTPERP", "BINANCE:KLAYUSDTPERP", "BINANCE:ARPAUSDTPERP", "BINANCE:CTSIUSDTPERP", "BINANCE:LPTUSDTPERP", "BINANCE:ENSUSDTPERP", "BINANCE:PEOPLEUSDTPERP", "BINANCE:ANTUSDTPERP", "BINANCE:ROSEUSDTPERP", "BINANCE:DUSKUSDTPERP", "BINANCE:FLOWUSDTPERP", "BINANCE:IMXUSDTPERP", "BINANCE:API3USDTPERP", "BINANCE:GMTUSDTPERP", "BINANCE:APEUSDTPERP", "BINANCE:WOOUSDTPERP", "BINANCE:JASMYUSDTPERP", "BINANCE:DARUSDTPERP", "BINANCE:GALUSDTPERP", "BINANCE:OPUSDTPERP", "BINANCE:INJUSDTPERP", "BINANCE:STGUSDTPERP", "BINANCE:FOOTBALLUSDTPERP", "BINANCE:SPELLUSDTPERP", "BINANCE:1000LUNCUSDTPERP", "BINANCE:LUNA2USDTPERP", "BINANCE:LDOUSDTPERP", "BINANCE:CVXUSDTPERP", "BINANCE:ICPUSDTPERP", "BINANCE:APTUSDTPERP", "BINANCE:QNTUSDTPERP", "BINANCE:BLUEBIRDUSDTPERP", "BINANCE:FETUSDTPERP", "BINANCE:FXSUSDTPERP", "BINANCE:HOOKUSDTPERP", "BINANCE:MAGICUSDTPERP", "BINANCE:TUSDTPERP", "BINANCE:RNDRUSDTPERP", "BINANCE:HIGHUSDTPERP", "BINANCE:MINAUSDTPERP", "BINANCE:ASTRUSDTPERP", "BINANCE:AGIXUSDTPERP", "BINANCE:PHBUSDTPERP", "BINANCE:GMXUSDTPERP", "BINANCE:CFXUSDTPERP", "BINANCE:STXUSDTPERP", "BINANCE:COCOSUSDTPERP", "BINANCE:BNXUSDTPERP", "BINANCE:ACHUSDTPERP", "BINANCE:SSVUSDTPERP", "BINANCE:CKBUSDTPERP", "BINANCE:PERPUSDTPERP", "BINANCE:TRUUSDTPERP", "BINANCE:LQTYUSDTPERP", "BINANCE:USDCUSDTPERP", "BINANCE:IDUSDTPERP", "BINANCE:ARBUSDTPERP", "BINANCE:ETHUSDT_230630PERP", "BINANCE:BTCUSDT_230630PERP", "BINANCE:JOEUSDTPERP", "BINANCE:TLMUSDTPERP", "BINANCE:AMBUSDTPERP", "BINANCE:LEVERUSDTPERP", "BINANCE:RDNTUSDTPERP", "BINANCE:HFTUSDTPERP", "BINANCE:XVSUSDTPERP"]
hisselerlist = ["BIST:ACSEL","BIST:ADEL","BIST:ADESE","BIST:AEFES","BIST:AFYON","BIST:AGESA","BIST:AGHOL","BIST:AGYO","BIST:AKBNK","BIST:AKCNS","BIST:AKENR","BIST:AKFGY","BIST:AKGRT","BIST:AKGRT","BIST:AKMGY","BIST:AKSA","BIST:AKSEN","BIST:AKSGY","BIST:AKSUE","BIST:AKYHO","BIST:ALARK","BIST:ALBRK","BIST:ALCAR","BIST:ALCTL","BIST:ALGYO","BIST:ALKA","BIST:ALKIM","BIST:ALMAD","BIST:ANELE","BIST:ANGEN","BIST:ANHYT","BIST:ANSGR","BIST:ARASE","BIST:ARCLK","BIST:ARDYZ","BIST:ARENA","BIST:ARMDA","BIST:ARSAN","BIST:ARZUM","BIST:ASELS","BIST:ASUZU","BIST:ATAGY","BIST:ATATP","BIST:ATEKS","BIST:ATLAS","BIST:ATSYH","BIST:AVGYO","BIST:AVHOL","BIST:AVOD","BIST:AVTUR","BIST:AYCES","BIST:AYDEM","BIST:AYEN","BIST:AYES","BIST:AYGAZ","BIST:AZTEK","BIST:BAGFS","BIST:BAKAB","BIST:BALAT","BIST:BANVT","BIST:BARMA","BIST:BASCM","BIST:BASGZ","BIST:BAYRK","BIST:BERA","BIST:BEYAZ","BIST:BFREN","BIST:BIMAS","BIST:BIOEN","BIST:BIZIM","BIST:BJKAS","BIST:BLCYT","BIST:BMSCH","BIST:BMSTL","BIST:BNTAS","BIST:BOBET","BIST:BOSSA","BIST:BRISA","BIST:BRKO","BIST:BRKSN","BIST:BRLSM","BIST:BRMEN","BIST:BRSAN","BIST:BRYAT","BIST:BSOKE","BIST:BTCIM","BIST:BUCIM","BIST:BURCE","BIST:BURVA","BIST:CANTE","BIST:CASA","BIST:CCOLA","BIST:CELHA","BIST:CEMAS","BIST:CEMTS","BIST:CEOEM","BIST:CIMSA","BIST:CLEBI","BIST:CMBTN","BIST:CMENT","BIST:CONSE","BIST:COSMO","BIST:CRDFA","BIST:CRFSA","BIST:CUSAN","BIST:DAGHL","BIST:DAGI","BIST:DAPGM","BIST:DARDL","BIST:DENGE","BIST:DERHL","BIST:DERIM","BIST:DESA","BIST:DESPC","BIST:DEVA","BIST:DGATE","BIST:DGGYO","BIST:DGNMO","BIST:DIRIT","BIST:DITAS","BIST:DMSAS","BIST:DNISI","BIST:DOAS","BIST:DOBUR","BIST:DOCO","BIST:DOGUB","BIST:DOHOL","BIST:DOKTA","BIST:DURDO","BIST:DYOBY","BIST:DZGYO","BIST:ECILC","BIST:ECZYT","BIST:EDATA","BIST:EDIP","BIST:EGEEN","BIST:EGEPO","BIST:EGGUB","BIST:EGPRO","BIST:EGSER","BIST:EKGYO","BIST:EKIZ","BIST:ELITE","BIST:EMKEL","BIST:EMNIS","BIST:ENJSA","BIST:ENKAI","BIST:ENSRI","BIST:EPLAS","BIST:ERBOS","BIST:ERCB","BIST:EREGL","BIST:ERSU","BIST:ESCAR","BIST:ESCOM","BIST:ESEN","BIST:ETILR","BIST:ETYAT","BIST:EUHOL","BIST:EUKYO","BIST:EUREN","BIST:EUYO","BIST:FADE","BIST:FENER","BIST:FLAP","BIST:FMIZP","BIST:FONET","BIST:FORMT","BIST:FRIGO","BIST:FROTO","BIST:GARAN","BIST:GARFA","BIST:GEDIK","BIST:GEDZA","BIST:GENIL","BIST:GENTS","BIST:GEREL","BIST:GESAN","BIST:GLBMD","BIST:GLCVY","BIST:GLRYH","BIST:GLYHO","BIST:GMTAS","BIST:GOLTS","BIST:GOODY","BIST:GOZDE","BIST:GRNYO","BIST:GRSEL","BIST:GSDDE","BIST:GSDHO","BIST:GSRAY","BIST:GUBRF","BIST:GWIND","BIST:GZNMI","BIST:HALKB","BIST:HATEK","BIST:HDFGS","BIST:HEDEF","BIST:HEKTS","BIST:HKTM","BIST:HLGYO","BIST:HTTBT","BIST:HUBVC","BIST:HUNER","BIST:HURGZ","BIST:ICBCT","BIST:IDEAS","BIST:IDGYO","BIST:IEYHO","BIST:IHAAS","BIST:IHEVA","BIST:IHGZT","BIST:IHLAS","BIST:IHLGM","BIST:IHYAY","BIST:IMASM","BIST:INDES","BIST:INFO","BIST:INTEM","BIST:INVEO","BIST:INVES","BIST:IPEKE","BIST:ISATR","BIST:ISBIR","BIST:ISBTR","BIST:ISCTR","BIST:ISDMR","BIST:ISFIN","BIST:ISGSY","BIST:ISGYO","BIST:ISKPL","BIST:ISMEN","BIST:ISSEN","BIST:ISYAT","BIST:ITTFH","BIST:IZFAS","BIST:IZINV","BIST:IZMDC","BIST:JANTS","BIST:KAPLM","BIST:KAREL","BIST:KARSN","BIST:KARTN","BIST:KARYE","BIST:KATMR","BIST:KCAER","BIST:KCHOL","BIST:KENT","BIST:KERVN","BIST:KERVT","BIST:KFEIN","BIST:KGYO","BIST:KIMMR","BIST:KLGYO","BIST:KLKIM","BIST:KLMSN","BIST:KLNMA","BIST:KLRHO","BIST:KLSYN","BIST:KMPUR","BIST:KNFRT","BIST:KONKA","BIST:KONTR","BIST:KONYA","BIST:KORDS","BIST:KOZAA","BIST:KOZAL","BIST:KRDMA","BIST:KRDMB","BIST:KRDMD","BIST:KRGYO","BIST:KRONT","BIST:KRPLS","BIST:KRSTL","BIST:KRTEK","BIST:KRVGD","BIST:KSTUR","BIST:KTSKR","BIST:KUTPO","BIST:KUVVA","BIST:KUYAS","BIST:KZBGY","BIST:LIDER","BIST:LIDFA","BIST:LINK","BIST:LKMNH","BIST:LOGO","BIST:LUKSK","BIST:MAALT","BIST:MAGEN","BIST:MAKIM","BIST:MAKTK","BIST:MANAS","BIST:MARKA","BIST:MARTI","BIST:MAVI","BIST:MEDTR","BIST:MEGAP","BIST:MEPET","BIST:MERCN","BIST:MERIT","BIST:MERKO","BIST:METRO","BIST:METUR","BIST:MGROS","BIST:MIATK","BIST:MIPAZ","BIST:MMCAS","BIST:MNDRS","BIST:MOBTL","BIST:MPARK","BIST:MRGYO","BIST:MRSHL","BIST:MSGYO","BIST:MTRKS","BIST:MTRYO","BIST:MZHLD","BIST:NATEN","BIST:NETAS","BIST:NIBAS","BIST:NTGAZ","BIST:NTHOL","BIST:NUGYO","BIST:NUHCM","BIST:OBASE","BIST:ODAS","BIST:ORCAY","BIST:ORGE","BIST:ORMA","BIST:OSMEN","BIST:OSTIM","BIST:OTKAR","BIST:OTTO","BIST:OYAKC","BIST:OYAYO","BIST:OYLUM","BIST:OYYAT","BIST:OZGYO","BIST:OZKGY","BIST:OZRDN","BIST:PAGYO","BIST:PAMEL","BIST:PAPIL","BIST:PARSN","BIST:PCILT","BIST:PEGYO","BIST:PEKGY","BIST:PENGD","BIST:PENTA","BIST:PETKM","BIST:PETUN","BIST:PGSUS","BIST:PINSU","BIST:PKART","BIST:PKENT","BIST:PNLSN","BIST:PNSUT","BIST:POLHO","BIST:POLTK","BIST:PRDGS","BIST:PRKAB","BIST:PRKME","BIST:PRZMA","BIST:PSDTC","BIST:PSGYO","BIST:QNBFB","BIST:QNBFL","BIST:QUAGR","BIST:RALYH","BIST:RAYSG","BIST:RHEAG","BIST:RNPOL","BIST:RODRG","BIST:ROYAL","BIST:RTALB","BIST:RUBNS","BIST:RYGYO","BIST:RYSAS","BIST:SAFKR","BIST:SAHOL","BIST:SAMAT","BIST:SANEL","BIST:SANFM","BIST:SANKO","BIST:SARKY","BIST:SASA","BIST:SAYAS","BIST:SEGYO","BIST:SEKFK","BIST:SEKUR","BIST:SELEC","BIST:SELGD","BIST:SELVA","BIST:SEYKM","BIST:SILVR","BIST:SISE","BIST:SKBNK","BIST:SKTAS","BIST:SMART","BIST:SMRTG","BIST:SNGYO","BIST:SNKRN","BIST:SNPAM","BIST:SODSN","BIST:SOKM","BIST:SONME","BIST:SRVGY","BIST:SUMAS","BIST:SUNTK","BIST:SUWEN","BIST:TATGD","BIST:TAVHL","BIST:TBORG","BIST:TCELL","BIST:TDGYO","BIST:TEKTU","BIST:TETMT","BIST:TEZOL","BIST:TGSAS","BIST:THYAO","BIST:TKFEN","BIST:TKNSA","BIST:TLMAN","BIST:TMPOL","BIST:TMSN","BIST:TOASO","BIST:TRCAS","BIST:TRGYO","BIST:TRILC","BIST:TSGYO","BIST:TSKB","BIST:TSPOR","BIST:TTKOM","BIST:TTRAK","BIST:TUCLK","BIST:TUKAS","BIST:TUPRS","BIST:TUREX","BIST:TURGG","BIST:TURSG","BIST:UFUK","BIST:ULAS","BIST:ULKER","BIST:ULUFA","BIST:ULUSE","BIST:ULUUN","BIST:UMPAS","BIST:UNLU","BIST:USAK","BIST:UZERB","BIST:VAKBN","BIST:VAKFN","BIST:VAKKO","BIST:VANGD","BIST:VBTYZ","BIST:VERTU","BIST:VERUS","BIST:VESBE","BIST:VESTL","BIST:VKFYO","BIST:VKGYO","BIST:VKING","BIST:YAPRK","BIST:YATAS","BIST:YAYLA","BIST:YBTAS","BIST:YEOTK","BIST:YESIL","BIST:YGGYO","BIST:YGYO","BIST:YKBNK","BIST:YKSLN","BIST:YONGA","BIST:YUNSA","BIST:YYAPI","BIST:YYLGD","BIST:ZEDUR","BIST:ZOREN","BIST:ZRGYO"]
coinlist = ['BINANCE:BTCUSDT', 'BINANCE:1INCHUSDT', 'BINANCE:AAVEUSDT', 'BINANCE:ACMUSDT', 'BINANCE:ADAUSDT', 'BINANCE:AKROUSDT', 'BINANCE:ALGOUSDT', 'BINANCE:ALICEUSDT', 'BINANCE:ALPACAUSDT', 'BINANCE:ALPHAUSDT', 'BINANCE:ANKRUSDT', 'BINANCE:ANTUSDT', 'BINANCE:ARDRUSDT', 'BINANCE:ARPAUSDT', 'BINANCE:ARUSDT', 'BINANCE:ASRUSDT', 'BINANCE:ATAUSDT', 'BINANCE:ATMUSDT', 'BINANCE:ATOMUSDT', 'BINANCE:AUDIOUSDT', 'BINANCE:AUDUSDT', 'BINANCE:AUTOUSDT', 'BINANCE:AVAUSDT', 'BINANCE:AVAXUSDT', 'BINANCE:AXSUSDT', 'BINANCE:BADGERUSDT', 'BINANCE:BAKEUSDT', 'BINANCE:BALUSDT', 'BINANCE:BANDUSDT', 'BINANCE:BATUSDT', 'BINANCE:BCHUSDT', 'BINANCE:BELUSDT', 'BINANCE:BLZUSDT', 'BINANCE:BNTUSDT', 'BINANCE:BONDUSDT', 'BINANCE:BURGERUSDT', 'BINANCE:BUSDUSDT', 'BINANCE:C98USDT', 'BINANCE:CAKEUSDT', 'BINANCE:CELOUSDT', 'BINANCE:CELRUSDT', 'BINANCE:CFXUSDT', 'BINANCE:CHRUSDT', 'BINANCE:CHZUSDT', 'BINANCE:CKBUSDT', 'BINANCE:CLVUSDT', 'BINANCE:COCOSUSDT', 'BINANCE:COMPUSDT', 'BINANCE:COSUSDT', 'BINANCE:COTIUSDT', 'BINANCE:CRVUSDT', 'BINANCE:CTKUSDT', 'BINANCE:CTSIUSDT', 'BINANCE:CTXCUSDT', 'BINANCE:DASHUSDT', 'BINANCE:DATAUSDT', 'BINANCE:DCRUSDT', 'BINANCE:DEGOUSDT', 'BINANCE:DENTUSDT', 'BINANCE:DEXEUSDT', 'BINANCE:DGBUSDT', 'BINANCE:DIAUSDT', 'BINANCE:DOCKUSDT', 'BINANCE:DODOUSDT', 'BINANCE:DOGEUSDT', 'BINANCE:DOTUSDT', 'BINANCE:DREPUSDT', 'BINANCE:DUSKUSDT', 'BINANCE:EGLDUSDT', 'BINANCE:ENJUSDT', 'BINANCE:EOSUSDT', 'BINANCE:ERNUSDT', 'BINANCE:ETCUSDT', 'BINANCE:EURUSDT', 'BINANCE:FARMUSDT', 'BINANCE:FETUSDT', 'BINANCE:FILUSDT', 'BINANCE:FIOUSDT', 'BINANCE:FIROUSDT', 'BINANCE:FISUSDT', 'BINANCE:FLMUSDT', 'BINANCE:FLOWUSDT', 'BINANCE:FORTHUSDT', 'BINANCE:FTMUSDT', 'BINANCE:FUNUSDT', 'BINANCE:GBPUSDT', 'BINANCE:GRTUSDT', 'BINANCE:GTCUSDT', 'BINANCE:HARDUSDT', 'BINANCE:HBARUSDT', 'BINANCE:HIVEUSDT', 'BINANCE:HOTUSDT', 'BINANCE:ICPUSDT', 'BINANCE:ICXUSDT', 'BINANCE:INJUSDT', 'BINANCE:IOSTUSDT', 'BINANCE:IOTAUSDT', 'BINANCE:IOTXUSDT', 'BINANCE:IRISUSDT', 'BINANCE:JSTUSDT', 'BINANCE:JUVUSDT', 'BINANCE:KAVAUSDT', 'BINANCE:KEYUSDT', 'BINANCE:KLAYUSDT', 'BINANCE:KMDUSDT', 'BINANCE:KNCUSDT', 'BINANCE:KSMUSDT', 'BINANCE:LINAUSDT', 'BINANCE:LINKUSDT', 'BINANCE:LITUSDT', 'BINANCE:LPTUSDT', 'BINANCE:LRCUSDT', 'BINANCE:LSKUSDT', 'BINANCE:LTCUSDT', 'BINANCE:LTOUSDT', 'BINANCE:LUNAUSDT', 'BINANCE:MANAUSDT', 'BINANCE:MASKUSDT', 'BINANCE:MATICUSDT', 'BINANCE:MBLUSDT', 'BINANCE:MDTUSDT', 'BINANCE:MDXUSDT', 'BINANCE:MINAUSDT', 'BINANCE:MKRUSDT', 'BINANCE:MLNUSDT', 'BINANCE:MTLUSDT', 'BINANCE:NEARUSDT', 'BINANCE:NEOUSDT', 'BINANCE:NMRUSDT', 'BINANCE:NULSUSDT', 'BINANCE:OCEANUSDT', 'BINANCE:OGNUSDT', 'BINANCE:OGUSDT', 'BINANCE:OMGUSDT', 'BINANCE:OMUSDT', 'BINANCE:ONEUSDT', 'BINANCE:ONGUSDT', 'BINANCE:ONTUSDT', 'BINANCE:ORNUSDT', 'BINANCE:OXTUSDT', 'BINANCE:PAXGUSDT', 'BINANCE:PERLUSDT', 'BINANCE:PERPUSDT', 'BINANCE:PHAUSDT', 'BINANCE:PNTUSDT', 'BINANCE:POLSUSDT', 'BINANCE:PONDUSDT', 'BINANCE:PSGUSDT', 'BINANCE:PUNDIXUSDT', 'BINANCE:QNTUSDT', 'BINANCE:QTUMUSDT', 'BINANCE:QUICKUSDT', 'BINANCE:RAYUSDT', 'BINANCE:REEFUSDT', 'BINANCE:RIFUSDT', 'BINANCE:RLCUSDT', 'BINANCE:ROSEUSDT', 'BINANCE:RSRUSDT', 'BINANCE:RUNEUSDT', 'BINANCE:RVNUSDT', 'BINANCE:SANDUSDT', 'BINANCE:SCUSDT', 'BINANCE:SFPUSDT', 'BINANCE:SHIBUSDT', 'BINANCE:SKLUSDT', 'BINANCE:SLPUSDT', 'BINANCE:SNXUSDT', 'BINANCE:SOLUSDT', 'BINANCE:STMXUSDT', 'BINANCE:STORJUSDT', 'BINANCE:STPTUSDT', 'BINANCE:STRAXUSDT', 'BINANCE:STXUSDT', 'BINANCE:SUNUSDT', 'BINANCE:SUPERUSDT', 'BINANCE:SUSHIUSDT', 'BINANCE:SXPUSDT', 'BINANCE:TFUELUSDT', 'BINANCE:THETAUSDT', 'BINANCE:TKOUSDT', 'BINANCE:TLMUSDT', 'BINANCE:TOMOUSDT', 'BINANCE:TRBUSDT', 'BINANCE:TROYUSDT', 'BINANCE:TRUUSDT', 'BINANCE:TRXUSDT', 'BINANCE:TUSDUSDT', 'BINANCE:TVKUSDT', 'BINANCE:TWTUSDT', 'BINANCE:UMAUSDT', 'BINANCE:UNFIUSDT', 'BINANCE:UNIUSDT', 'BINANCE:USDCUSDT', 'BINANCE:UTKUSDT', 'BINANCE:VETUSDT', 'BINANCE:VITEUSDT', 'BINANCE:VTHOUSDT', 'BINANCE:WANUSDT', 'BINANCE:WAVESUSDT', 'BINANCE:WINGUSDT', 'BINANCE:WINUSDT', 'BINANCE:WNXMUSDT', 'BINANCE:WRXUSDT', 'BINANCE:WTCUSDT', 'BINANCE:XEMUSDT', 'BINANCE:XLMUSDT', 'BINANCE:XMRUSDT', 'BINANCE:XRPUSDT', 'BINANCE:XTZUSDT', 'BINANCE:XVGUSDT', 'BINANCE:XVSUSDT', 'BINANCE:YFIIUSDT', 'BINANCE:YFIUSDT', 'BINANCE:ZECUSDT', 'BINANCE:ZENUSDT', 'BINANCE:ZILUSDT', 'BINANCE:ZRXUSDT', 'BINANCE:BNBUSDT', 'BINANCE:ETHUSDT', 'BINANCE:RENUSDT', 'BINANCE:NKNUSDT', 'BINANCE:BTSUSDT', 'BINANCE:BARUSDT', 'BINANCE:MBOXUSDT', 'BINANCE:FORUSDT', 'BINANCE:REQUSDT', 'BINANCE:GHSTUSDT', 'BINANCE:WAXPUSDT', 'BINANCE:GNOUSDT', 'BINANCE:XECUSDT', 'BINANCE:ELFUSDT', 'BINANCE:DYDXUSDT', 'BINANCE:IDEXUSDT', 'BINANCE:VIDTUSDT', 'BINANCE:USDPUSDT', 'BINANCE:GALAUSDT', 'BINANCE:ILVUSDT', 'BINANCE:YGGUSDT', 'BINANCE:SYSUSDT', 'BINANCE:DFUSDT', 'BINANCE:FIDAUSDT', 'BINANCE:FRONTUSDT', 'BINANCE:CVPUSDT', 'BINANCE:AGLDUSDT', 'BINANCE:RADUSDT', 'BINANCE:BETAUSDT', 'BINANCE:RAREUSDT', 'BINANCE:LAZIOUSDT', 'BINANCE:CHESSUSDT', 'BINANCE:ADXUSDT', 'BINANCE:AUCTIONUSDT', 'BINANCE:DARUSDT', 'BINANCE:BNXUSDT', 'BINANCE:MOVRUSDT', 'BINANCE:CITYUSDT', 'BINANCE:ENSUSDT', 'BINANCE:KP3RUSDT', 'BINANCE:QIUSDT', 'BINANCE:PORTOUSDT', 'BINANCE:POWRUSDT', 'BINANCE:VGXUSDT', 'BINANCE:JASMYUSDT', 'BINANCE:AMPUSDT', 'BINANCE:PLAUSDT', 'BINANCE:PYRUSDT', 'BINANCE:RNDRUSDT', 'BINANCE:ALCXUSDT', 'BINANCE:SANTOSUSDT', 'BINANCE:MCUSDT', 'BINANCE:BICOUSDT', 'BINANCE:FLUXUSDT', 'BINANCE:FXSUSDT', 'BINANCE:VOXELUSDT', 'BINANCE:HIGHUSDT', 'BINANCE:CVXUSDT', 'BINANCE:PEOPLEUSDT', 'BINANCE:OOKIUSDT', 'BINANCE:SPELLUSDT', 'BINANCE:JOEUSDT', 'BINANCE:ACHUSDT', 'BINANCE:IMXUSDT', 'BINANCE:GLMRUSDT', 'BINANCE:LOKAUSDT', 'BINANCE:SCRTUSDT', 'BINANCE:API3USDT', 'BINANCE:BTTCUSDT', 'BINANCE:ACAUSDT', 'BINANCE:XNOUSDT', 'BINANCE:WOOUSDT', 'BINANCE:ALPINEUSDT', 'BINANCE:TUSDT', 'BINANCE:ASTRUSDT', 'BINANCE:GMTUSDT', 'BINANCE:KDAUSDT', 'BINANCE:APEUSDT', 'BINANCE:BSWUSDT', 'BINANCE:BIFIUSDT', 'BINANCE:MULTIUSDT', 'BINANCE:STEEMUSDT', 'BINANCE:MOBUSDT', 'BINANCE:NEXOUSDT', 'BINANCE:REIUSDT', 'BINANCE:GALUSDT', 'BINANCE:LDOUSDT', 'BINANCE:EPXUSDT', 'BINANCE:OPUSDT', 'BINANCE:LEVERUSDT', 'BINANCE:STGUSDT', 'BINANCE:LUNCUSDT', 'BINANCE:GMXUSDT', 'BINANCE:NEBLUSDT', 'BINANCE:POLYXUSDT', 'BINANCE:APTUSDT', 'BINANCE:OSMOUSDT', 'BINANCE:HFTUSDT', 'BINANCE:PHBUSDT', 'BINANCE:HOOKUSDT', 'BINANCE:MAGICUSDT', 'BINANCE:HIFIUSDT', 'BINANCE:RPLUSDT', 'BINANCE:PROSUSDT', 'BINANCE:AGIXUSDT', 'BINANCE:GNSUSDT', 'BINANCE:SYNUSDT', 'BINANCE:VIBUSDT', 'BINANCE:SSVUSDT', 'BINANCE:LQTYUSDT', 'BINANCE:AMBUSDT', 'BINANCE:BETHUSDT', 'BINANCE:USTCUSDT', 'BINANCE:GASUSDT', 'BINANCE:GLMUSDT', 'BINANCE:PROMUSDT', 'BINANCE:QKCUSDT', 'BINANCE:UFTUSDT', 'BINANCE:IDUSDT', 'BINANCE:ARBUSDT', 'BINANCE:LOOMUSDT', 'BINANCE:OAXUSDT', 'BINANCE:RDNTUSDT']
coinlist
hisselerlist
perplist
hepsilist = coinlist + hisselerlist + perplist

print(hepsilist)
## tweet atmak için.
consumer_key = 'FJ6kGDudmvZK7ggyMXkSxeBMq'
consumer_secret = '2z8HRiaAxBBy4HknFVuLZtKerqqtWebPVBbHRLmi70V6HX8PHb'
access_token = '2470264535-iW0wEfdaeyHqTNoScbIVJWsVkXNjUCfq6C9zC3M'
access_token_secret = 'ISMBkL5ePiMwAKpga3mSqCKz1kDRlx3EywgrvY0I4InGe'
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, wait_on_rate_limit = True )
twit_at = api.update_status

def resim_att(text, filename):
  media = api.media_upload(filename)
  api.update_status(text,media_ids = [media.media_id_string])

import requests

def mesaj_at(bot_mesaj, id: str):
    bot_token = ("5747202724:AAHLfOnWPZE0TAyvFO0vEaJUYyVYYOOodC4")
    bot_chatID = id
    url = 'https://api.telegram.org/bot' + bot_token + '/sendMessage?chat_id=' + str(bot_chatID) + '&parse_mode=Markdown&text=' + bot_mesaj


    response = requests.get(url)

# telegram_bot_sendtext as mesaj_at ## fonksiyonu mesaj_at şeklinde cağırılabilir hale getirdim.
# benim_id = '860174169'
# halilgrup_id = '-1001794193133'
# mesaj_at("merhaba", benim_id) ## 860174169 bot kendime mesaj atıyor.
# mesaj_at("merhaba",halilgrup_id) ## -1001794193133 bot HALil grup'a mesaj atıyor.

# Resim atmak için kullanılacak.
token = "5747202724:AAHLfOnWPZE0TAyvFO0vEaJUYyVYYOOodC4"
id= 860174169
id1 = 1001794193133
id2 = 818845314
# id3 = -818845314
bot= telepot.Bot(token)
# bot.sendMessage(id,'Test mesajı')
# bot.sendPhoto(id,photo=open(f"{coin}.png", 'rb'))  # mesaj attırmak için eklenecek kod.
def norm(O,H,L,C):
    Max = max(H)
    Min = min(L)
    Range = (Max - Min) / 100

    O1 = (O - Min) / Range
    H1 = (H - Min) / Range
    L1 = (L - Min) / Range
    C1 = (C - Min) / Range

    return [O1, H1, L1, C1]

 ##Add MACD as subplot
def MACD(df, window_slow, window_fast, window_signal):
    macd = pd.DataFrame()
    macd['ema_slow'] = df.close.ewm(span=window_slow).mean()
    macd['ema_fast'] = df.close.ewm(span=window_fast).mean()
    macd['macd'] = macd['ema_slow'] - macd['ema_fast']
    macd['signal'] = macd['macd'].ewm(span=window_signal).mean()
    macd['diff'] = macd['macd'] - macd['signal']
    macd['bar_positive'] = macd['diff'].map(lambda x: x if x > 0 else 0)
    macd['bar_negative'] = macd['diff'].map(lambda x: x if x < 0 else 0)
    return macd

macd = MACD(df, 12, 26, 9)
macd_plot  = [
    mpf.make_addplot((macd['macd']), color='#606060', panel=2, ylabel='MACD', secondary_y=False),
    mpf.make_addplot((macd['signal']), color='#1f77b4', panel=2, secondary_y=False),
    mpf.make_addplot((macd['bar_positive']), type='bar', color='#4dc790', panel=2),
    mpf.make_addplot((macd['bar_negative']), type='bar', color='#fd6b6c', panel=2),
]

mpf.plot(df, type='candle', volume=True, addplot=macd_plot,style='yahoo')
# Stochastic
def Stochastic(df, window, smooth_window):
    stochastic = pd.DataFrame()
    stochastic['%K'] = ((df.close - df.low.rolling(window).min()) \
                        / (df.high.rolling(window).max() - df.low.rolling(window).min())) * 100
    stochastic['%D'] = stochastic['%K'].rolling(smooth_window).mean()
    stochastic['%SD'] = stochastic['%D'].rolling(smooth_window).mean()
    stochastic['UL'] = 80
    stochastic['DL'] = 20
    return stochastic

stochastic = Stochastic(df, 14, 3)
stochastic_plot  = [
    mpf.make_addplot((stochastic[['%K', '%D', '%SD', 'UL', 'DL']]), ylim=[0, 100], panel=2, ylabel='Stoch')
]

# mpf.plot(df, type='candle', volume=True, addplot=stochastic_plot,figscale=1.5,style='yahoo')

macd = MACD(df, 12, 26, 9)
stochastic = Stochastic(df, 14, 3)
plots  = [
    mpf.make_addplot((macd['macd']), color='#606060', panel=1, ylabel='MACD (12,26,9)', secondary_y=False),
    mpf.make_addplot((macd['signal']), color='#1f77b4', panel=1, secondary_y=False),
    mpf.make_addplot((macd['bar_positive']), type='bar', color='#4dc790', panel=1),
    mpf.make_addplot((macd['bar_negative']), type='bar', color='#fd6b6c', panel=1),
    mpf.make_addplot((stochastic[['%D', '%SD', 'UL', 'DL']]), ylim=[0, 100], panel=2, ylabel='StochRSI (14,3)')
]
mpf.plot(df, type='candle', style='yahoo', mav=(5,20), addplot=plots, panel_ratios=(3,2,2), figscale=1.5)

macd = MACD(df, 12, 26, 9)
stochastic = Stochastic(df, 14, 3)
# macd.signal #turuncu çizgi
macd.macd #mavi çizgi

def cross_bul (seris_a,series_b):
  pre_short = seris_a[len(seris_a)-2]
  short = seris_a[len(seris_a)-1]
  pre_long = series_b[len(series_b)-2]
  long = series_b[len(series_b)-1]

  if pre_short < pre_long and short > long:
    return True
  else :
    return False
def Supertrend(df, atr_period, multiplier):

    high = df.high
    low = df.low
    close = df.close

    # calculate ATR
    price_diffs = [high - low,
                   high - close.shift(),
                   close.shift() - low]
    true_range = pd.concat(price_diffs, axis=1)
    true_range = true_range.abs().max(axis=1)
    # default ATR calculation in supertrend indicator
    atr = true_range.ewm(alpha=1/atr_period,min_periods=atr_period).mean()
    # df['atr'] = df['tr'].rolling(atr_period).mean()

    # HL2 is simply the average of high and low prices
    hl2 = (high + low) / 2
    # upperband and lowerband calculation
    # notice that final bands are set to be equal to the respective bands
    final_upperband = upperband = hl2 + (multiplier * atr)
    final_lowerband = lowerband = hl2 - (multiplier * atr)

    # initialize Supertrend column to True
    supertrend = [True] * len(df)

    for i in range(1, len(df.index)):
        curr, prev = i, i-1

        # if current close price crosses above upperband
        if close[curr] > final_upperband[prev]:
            supertrend[curr] = True
        # if current close price crosses below lowerband
        elif close[curr] < final_lowerband[prev]:
            supertrend[curr] = False
        # else, the trend continues
        else:
            supertrend[curr] = supertrend[prev]

            # adjustment to the final bands
            if supertrend[curr] == True and final_lowerband[curr] < final_lowerband[prev]:
                final_lowerband[curr] = final_lowerband[prev]
            if supertrend[curr] == False and final_upperband[curr] > final_upperband[prev]:
                final_upperband[curr] = final_upperband[prev]

        # to remove bands according to the trend direction
        if supertrend[curr] == True:
            final_upperband[curr] = np.nan
        else:
            final_lowerband[curr] = np.nan

    return pd.DataFrame({
        'Supertrend': supertrend,
        'Final Lowerband': final_lowerband,
        'Final Upperband': final_upperband
    }, index=df.index)


atr_period = 10
atr_multiplier = 3.0

#@title alpha_trend function
def alphaTrend(df):
    open = df['open']
    close = df['close']
    high = df['high']
    low = df['low']
    volume = df['volume']
    ap = 14
    atr = ta.volatility.AverageTrueRange(df["high"], df["low"], df["close"], window=14).average_true_range()
    noVolumeData = False
    coeff = 1
    upt = df["low"] - atr * coeff
    downT = df["high"] + atr * coeff
    AlphaTrend = [0.0]
    src = close
    rsi = df["rsi"]
    k1 = []
    k2 = []
    mfi = df["mfi"]

    for i in range(1, len(close)):
        if noVolumeData is True and rsi[i] >= 50:
            if upt[i] < AlphaTrend[i - 1]:
                AlphaTrend.append(AlphaTrend[i - 1])
            else:
                AlphaTrend.append(upt[i])

        elif noVolumeData is False and mfi[i] >= 50:
            if upt[i] < AlphaTrend[i - 1]:
                AlphaTrend.append(AlphaTrend[i - 1])
            else:
                AlphaTrend.append(upt[i])
        else:
            if downT[i] > AlphaTrend[i - 1]:
                AlphaTrend.append(AlphaTrend[i - 1])
            else:
                AlphaTrend.append(downT[i])

    for i in range(len(AlphaTrend)):
        if i < 2:
            k2.append(0)
            k1.append(AlphaTrend[i])
        else:
            k2.append(AlphaTrend[i - 2])
            k1.append(AlphaTrend[i])

    at = pd.DataFrame(data=k1, columns=['k1'])
    at['k2'] = k2
    return at

#calısanı while döngülü
liste = coinlist

timeframe_dict = {
    "15m": Interval.in_15_minute,
    "30m": Interval.in_30_minute,
    "1h": Interval.in_1_hour,
    "2h": Interval.in_2_hour,
    "4h": Interval.in_4_hour,
    "1d": Interval.in_daily,
    "1w": Interval.in_weekly,
    "m": Interval.in_monthly
}

result = []
timeframe_list = list(timeframe_dict.keys())
zaman_index = 0
max_len = 150

while True:
    zaman = timeframe_list[zaman_index]
    for symbol in tqdm(liste):
        try:
            data = tv.get_hist(symbol=symbol, interval=timeframe_dict[zaman], n_bars=max_len)

            df = data

            df["date"] = pd.to_datetime(df.index, unit='s')
            df.index = pd.date_range(str(df["date"][0]), periods=len(df), freq='D')
            df["date"] = pd.to_datetime(df.index, unit='s')

            df["open_norm"], df["high_norm"], df["low_norm"], df["close_norm"] = norm(df["open"], df["high"], df["low"], df["close"])
            df["open"], df["high"], df["low"], df["close"] = norm(df["open"], df["high"], df["low"], df["close"])

            for order in [130, 125, 120, 110, 100, 90, 80, 70, 60, 50, 40, 35, 30, 25, 20, 18, 16, 14, 12, 10, 8]:
                try:
                    high = signal.argrelextrema(np.array(df["high"]), np.greater_equal, order=order)
                    high = high[0]

                    low = signal.argrelextrema(np.array(df["low"]), np.less_equal, order=order)
                    low = low[0]

                    if high[-1] > low[-1]:
                        index = high
                        val = df["high"][index]

                        slope = linregress([index[-3], index[-2]], [val[-3], val[-2]])

                        if val[-1] < val[-2] < val[-3] and df["close"][-1] > slope[0]*(len(df)-1) + slope[1] and val[-1] > slope[0]*(index[-1]) + slope[1] and slope[0]*(len(df) - 1) + slope[1] > df["close"][-1]-5:
                            result.append(symbol)

                            index_ = [index[-3], len(df)-1]
                            val_ = [slope[0]*(index[-3]) + slope[1], slope[0]*(len(df) - 1) + slope[1]]

                            fig, ax = plt.subplots(figsize=(7, 5))
                            candlestick_ohlc(ax, zip(mdates.date2num(df.index.to_pydatetime()), df["open"], df["high"], df["low"], df["close"]), width=0.6, colorup='green', colordown='red')
                            plt.plot(df.index[index_], val_, 'r-')
                            ax.xaxis.set_visible(False)
                            ax.yaxis.set_visible(False)
                            plt.ylabel('Fiyat')
                            plt.title(f'{symbol}')
                            plt.figtext(0.95, 0.05, 'Grafik otomatik oluşturulmuştur. Aksiliklerde dikkate almayın. (@beyefend112)', fontsize=10, color='gray', ha='right', va='bottom', alpha=0.7)
                            fig.savefig(f"{symbol}.png", bbox_inches='tight')
                            bot.sendPhoto(id, photo=open(f"{symbol}.png", 'rb'), caption=f"{zaman} grafiğinde hisse ismi= {symbol} /n  >>> https://tr.tradingview.com/chart/?symbol={symbol}&interval=D")
                            os.remove(f"{symbol}.png")
                            break

                except Exception as e:
                    pass

        except Exception as e:
            print(e)

    print(f"{zaman} GRAFİKTE Düşeni Kıranlar Yada Retest Yapanlar : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    result.clear()

    zaman_index = (zaman_index + 1) % len(timeframe_list)
    time.sleep(1)  # Bekleme süresi (saniye)
liste = hepsilist

timeframe_dict = {
    "15m": Interval.in_15_minute,
    "30m": Interval.in_30_minute,
    "1h": Interval.in_1_hour,
    "2h": Interval.in_2_hour,
    "4h": Interval.in_4_hour,
    "1d": Interval.in_daily,
    "1w": Interval.in_weekly,
    "m": Interval.in_monthly
}

result = []
timeframe_list = list(timeframe_dict.keys())
zaman_index = 0
max_len = 150

while True:
    zaman = timeframe_list[zaman_index]
    for symbol in tqdm(liste):
        try:
            data = tv.get_hist(symbol=symbol, interval=timeframe_dict[zaman], n_bars=max_len)
            macd = MACD(data, 12, 26, 9)
            macd1 = macd.macd
            signal1 = macd.signal
            stochastic = Stochastic(df, 14, 3)

            # Destek ve direnç seviyelerini hesaplayın
            low = min(df.low)
            high = max(df.high)

            # Fibonacci seviyelerini hesaplayın
            level1 = low
            level2 = low + (high - low) * 0.236
            level3 = low + (high - low) * 0.382
            level4 = low + (high - low) * 0.5
            level5 = low + (high - low) * 0.618
            level6 = low + (high - low) * 0.65
            level7 = low + (high - low) * 0.768
            level8 = high

            if cross_bul(macd1, signal1) and macd1[len(macd1) - 1] < 0:
                result.append(coin)
                plots = [
                    mpf.make_addplot(macd.macd, color='#606060', panel=1, ylabel='MACD (12,26,9)', secondary_y=False),
                    mpf.make_addplot(macd.signal, color='#1f77b4', panel=1, secondary_y=False),
                    mpf.make_addplot(macd.bar_positive, type='bar', color='#4dc790', panel=1),
                    mpf.make_addplot(macd.bar_negative, type='bar', color='#fd6b6c', panel=1),
                    mpf.make_addplot(stochastic[['%D', '%SD', 'UL', 'DL']], ylim=[0, 100], panel=2, ylabel='Stoch (14,3)')
                ]

                fig, axes = mpf.plot(df,
                                     type='candle',
                                     ylabel='HAFTALIKTA MACD AL',
                                     savefig=dict(fname=coin, bbox_inches='tight'),
                                     addplot=plots,
                                     figscale=2,
                                     figratio=(7, 5),
                                     style='yahoo',
                                     panel_ratios=(4, 3, 2),
                                     returnfig=True)
                axes[0].set_title(coin, fontsize=20)  # Başlık fontunu büyüttüm.
                # Fibonacci seviyesini çiz
                axes[0].axhline(level1, color='red', linestyle='--', linewidth=1)
                # axes[0].annotate(f'{level1:.2f}', xy=(0, level1), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
                axes[0].axhline(level2, color='red', linestyle='--', linewidth=1)
                axes[0].annotate(f'{level2:.2f}', xy=(0, level2), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
                axes[0].axhline(level3, color='red', linestyle='--', linewidth=1)
                axes[0].annotate(f'{level3:.2f}', xy=(0, level3), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
                axes[0].axhline(level4, color='red', linestyle='--', linewidth=1)
                axes[0].annotate(f'{level4:.2f}', xy=(0, level4), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
                axes[0].axhline(level5, color='red', linestyle='--', linewidth=1)
                axes[0].annotate(f'{level5:.2f}', xy=(0, level5), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
                # axes[0].axhline(level6, color='red', linestyle='--', linewidth=1)
                # axes[0].annotate(f'{level6:.2f}', xy=(0, level6), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
                axes[0].axhline(level7, color='red', linestyle='--', linewidth=1)
                axes[0].annotate(f'{level7:.2f}', xy=(0, level7), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
                axes[0].axhline(level8, color='red', linestyle='--', linewidth=1)
                axes[0].annotate(f'{level8:.2f}', xy=(0, level8), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')

                # Filigran metni
                watermark_text = '@beyefend112'

                # Filigranın ekleneceği konum
                watermark_pos = (0.3, 0.2)

                # Filigranı görüntüye ekle
                fig.text(watermark_pos[0], watermark_pos[1], watermark_text,
                         fontsize=15, color='gray', alpha=0.7, ha='center', va='center',
                         transform=fig.transFigure)

                # Grafiği kaydet ve gönder
                fig.savefig(f"{coin}.png", bbox_inches='tight')
                bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'), caption=f"{zaman} grafiğinde hisse ismi= {coin} /n  >>> https://tr.tradingview.com/chart/?symbol={coin}&interval=W")

                os.remove(f"{coin}.png")

        except:
            pass

    zaman_index = (zaman_index + 1) % len(timeframe_list)  # Zaman dilimini bir sonraki değere geçir

    print(f"Macd Ort. Cross Olanlar Tarama: \n {result} \n Koşula Uygun Hisse Sayısı: {len(result)}")
    time.sleep(1)  # Bekleme süresi (saniye)


deneme
# HAFTALIKTA Macd Ort. Cross Olanlar Tarama
liste= hepsilist


def explorer(liste):

  result = []
  timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}
  zaman = '15m'
  max_len = 150
  for coin in tqdm(liste):
    try:
        df = tv.get_hist(symbol=coin,interval=timeframe_dict[f"{zaman}"],n_bars=max_len)
        macd = MACD(df, 12, 26, 9)
        macd1=  macd.macd
        signal1= macd.signal

        stochastic = Stochastic(df, 14, 3)

        # Destek ve direnç seviyelerini hesaplayın
        low = min(df.low)
        high = max(df.high)

        # Fibonacci seviyelerini hesaplayın
        level1 = low
        level2 = low + (high - low) * 0.236
        level3 = low + (high - low) * 0.382
        level4 = low + (high - low) * 0.5
        level5 = low +(high - low) * 0.618
        level6 = low + (high - low) * 0.65
        level7 = low + (high - low) * 0.768
        level8 = high

        if cross_bul(macd1,signal1) and macd1[len(macd1)-1] < 0 :
         result.append(coin)
         plots  = [
            mpf.make_addplot((macd['macd']), color='#606060', panel=1, ylabel='MACD (12,26,9)', secondary_y=False),
            mpf.make_addplot((macd['signal']), color='#1f77b4', panel=1, secondary_y=False),
            mpf.make_addplot((macd['bar_positive']), type='bar', color='#4dc790', panel=1),
            mpf.make_addplot((macd['bar_negative']), type='bar', color='#fd6b6c', panel=1),
            mpf.make_addplot((stochastic[['%D', '%SD', 'UL', 'DL']]), ylim=[0, 100], panel=2, ylabel='Stoch (14,3)')
        ]

         fig, axes = mpf.plot(df,
                     type='candle',
                     ylabel='HAFTALIKTA MACD AL',
                     savefig=dict(fname=coin, bbox_inches='tight'),
                     addplot=plots,
                     figscale=2,
                     figratio=(7, 5),
                     style='yahoo',
                     panel_ratios=(4, 3, 2),
                     returnfig=True)
         axes[0].set_title(coin, fontsize=20) # Başlık fontunu büyüttüm.
         # Fibonacci seviyesini çiz
         axes[0].axhline(level1, color='red', linestyle='--', linewidth=1)
        #  axes[0].annotate(f'{level1:.2f}', xy=(0, level1), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
         axes[0].axhline(level2, color='red', linestyle='--', linewidth=1)
         axes[0].annotate(f'{level2:.2f}', xy=(0, level2), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
         axes[0].axhline(level3, color='red', linestyle='--', linewidth=1)
         axes[0].annotate(f'{level3:.2f}', xy=(0, level3), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
         axes[0].axhline(level4, color='red', linestyle='--', linewidth=1)
         axes[0].annotate(f'{level4:.2f}', xy=(0, level4), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
         axes[0].axhline(level5, color='red', linestyle='--', linewidth=1)
         axes[0].annotate(f'{level5:.2f}', xy=(0, level5), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
        #  axes[0].axhline(level6, color='red', linestyle='--', linewidth=1)
        #  axes[0].annotate(f'{level6:.2f}', xy=(0, level6), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
         axes[0].axhline(level7, color='red', linestyle='--', linewidth=1)
         axes[0].annotate(f'{level7:.2f}', xy=(0, level7), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')
         axes[0].axhline(level8, color='red', linestyle='--', linewidth=1)
         axes[0].annotate(f'{level8:.2f}', xy=(0, level8), xytext=(5, 5), textcoords='offset points', va='bottom', fontsize=11, color='red')

# Filigran metni
         watermark_text = '@beyefend112'

# Filigranın ekleneceği konum
         watermark_pos = (0.3, 0.2)

# Filigranı görüntüye ekle
         fig.text(watermark_pos[0], watermark_pos[1], watermark_text,
         fontsize=15, color='gray', alpha=0.7, ha='center', va='center',
         transform=fig.transFigure)


         # Grafiği kaydet ve gönder
         fig.savefig(f"{coin}.png", bbox_inches='tight')
         bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'), caption=f"{zaman }  grafiğinde hisse ismi= {coin} /n  >>> https://tr.tradingview.com/chart/?symbol={coin}&interval=W")
        #  resim_att(f'{zaman }  grafikte {coin} MACD AL VERENLERİN  taranması amaçlanmıştır. İlgilenenler için Grafik Bilgisi  : https://tr.tradingview.com/chart/?symbol={coin}&interval=W >>> #bist100 #altın #dolar #destek #direnç ',f"{coin}.png")

         os.remove(f"{coin}.png")

    except:
        pass
  print(f"HAFTALIKTA Macd Ort. Cross Olanlar Tarama  : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
  # twit_at(f"HAFTALIKTA Macd Ort. Cross Olanlar Tarama  : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}{hashtag_list[i]}")

explorer(liste)

#SUPERTREND Al Verenler Tarama
liste = hisselerlist

def explorer(liste):
  result = []
  timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}
  zaman = '1d'
  max_len = 150

  for coin in tqdm(liste):
    try:
        df = tv.get_hist(symbol=coin,interval=timeframe_dict[f"{zaman}"],n_bars=max_len)
        supertrend = Supertrend(df, atr_period, atr_multiplier)
        if len(df) == 0: continue
        supertrend = Supertrend(df, atr_period, atr_multiplier)
        df = df.join(supertrend)
        if not supertrend['Supertrend'][-2] and supertrend['Supertrend'][-1]:
          result.append(coin)
          plots  = [
    mpf.make_addplot(df['Final Lowerband'],color='#1d9300',markersize=200,marker='^'),
    mpf.make_addplot(df['Final Upperband'],color='#ef0000',markersize=200,marker='v'),]

          mpf.plot(df,type='candle',addplot=plots,savefig=dict(fname=coin ,bbox_inches='tight') ,figscale=2,figratio=(7,5),axtitle=coin,style='yahoo',returnfig=True,volume=True
)
          bot.sendPhoto(id,photo=open(f"{coin}.png", 'rb'))
          os.remove(f"{coin}.png")
          # resim_att(f'SUPERTREND AL VERENLER Tarama Sonuçları. İlgili Hissenin Finansal Bilgileri: https://tr.tradingview.com/symbols/{coin} \n #{coin} .',f"{coin}.png")
    except:
        pass
  print(f"SUPERTREND AL VERENLER Tarama  : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
  mesaj_at(f"SUPERTREND AL VERENLER Tarama  : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')
  # mesaj_at(f"SUPERTREND AL VERENLER Tarama : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '-1001794193133')
  # twit_at(f"SUPERTREND AL VERENLER Tarama  : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")

explorer(liste)
#calısan trend çizgisi kodu
#Hangi liste?
liste = hisselerlist

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}
result= []
zaman = '4h'
max_len = 150
while True:
    for symbol in tqdm(liste):
        try:
            data = tv.get_hist(symbol=symbol,interval=timeframe_dict[f"{zaman}"],n_bars=max_len)

            df = data

            df["date"] = pd.to_datetime(df.index, unit='s')

            df.index = pd.date_range(str(df["date"][0]), periods=len(df), freq='D')

            df["date"] = pd.to_datetime(df.index, unit='s')

            df["rsi"] = ta.momentum.rsi(df["close"], window=14)
            df["open_norm"], df["high_norm"], df["low_norm"], df["close_norm"] = norm(df["open"], df["high"], df["low"], df["close"])
            df["open"], df["high"], df["low"], df["close"] = norm(df["open"], df["high"], df["low"], df["close"])

            for order in [130,125,120,110,100,90,80,70,60,50,40,35,30,25,20,18,16,14,12,10,8]:
                try:

                    high = signal.argrelextrema(np.array(df["high"]), np.greater_equal, order=order)
                    high = high[0]

                    low = signal.argrelextrema(np.array(df["low"]), np.less_equal, order=order)
                    low = low[0]

                    if high[-1] > low[-1]:

                        index = high
                        val = df["high"][index]

                        slope = linregress([index[-3], index[-2]], [val[-3], val[-2]])

                        if val[-1] < val[-2] < val[-3] and df["close"][-1] > slope[0]*(len(df)-1) + slope[1] and val[-1] > slope[0]*(index[-1]) + slope[1] and slope[0]*(len(df) - 1) + slope[1] > df["close"][-1]-5:
                            result.append(symbol)
                            index_ = [index[-3], len(df)-1]

                            val_ = [slope[0]*(index[-3]) + slope[1], slope[0]*(len(df) - 1) + slope[1]]
                            fig, ax = plt.subplots(figsize=(7,5))
                            candlestick_ohlc(ax, zip(mdates.date2num(df.index.to_pydatetime()), df["open"], df["high"], df["low"], df["close"]), width=0.6, colorup='green', colordown='red')
                            plt.plot(df.index[index_], val_, 'r-')
                            ax.xaxis.set_visible(False)
                            ax.yaxis.set_visible(False)
                            plt.ylabel('Fiyat')
                            plt.title(f'{symbol}')
                            plt.figtext(0.95, 0.05, 'Grafik otomatik oluşturulmuştur.Aksiliklerde dikkate almayın.               (@beyefend112)', fontsize=10, color='gray', ha='right', va='bottom', alpha=0.7)
                            plt.show()
                            fig.savefig(f"{symbol}.png", bbox_inches='tight')
                            bot.sendPhoto(id, photo=open(f"{symbol}.png", 'rb'), caption=f"{zaman }  grafiğinde hisse ismi= {symbol} /n  >>> https://tr.tradingview.com/chart/?symbol={symbol}")
                            # resim_att(f'{zaman }  grafikte {symbol} Düşeni Kıranlar ve Retest yapanların taranması amaçlanmıştır. İlgilenenler için Grafik Bilgisi : https://tr.tradingview.com/chart/?symbol={symbol}',f"{symbol}.png")
                            os.remove(f"{symbol}.png")
                            break


                except Exception as e:
                    pass


        except Exception as e:
            print(e)
    print(f" {zaman }  GRAFİKTE Düşeni Kıranlar Yada Retest Yapanlar : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    result.clear()
    # if len(df) >= max_len:
    #     max_len -= 1
    #     del df[-1]
    # else:
    #     break
#Bollinger alt bandında olan hisseler
liste = hisselerlist


def explorer(liste):
    value = 0
    value2 = 1
    result = []
    timeframe_dict = {"1m": Interval.in_1_minute, "m": Interval.in_5_minute, "15m": Interval.in_15_minute,
                      "30m": Interval.in_30_minute, "1h": Interval.in_1_hour, "2h": Interval.in_2_hour,
                      "4h": Interval.in_4_hour, "1d": Interval.in_daily, "1w": Interval.in_weekly,
                      "m": Interval.in_monthly}
    zaman = '1d'
    max_len = 200
    for coin in tqdm(liste):
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"], n_bars=max_len)
            hb = ta.volatility.bollinger_hband(df.close, 20, 2)
            bb = ta.volatility.bollinger_lband(df.close, 20, 2)
            ob = ta.volatility.bollinger_mavg(df.close, 20)
            kri = 100 * (df['close'] - bb) / bb
            if value < kri[len(kri) -1] < value2:
                result.append(coin)
                plots = [
                    mpf.make_addplot(hb, panel=0, color='blue', secondary_y=False),
                    mpf.make_addplot(bb, panel=0, color='blue', secondary_y=False),
                    mpf.make_addplot(ob, panel=0, color='purple', secondary_y=False)
                ]

                fig, axes = mpf.plot(df,
                                     type='candle',
                                     ylabel='Bollinger Al Verenler ',
                                     savefig=dict(fname=coin, bbox_inches='tight'),
                                     addplot=plots,
                                     figscale=2,
                                     figratio=(7, 5),
                                     style='yahoo',
                                     returnfig=True,volume=True)
                axes[0].set_title(coin, fontsize=20) # Başlık fontunu büyüttüm.


                # Filigran metni
                watermark_text = '@beyefend112'

                # Filigranın ekleneceği konum
                watermark_pos = (0.3, 0.2)

                # Filigranı görüntüye ekle
                fig.text(watermark_pos[0], watermark_pos[1], watermark_text,
                         fontsize=15, color='gray', alpha=0.7, ha='center', va='center',
                         transform=fig.transFigure)

                # Grafiği kaydet ve gönder
                fig.savefig(f"{coin}.png", bbox_inches='tight')
                bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'),
                              caption=f"{zaman} grafiğinde hisse ismi= {coin} /n >>> https://tr.tradingview.com/chart/?symbol={coin}&interval=D")
                resim_att(f'{zaman }  grafikte {coin} Bollinger alt bandına yakınlık taranması amaçlanmıştır. İlgilenenler için Grafik Bilgisi : https://tr.tradingview.com/chart/?symbol={coin}&interval=D    >>>>> #bist100 #altın #dolar #destek #direnç ',f"{coin}.png")


                os.remove(f"{coin}.png")

        except:
            pass
    print(
        f" Bollinger Alt Bandında Olanlar Tarama  : \n {result} \n Koşula Uygun His Sayısı : {len(result)}")

explorer(liste)
def explorer(perplist):
  result_df = pd.DataFrame(columns=['Coin', 'SMA111 Yakınlık','SMA350 YAKINLIK','Yakınlık'])
  value = -15
  value2 = 15
  for coin in tqdm(perplist):
    try:
        df = tv.get_hist(symbol=coin ,exchange = 'BINANCE', interval=Interval.in_daily,n_bars=400)
        sma111 = ta.sma(df['close'],111)
        sma350 = ta.sma(df['close'],350)
        kri111 = 100 * (df['close'] - sma111) / sma111
        kri350 = 100 * (df['close'] - sma350) / sma350
        yakınlık = 100 * (sma350 - sma111) / sma111
        if value < kri111[len(kri111)-1] < value2:
         result_df = result_df.append({'Coin': coin, 'SMA111 Yakınlık': kri111[-1],'SMA350 YAKINLIK': kri350[-1],'Yakınlık': yakınlık[-1]}, ignore_index=True)
         result_df.to_excel("hepsi.xlsx")
    except:
        pass



explorer(perplist)

# HAREKETLİ ORTALAMAYA YAKINLIK TARAMASI
#Hangi liste?
liste = perplist

metin = 'Aylık Grafikte Sma111'

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}

zaman = '15m'

def explorer(liste):
    result = []
    value = -1
    value2 = 1
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 10:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"],n_bars=200)
            sma = ta.sma(df['close'], 111)
            kri = 100 * (df['close'] - sma) / sma
            if value < kri[len(kri)-1] < value2:
                result.append(coin)
                mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin}', figsize=(6, 6),
                         savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                         type='candle', mav=111, style='yahoo')
                bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin} %{value2} Değerine yakınlıkta olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    mesaj_at(f"{metin} DEĞERİNE %{value2} yakınlıkta olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')

explorer(liste)
#calısan trend çizgisi kodu
#Hangi liste?
liste = hisselerlist

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}
result= []
zaman = '15m'

for symbol in tqdm(liste):
    try:
        data = tv.get_hist(symbol=symbol,interval=timeframe_dict[f"{zaman}"],n_bars=80)

        df = data

        df["date"] = pd.to_datetime(df.index, unit='s')

        df.index = pd.date_range(str(df["date"][0]), periods=len(df), freq='D')

        df["date"] = pd.to_datetime(df.index, unit='s')

        df["rsi"] = ta.momentum.rsi(df["close"], window=14)
        df["open_norm"], df["high_norm"], df["low_norm"], df["close_norm"] = norm(df["open"], df["high"], df["low"], df["close"])
        df["open"], df["high"], df["low"], df["close"] = norm(df["open"], df["high"], df["low"], df["close"])

        for order in [100,90,80,70,60,50,40,35,30,25,20,18,16,14,12,10,8]:
            try:

                high = signal.argrelextrema(np.array(df["high"]), np.greater_equal, order=order)
                high = high[0]

                low = signal.argrelextrema(np.array(df["low"]), np.less_equal, order=order)
                low = low[0]

                if high[-1] > low[-1]:

                    index = high
                    val = df["high"][index]

                    slope = linregress([index[-3], index[-2]], [val[-3], val[-2]])

                    if val[-1] < val[-2] < val[-3] and df["close"][-1] > slope[0]*(len(df)-1) + slope[1] and val[-1] > slope[0]*(index[-1]) + slope[1] and slope[0]*(len(df) - 1) + slope[1] > df["close"][-1]-5:
                     result.append(symbol)
                     index_ = [index[-3], len(df)-1]

                     val_ = [slope[0]*(index[-3]) + slope[1], slope[0]*(len(df) - 1) + slope[1]]
                     fig, ax = plt.subplots(figsize=(7,5))
                     candlestick_ohlc(ax, zip(mdates.date2num(df.index.to_pydatetime()), df["open"], df["high"], df["low"], df["close"]), width=0.6, colorup='green', colordown='red')
                     plt.plot(df.index[index_], val_, 'r-')
                     ax.xaxis.set_visible(False)
                     ax.yaxis.set_visible(False)
                     plt.ylabel('Fiyat')
                     plt.title(f'{symbol}')
                     plt.figtext(0.95, 0.05, 'Grafik otomatik oluşturulmuştur.Aksiliklerde dikkate almayın.               (@beyefend112)', fontsize=10, color='gray', ha='right', va='bottom', alpha=0.7)
                     plt.show()
                     fig.savefig(f"{symbol}.png", bbox_inches='tight')
                     bot.sendPhoto(id, photo=open(f"{symbol}.png", 'rb'), caption=f"{zaman }  grafiğinde hisse ismi= {symbol} /n  >>> https://tr.tradingview.com/chart/?symbol={symbol}")
                     resim_att(f'{zaman }  grafikte {symbol} Düşeni Kıranlar ve Retest yapanların taranması amaçlanmıştır. İlgilenenler için Grafik Bilgisi : https://tr.tradingview.com/chart/?symbol={symbol}',f"{symbol}.png")
                     os.remove(f"{symbol}.png")
                     break


            except Exception as e:
                pass


    except Exception as e:
        print(e)
print(f" {zaman }  GRAFİKTE Düşeni Kıranlar Yada Retest Yapanlar : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")



# #calısan excel gonderme kodu otomatik.
# liste = hepsilist

# # Bot Token, Api ID ve Api Hash bilgilerinizi girin
# bot_token = token
# api_id = "25573567"
# api_hash = "f4dec55bf37c0cd9b6ee8d067a82a9c9"

# client = TelegramClient("session_name", api_id, api_hash)

# async def excelgonder():
#     # Göndermek istediğiniz sohbetin ID'sini girin.
#     chat_id = 860174169

#     # Göndermek istediğiniz dosyanın yerel dizinini girin.
#     file_path = "/content/hepsi.xlsx"

#     # Dosyayı gönderin.
#     await client.send_file(chat_id, file_path)

# async def exploper(liste):
#     result_df = pd.DataFrame(columns=['Coin', 'SMA111 Yakınlık','SMA350 YAKINLIK','Yakınlık'])
#     value = -15
#     value2 = 15
#     for coin in tqdm(liste):
#         try:
#             df = tv.get_hist(symbol=coin ,exchange = 'BINANCE', interval=Interval.in_daily,n_bars=400)
#             sma111 = ta.sma(df['close'],111)
#             sma350 = ta.sma(df['close'],350)
#             kri111 = 100 * (df['close'] - sma111) / sma111
#             kri350 = 00 * (df['close'] - sma350) / sma350
#             yakınlık = 100 * (sma350 - sma111) / sma111
#             if value < kri111[len(kri111)-1] < value2:
#                 result_df = result_df.append({'Coin': coin, 'SMA111 Yakınlık': kri111[-1],'SMA350 YAKINLIK': kri350[-1],'Yakınlık': yakınlık[-1]}, ignore_index=True)
#         except:
#             pass
#     result_df.to_excel("hepsi.xlsx")
#     await excelgonder()

# # Telegram istemcisini başlatın
# await client.start(bot_token=bot_token)

# # Explorer fonksiyonunu çalıştırın
# await explorer(liste)

# # Telegram istemcisini kapatın
# await client.disconnect()
#Hangi liste?
liste = hepsilist

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}
result= []
zaman = '1d'

def explorer(liste):
  result_df = pd.DataFrame(columns=['Coin', 'SMA111 Yakınlık','SMA350 YAKINLIK','Yakınlık'])
  value = -15
  value2 = 15
  for coin in tqdm(liste):
    try:
        df = tv.get_hist(symbol=symbol,exchange='BINANCE', interval=timeframe_dict[f"{zaman}"],n_bars=400)
        sma111 = ta.sma(df['close'],111)
        sma350 = ta.sma(df['close'],350)
        kri111 = 100 * (df['close'] - sma111) / sma111
        kri350 = 100 * (df['close'] - sma350) / sma350
        yakınlık = 100 * (sma350 - sma111) / sma111
        if value < kri111[len(kri111)-1] < value2:
         result_df = result_df.append({'Coin': coin, 'SMA111 Yakınlık': kri111[-1],'SMA350 YAKINLIK': kri350[-1],'Yakınlık': yakınlık[-1]}, ignore_index=True)
         result_df.to_excel("hepsi.xlsx")
    except:
        pass



explorer(liste)


#Alpha Trend AL Verenler

liste = hepsilist

metin = 'Alpha Trend Al'

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}

zaman = '1d'
def explorer(liste):
  result = []
  value = -1
  value2 = 1
  for coin in tqdm(liste):
    try:
        df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"],n_bars=200)
        df.drop('symbol',axis=1, inplace=True)
        df["date"] = df.index
        df["rsi"] = ta.momentum.rsi(df["close"], window=14)
        mfi = ta.volume.MFIIndicator(df["high"], df["low"], df["close"], df["volume"], window=14)
        df["mfi"] = mfi.money_flow_index()

        at = alphaTrend(df)

        df["k1"] = at["k1"].values

        df["k2"] = at["k2"].values

        df = df.tail(100)

        if df["k1"][-1] > df["k2"][-1] and df["k1"][-2] <= df["k2"][-2]:
         result.append(coin)
         addplot=[
                mpf.make_addplot(df["k1"], color='blue', width=1),
                mpf.make_addplot(df["k2"], color='red', width=1)
            ]
         mpf.plot(
                df,
                axtitle=coin,
                ylabel_lower=f' {metin}',
                figsize=(6, 6),
                savefig=dict(fname=coin, bbox_inches='tight'),
                volume=True,
                ylabel=str(coin),
                type='candle',
                style='yahoo',
                addplot=addplot,
                panel_ratios=(1, 0.3)
            )

         bot.sendPhoto(id,photo=open(f"{coin}.png", 'rb'))



    except:
        pass
  print(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
  mesaj_at(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')

explorer(liste)

#wto TARAMA YAPMA KISMI

liste = hep

metin = 'Wto Taraması Al'

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}

zaman = '1d'
def explorer(hisselerlist):
  result = [] #boş liste demek.
  value = -5
  value2 = 5
  for coin in hisselerlist:
    try:
        df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"],n_bars=200)
        # sma = ta.sma(df['close'],21)
        wto= TA.WTO(df,channel_lenght=10,average_lenght=21)
        kri = 100 * (-50 -  wto [ 'WT1.']) /  wto [ 'WT1.']
        if value < kri[len(kri)-1] < value2:
         result.append(coin)
        #  mpf.plot(df, axtitle = coin ,ylabel_lower='HAFTALIK SMA21 Yakınlık', figsize=(6,6) , savefig=dict(fname=coin ,bbox_inches='tight')  ,volume= True, ylabel= str(coin)  ,type='candle',mav = 21 , style='yahoo')
        #  bot.sendPhoto(id,photo=open(f"{coin}.png", 'rb'))
        #  resim_att(f'HAFTALIK GRAFİKTE {coin} SMA21  Değerini Grafiğe İşledim. 21 HAFTALIK Hareketli Ortalama Değerine Yakınlık taranması amaçlanmıştır. İlgilenenler için Grafik Bilgisi : https://tr.tradingview.com/chart/?symbol={coin}',f"{coin}.png")
    except:
        pass
  print(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
  mesaj_at(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')

  # mesaj_at(f"HAFTALIK GRAFİKTE SMA21 DEĞERİNE %{value2} yakınlıkta olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '-1001794193133')
  # twit_at(f"HAFTALIK GRAFİKTE SMA21 DEĞERİNE %{value2} yakınlıkta olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")

explorer(hisselerlist)
for coin in tqdm(perplist):
  bars= tv.get_hist(symbol=coin,  interval=Interval.in_daily,n_bars=400)

bars['previous_close'] = bars['close'].shift(1)
bars
filtered = bars[bars.index.strftime('%Y-%m-%d') == today.isoformat()].copy()
filtered
bars['percent'] = bars['open'] / bars['previous_close']
bars
gap_ups = bars[bars['percent'] > 1.03]
gap_ups
gap_downs = bars[bars['percent'] < 0.98]
gap_downs
gap_down_symbols = gap_downs['symbol'].tolist()
gap_down_symbols
# HAREKETLİ ORTALAMAYA YAKINLIK TARAMASI
#Hangi liste?
liste = hisselerlist

metin = 'GAP BOŞLUKLUGU OLANLAR'

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}

zaman = '1d'

def explorer(liste):
    result = []
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 20:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"],n_bars=200)
            df['previous_close'] = df['close'].shift(1)
            df['percent'] = df['open'] / df['previous_close']
            gap_ups = df[df['percent'] > 1.03]
            gap_downs = df[df['percent'] < 0.98]

            if not gap_ups.empty:
              result.append(coin)
              mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin}', figsize=(6, 6),
             savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
             type='candle', style='yahoo')
              bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    mesaj_at(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')

explorer(liste)
# HAREKETLİ ORTALAMAYA YAKINLIK TARAMASI
# Hangi liste?
liste = hisselerlist

metin = 'GAP BOŞLUKLUGU OLANLAR'

timeframe_dict = {"1m": Interval.in_1_minute, "5m": Interval.in_5_minute, "15m": Interval.in_15_minute,
                  "30m": Interval.in_30_minute, "1h": Interval.in_1_hour, "2h": Interval.in_2_hour,
                  "4h": Interval.in_4_hour, "1d": Interval.in_daily, "1w": Interval.in_weekly,
                  "m": Interval.in_monthly}

zaman = '1d'


def explorer(liste):
    result = []
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 10:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"], n_bars=200)
            df['previous_close'] = df['close'].shift(1)
            df['percent'] = df['open'] / df['previous_close']
            gap_ups = df[df['percent'] > 1.03]
            gap_downs = df[df['percent'] < 0.98]

            if not gap_ups.empty:
                gap_ups_below_sma = gap_ups[gap_ups['low'] < gap_ups['open']]
                if not gap_ups_below_sma.empty:
                    result.append(coin)
                    mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin}', figsize=(6, 6),
                             savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                             type='candle', style='yahoo')
                    bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
            elif not gap_downs.empty:
                gap_downs_below_sma = gap_downs[gap_downs['low'] < gap_downs['open']]
                if not gap_downs_below_sma.empty:
                    result.append(coin)
                    mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin}', figsize=(8, 8),
                             savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                             type='candle', style='yahoo')
                    bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    mesaj_at(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')


explorer(liste)
# HAREKETLİ ORTALAMAYA YAKINLIK TARAMASI
# Hangi liste?
liste = hisselerlist

metin = 'GAP BOŞLUKLUGU OLANLAR'

timeframe_dict = {"1m": Interval.in_1_minute, "5m": Interval.in_5_minute, "15m": Interval.in_15_minute,
                  "30m": Interval.in_30_minute, "1h": Interval.in_1_hour, "2h": Interval.in_2_hour,
                  "4h": Interval.in_4_hour, "1d": Interval.in_daily, "1w": Interval.in_weekly,
                  "m": Interval.in_monthly}

zaman = '4h'


def explorer(liste):
    result = []
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 10:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"], n_bars=150)
            df['previous_close'] = df['close'].shift(1)
            df['percent'] = df['open'] / df['previous_close']
            gap_ups = df[df['percent'] > 1.03]
            gap_downs = df[df['percent'] < 0.98]

            if not gap_ups.empty:
                gap_ups_below_sma = gap_ups[gap_ups['low'] < gap_ups['open']]
                if not gap_ups_below_sma.empty:
                    result.append(coin)
                    gap_size = round((gap_ups_below_sma['open'] - gap_ups_below_sma['low']) * 100 / gap_ups_below_sma['open'], 2)
                    mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin} - Gap size: {gap_size}%', figsize=(10, 10),
                             savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                             type='candle', style='yahoo')
                    bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
            elif not gap_downs.empty:
                gap_downs_below_sma = gap_downs[gap_downs['low'] < gap_downs['open']]
                if not gap_downs_below_sma.empty:
                    result.append(coin)
                    gap_size = round((gap_downs_below_sma['open'] - gap_downs_below_sma['low']) * 100 / gap_downs_below_sma['open'], 2)
                    mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin} - Gap size: {gap_size}%', figsize=(8, 8),
                             savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                             type='candle', style='yahoo')
                    bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    mesaj_at(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')


explorer(liste)
# Hangi liste?
liste = hisselerlist

metin = 'GAP BOŞLUKLUGU OLANLAR'

timeframe_dict = {"1m": Interval.in_1_minute, "5m": Interval.in_5_minute, "15m": Interval.in_15_minute,
                  "30m": Interval.in_30_minute, "1h": Interval.in_1_hour, "2h": Interval.in_2_hour,
                  "4h": Interval.in_4_hour, "1d": Interval.in_daily, "1w": Interval.in_weekly,
                  "m": Interval.in_monthly}

zaman = '4h'


def explorer(liste):
    result = []
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 50:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"], n_bars=150)
            gap_ups = df[(df['open'] > df['high'].shift(1)) & (df['open'] > df['close'].shift(1)) & ((df['open'] - df['high'].shift(1))/df['high'].shift(1) > 0.05)]
            gap_downs = df[(df['open'] < df['low'].shift(1)) & (df['open'] < df['close'].shift(1)) & ((df['low'].shift(1) - df['open'])/df['low'].shift(1) > 0.05)]

            if not gap_ups.empty:
                result.append(coin)
                gap_size = round((gap_ups['open'] - gap_ups['high'].shift(1)) * 100 / gap_ups['high'].shift(1), 2)
                mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin} - Gap size: {gap_size}%', figsize=(10, 10),
                         savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                         type='candle', style='yahoo')
                bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
            elif not gap_downs.empty:
                result.append(coin)
                gap_size = round((gap_downs['low'].shift(1) - gap_downs['open']) * 100 / gap_downs['low'].shift(1), 2)
                mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin} - Gap size: {gap_size}%', figsize=(8, 8),
                         savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                         type='candle', style='yahoo')
                bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin}  olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    #mesaj_at(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı)
def explorer(liste):
    result = []
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 20:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"],n_bars=200)
            df['previous_close'] = df['close'].shift(1)
            df['percent'] = df['open'] / df['previous_close']
            gap_ups = df[df['percent'] > 1.05]
            gap_downs = df[df['percent'] < 0.90]

            if not gap_ups.empty and any(gap_ups['percent'] > 1.05):
                result.append(coin)
                mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin}', figsize=(6, 6),
                savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                type='candle', style='yahoo')
                bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    mesaj_at(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')

explorer(liste)
# Hangi liste?
liste = hisselerlist

metin = 'GAP BOŞLUKLUGU OLANLAR'

timeframe_dict = {"1m": Interval.in_1_minute, "5m": Interval.in_5_minute, "15m": Interval.in_15_minute,
                  "30m": Interval.in_30_minute, "1h": Interval.in_1_hour, "2h": Interval.in_2_hour,
                  "4h": Interval.in_4_hour, "1d": Interval.in_daily, "1w": Interval.in_weekly,
                  "m": Interval.in_monthly}

zaman = '1d'


def explorer(liste):
    result = []
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 20:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"],n_bars=200)
            df['previous_close'] = df['close'].shift(1)
            df['percent'] = df['open'] / df['previous_close']
            gap_ups = df[df['percent'] > 1.10]
            gap_downs = df[df['percent'] < 0.90]

            if not gap_ups.empty and any(gap_ups['percent'] > 1.10):
                result.append(coin)
                mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin}', figsize=(6, 6),
                savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                type='candle', style='yahoo')
                bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    mesaj_at(f"{metin} olan Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')

explorer(liste)
1- bolinger bands (30-2 olarak güncelle,arka planı kaldır, aşagıyı yeşil üst çizgiyi kırmızı yap.)
2-supertrend(10-1 şeklinde güüncelle,super trend çizgisini kapat, elmas yap)
3- stokastik rsi(8-10-3-3 şekliinde,100 ve 0 olarak değiştiriyoruz.arka planı kapat. çizgi yap)
4- rsi(13 yap.beyaz çizgi yap.arka planı kapat. çizgileri kırmızı yap üst alt bandı.
5-tekrar stokastik rsi(değerler aynı,stil bölümüünde 90-10 yap değerleri. çizgi yap beyaz beyaz seç arka plan kapat.)
6- trix indikatörü(çizgiyi beyaz yap. ve çizgi haline getir.)
7- cci indikatörü(ayarlar aynı stilde 90 a -90 yap.çizgiyi beyaz yap yukarı limit kırmızı aşagısı yeşil olsun.)
8-macd(orjinal ayarlar,stilde aynı.)
9-willliams r(ayarını 10 yap. stil 0 a -20 olcak.çizgi renklerini kırmızı yap limitleri ve arka planı kırmızı yap ve saydamlk arttır.sonrasında plot çizgisinin seffaflıgını 0 yap)
10- williams r(inputs 10 olcak yeşil çizgi olcak-70 e -90 şeklnde beyaz çizgi olacak.
11- adx indikatörü(14-14 kalacak..)
nasıl long sinyali alınır.??
1- mumlar bolinger bandının altına sarkmalı ve mum kapatmış olmalı
2- stokastik mavi çizgi -0.0 olmalı truncu çizgi önemli değil.
3-rsi beyaz çizgi 30 seviyesinin altındaysa sinyal devam.
4-stokastik rsi 10 çizgissinin altında mavi sarıyı yukarı keserse al siinyali veriyor.
5-trix düz çizginin altıındaysa devam, trix ne kaadr altındaysa o kadar iyi sinyal our.
6- cci indikatörü beyaz çizginin yeşil çizginin altına giriip bir süre sonra yeşil çizgiyi yukarı keserse al sinyalini verir.
7-macd çizgisi 0ın altında turuncu üste mavi altta olunca sinyal gelir.
8- william r da -90 altına gidecek sonra yeşil çizginin üstüne cıkınca sinyal gelir.
! pip install pandas_ta
import pandas as pd
import pandas_ta as ta
def cross_bul (seris_a,series_b):
  pre_short = seris_a[len(seris_a)-2]
  short = seris_a[len(seris_a)-1]
  pre_long = series_b[len(series_b)-2]
  long = series_b[len(series_b)-1]

  if pre_short < pre_long and short > long:
    return True
  else :
    return False
# HAREKETLİ ORTALAMAYA YAKINLIK TARAMASI
#Hangi liste?
liste = hepsilist

metin = 'Sistemime Uyan '

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}

zaman = '1d'

def explorer(liste):
    result = []
    value = -1
    value2 = 1
    for i, coin in enumerate(tqdm(liste, desc='Tarama İşlemi Başlatıldı.', leave=False)):
        if i >= 150:
            break
        try:
            df = tv.get_hist(symbol=coin, interval=timeframe_dict[f"{zaman}"],n_bars=200)
            bb=ta.bbands(df.close,30,2)['BBL_30_2.0']   # Bollinger alt bandı
            srsi=ta.stochrsi(df.close,d=3,k=3,length=10,rsi_length=8)['STOCHRSIk_10_8_3_3'] #strsi değeri ½k değeri 0.00 olmalı.
            k=ta.stochrsi(df.close,d=3,k=3,length=14,rsi_length=14)['STOCHRSIk_14_14_3_3']
            d=ta.stochrsi(df.close,d=3,k=3,length=14,rsi_length=14)['STOCHRSId_14_14_3_3']
            rsi=ta.rsi(df.close,13) #rsi değeri 30un altında olacak.
            if  df.close[len(df.close)-1] < bb[len(bb)-1] and round(srsi[-1]) == 0 and rsi[len(rsi)-1] <= 30 and round(k[-1], 2) < 10 and round(d[-1], 2) < 10 :


             result.append(coin)
             mesaj_at(f"{metin}  Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')


                # # mpf.plot(df, axtitle=coin, ylabel_lower=f' {metin}', figsize=(6, 6),
                #          savefig=dict(fname=coin, bbox_inches='tight'), volume=True, ylabel=str(coin),
                #          type='candle', mav=111, style='yahoo')
                # # bot.sendPhoto(id, photo=open(f"{coin}.png", 'rb'))
        except:
            pass
    print(f"{metin}  Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    mesaj_at(f"{metin}  Hisseler : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}", '860174169')

explorer(liste)
df = tv.get_hist("BIST:ADEL",interval=Interval.in_daily,n_bars=300)
bb=ta.bbands(df.close,30,2)['BBL_30_2.0']
print(bb)

df = tv.get_hist("BIST:ADEL",interval=Interval.in_daily,n_bars=300)
k=ta.stochrsi(df.close,d=3,k=3,length=14,rsi_length=14)['STOCHRSIk_14_14_3_3']
d=ta.stochrsi(df.close,d=3,k=3,length=14,rsi_length=14)['STOCHRSId_14_14_3_3']
# print(k[-1])
round(k[-1],2)

ta.stochrsi(df.close,d=3,k=3,length=10,rsi_length=8)['STOCHRSId_10_8_3_3']
df = tv.get_hist("BIST:ADEL",interval=Interval.in_daily,n_bars=300)
rsi=ta.rsi(df.close,13)
print(rsi)

help(ta.trix)
df = tv.get_hist("BIST:KOZAL",interval=Interval.in_daily,n_bars=300)
trix=ta.trix(df.close,18)*100
print(trix)

pip install --upgrade ta

df = tv.get_hist("BIST:ADEL",interval=Interval.in_daily,n_bars=100)

def trix_indicator(df, length=18):
    log_close = pd.Series(df['close'].apply(lambda x: math.log(x)))
    ema1 = ta.ema(log_close, length)
    ema2 = ta.ema(ema1, length)
    ema3 = ta.ema(ema2, length)
    trix = 10000 * ema3.pct_change()


    return trix

trix = trix_indicator(df)
print(trix)
import pandas as pd
from ta import add_all_ta_features
df = tv.get_hist("BIST:KOZAL",interval=Interval.in_daily,n_bars=100)

taa.trend.trix(df.close, window=18, fillna=False)*100

df = tv.get_hist("BIST:KOZAL",interval=Interval.in_daily,n_bars=100)
adx=ta.adx(df.high,df.low,df.close)
print(adx)


#calısan trend çizgisi kodu
#Hangi liste?
liste = hisselerlist

timeframe_dict = {"1m":Interval.in_1_minute, "5m":Interval.in_5_minute, "15m":Interval.in_15_minute, "30m":Interval.in_30_minute, "1h":Interval.in_1_hour, "2h":Interval.in_2_hour, "4h":Interval.in_4_hour, "1d":Interval.in_daily, "1w":Interval.in_weekly, "m":Interval.in_monthly}
result= []
zaman = '1d'
max_len = 150
while True:
    for symbol in tqdm(liste):
        try:
            data = tv.get_hist(symbol=symbol,interval=timeframe_dict[f"{zaman}"],n_bars=max_len)

            df = data

            df["date"] = pd.to_datetime(df.index, unit='s')

            df.index = pd.date_range(str(df["date"][0]), periods=len(df), freq='D')

            df["date"] = pd.to_datetime(df.index, unit='s')

            df["rsi"] = ta.momentum.rsi(df["close"], window=14)
            df["open_norm"], df["high_norm"], df["low_norm"], df["close_norm"] = norm(df["open"], df["high"], df["low"], df["close"])
            df["open"], df["high"], df["low"], df["close"] = norm(df["open"], df["high"], df["low"], df["close"])

            for order in [130,125,120,110,100,90,80,70,60,50,40,35,30,25,20,18,16,14,12,10,8]:
                try:

                    high = signal.argrelextrema(np.array(df["high"]), np.greater_equal, order=order)
                    high = high[0]

                    low = signal.argrelextrema(np.array(df["low"]), np.less_equal, order=order)
                    low = low[0]

                    if high[-1] > low[-1]:

                        index = high
                        val = df["high"][index]

                        slope = linregress([index[-3], index[-2]], [val[-3], val[-2]])

                        if val[-1] < val[-2] < val[-3] and df["close"][-1] > slope[0]*(len(df)-1) + slope[1] and val[-1] > slope[0]*(index[-1]) + slope[1] and slope[0]*(len(df) - 1) + slope[1] > df["close"][-1]-5:
                            result.append(symbol)
                            index_ = [index[-3], len(df)-1]

                            val_ = [slope[0]*(index[-3]) + slope[1], slope[0]*(len(df) - 1) + slope[1]]
                            fig, ax = plt.subplots(figsize=(7,5))
                            candlestick_ohlc(ax, zip(mdates.date2num(df.index.to_pydatetime()), df["open"], df["high"], df["low"], df["close"]), width=0.6, colorup='green', colordown='red')
                            plt.plot(df.index[index_], val_, 'r-')
                            ax.xaxis.set_visible(False)
                            ax.yaxis.set_visible(False)
                            plt.ylabel('Fiyat')
                            plt.title(f'{symbol}')
                            plt.figtext(0.95, 0.05, 'Grafik otomatik oluşturulmuştur.Aksiliklerde dikkate almayın.               (@beyefend112)', fontsize=10, color='gray', ha='right', va='bottom', alpha=0.7)
                            plt.show()
                            fig.savefig(f"{symbol}.png", bbox_inches='tight')
                            bot.sendPhoto(id, photo=open(f"{symbol}.png", 'rb'), caption=f"{zaman }  grafiğinde hisse ismi= {symbol} /n  >>> https://tr.tradingview.com/chart/?symbol={symbol}")
                            # resim_att(f'{zaman }  grafikte {symbol} Düşeni Kıranlar ve Retest yapanların taranması amaçlanmıştır. İlgilenenler için Grafik Bilgisi : https://tr.tradingview.com/chart/?symbol={symbol}',f"{symbol}.png")
                            os.remove(f"{symbol}.png")
                            break


                except Exception as e:
                    pass


        except Exception as e:
            print(e)
    print(f" {zaman }  GRAFİKTE Düşeni Kıranlar Yada Retest Yapanlar : \n {result} \n Koşula Uygun Hisse Sayısı : {len(result)}")
    result.clear()
    # if len(df) >= max_len:
    #     max_len -= 1
    #     del df[-1]
    # else:
    #     break

df = tv.get_hist("BIST:ADEL",interval=Interval.in_daily,n_bars=100)
# bb = ta.bbands(df.close,20,2)['BBL_20_2.0'] ## bolinger alt çizgisinin verisini çektim.
hb = ta.volatility.bollinger_hband(df.close,20,2)
lb = ta.volatility.bollinger_lband(df.close,20,2)
ob = ta.volatility.bollinger_mavg(df.close,20)


bbb=  ['BIST:ANSGR', 'BIST:DAGHL', 'BIST:ENSRI', 'BIST:SUWEN']

