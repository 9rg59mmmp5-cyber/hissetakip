import numpy as np
import pandas as pd
from datetime import datetime
import telepot
import time
import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from tvDatafeed import TvDatafeed, Interval
from mplfinance.original_flavor import candlestick_ohlc

# -----------------------------------------------------------------------------
# AYARLAR
# -----------------------------------------------------------------------------
BOT_TOKEN = "5747202724:AAHLfOnWPZE0TAyvFO0vEaJUYyVYYOOodC4"
CHAT_IDS = ["860174169", "5290425385"]

hisselerlist = [
    "BIST:ACSEL", "BIST:ADEL", "BIST:ADESE", "BIST:AEFES", "BIST:AFYON",
    "BIST:AGESA", "BIST:AGHOL", "BIST:AGYO", "BIST:AKBNK", "BIST:AKCNS",
    "BIST:AKENR", "BIST:AKFGY", "BIST:AKGRT", "BIST:AKMGY", "BIST:AKSA",
    "BIST:AKSEN", "BIST:AKSGY", "BIST:AKSUE", "BIST:AKYHO", "BIST:ALARK",
    "BIST:ALBRK", "BIST:ALCAR", "BIST:ALCTL", "BIST:ALGYO", "BIST:ALKA",
    "BIST:ALKIM", "BIST:ALMAD", "BIST:ANELE", "BIST:ANGEN", "BIST:ANHYT",
    "BIST:ANSGR", "BIST:ARASE", "BIST:ARCLK", "BIST:ARDYZ", "BIST:ARENA",
    "BIST:ARMDA", "BIST:ARSAN", "BIST:ARZUM", "BIST:ASELS", "BIST:ASUZU",
    "BIST:ATAGY", "BIST:ATATP", "BIST:ATEKS", "BIST:ATLAS", "BIST:ATSYH",
    "BIST:AVGYO", "BIST:AVHOL", "BIST:AVOD", "BIST:AVTUR", "BIST:AYCES",
    "BIST:AYDEM", "BIST:AYEN", "BIST:AYES", "BIST:AYGAZ", "BIST:AZTEK",
    "BIST:BAGFS", "BIST:BAKAB", "BIST:BALAT", "BIST:BANVT", "BIST:BARMA",
    "BIST:BASCM", "BIST:BASGZ", "BIST:BAYRK", "BIST:BERA", "BIST:BEYAZ",
    "BIST:BFREN", "BIST:BIMAS", "BIST:BIOEN", "BIST:BIZIM", "BIST:BJKAS",
    "BIST:BLCYT", "BIST:BMSCH", "BIST:BMSTL", "BIST:BNTAS", "BIST:BOBET",
    "BIST:BOSSA", "BIST:BRISA", "BIST:BRKO", "BIST:BRKSN", "BIST:BRLSM",
    "BIST:BRMEN", "BIST:BRSAN", "BIST:BRYAT", "BIST:BSOKE", "BIST:BTCIM",
    "BIST:BUCIM", "BIST:BURCE", "BIST:BURVA", "BIST:CANTE", "BIST:CASA",
    "BIST:CCOLA", "BIST:CELHA", "BIST:CEMAS", "BIST:CEMTS", "BIST:CEOEM",
    "BIST:CIMSA", "BIST:CLEBI", "BIST:CMBTN", "BIST:CMENT", "BIST:CONSE",
    "BIST:COSMO", "BIST:CRDFA", "BIST:CRFSA", "BIST:CUSAN", "BIST:DAGHL",
    "BIST:DAGI", "BIST:DAPGM", "BIST:DARDL", "BIST:DENGE", "BIST:DERHL",
    "BIST:DERIM", "BIST:DESA", "BIST:DESPC", "BIST:DEVA", "BIST:DGATE",
    "BIST:DGGYO", "BIST:DGNMO", "BIST:DIRIT", "BIST:DITAS", "BIST:DMSAS",
    "BIST:DNISI", "BIST:DOAS", "BIST:DOBUR", "BIST:DOCO", "BIST:DOGUB",
    "BIST:DOHOL", "BIST:DOKTA", "BIST:DURDO", "BIST:DYOBY", "BIST:DZGYO",
    "BIST:ECILC", "BIST:ECZYT", "BIST:EDATA", "BIST:EDIP", "BIST:EGEEN",
    "BIST:EGEPO", "BIST:EGGUB", "BIST:EGPRO", "BIST:EGSER", "BIST:EKGYO",
    "BIST:EKIZ", "BIST:ELITE", "BIST:EMKEL", "BIST:EMNIS", "BIST:ENJSA",
    "BIST:ENKAI", "BIST:ENSRI", "BIST:EPLAS", "BIST:ERBOS", "BIST:ERCB",
    "BIST:EREGL", "BIST:ERSU", "BIST:ESCAR", "BIST:ESCOM", "BIST:ESEN",
    "BIST:ETILR", "BIST:ETYAT", "BIST:EUHOL", "BIST:EUKYO", "BIST:EUREN",
    "BIST:EUYO", "BIST:FADE", "BIST:FENER", "BIST:FLAP", "BIST:FMIZP",
    "BIST:FONET", "BIST:FORMT", "BIST:FRIGO", "BIST:FROTO", "BIST:GARAN",
    "BIST:GARFA", "BIST:GEDIK", "BIST:GEDZA", "BIST:GENIL", "BIST:GENTS",
    "BIST:GEREL", "BIST:GESAN", "BIST:GLBMD", "BIST:GLCVY", "BIST:GLRYH",
    "BIST:GLYHO", "BIST:GMTAS", "BIST:GOLTS", "BIST:GOODY", "BIST:GOZDE",
    "BIST:GRNYO", "BIST:GRSEL", "BIST:GSDDE", "BIST:GSDHO", "BIST:GSRAY",
    "BIST:GUBRF", "BIST:GWIND", "BIST:GZNMI", "BIST:HALKB", "BIST:HATEK",
    "BIST:HDFGS", "BIST:HEDEF", "BIST:HEKTS", "BIST:HKTM", "BIST:HLGYO",
    "BIST:HTTBT", "BIST:HUBVC", "BIST:HUNER", "BIST:HURGZ", "BIST:ICBCT",
    "BIST:IDEAS", "BIST:IDGYO", "BIST:IEYHO", "BIST:IHAAS", "BIST:IHEVA",
    "BIST:IHGZT", "BIST:IHLAS", "BIST:IHLGM", "BIST:IHYAY", "BIST:IMASM",
    "BIST:INDES", "BIST:INFO", "BIST:INTEM", "BIST:INVEO", "BIST:INVES",
    "BIST:IPEKE", "BIST:ISATR", "BIST:ISBIR", "BIST:ISBTR", "BIST:ISCTR",
    "BIST:ISDMR", "BIST:ISFIN", "BIST:ISGSY", "BIST:ISGYO", "BIST:ISKPL",
    "BIST:ISMEN", "BIST:ISSEN", "BIST:ISYAT", "BIST:ITTFH", "BIST:IZFAS",
    "BIST:IZINV", "BIST:IZMDC", "BIST:JANTS", "BIST:KAPLM", "BIST:KAREL",
    "BIST:KARSN", "BIST:KARTN", "BIST:KARYE", "BIST:KATMR", "BIST:KCAER",
    "BIST:KCHOL", "BIST:KENT", "BIST:KERVN", "BIST:KERVT", "BIST:KFEIN",
    "BIST:KGYO", "BIST:KIMMR", "BIST:KLGYO", "BIST:KLKIM", "BIST:KLMSN",
    "BIST:KLNMA", "BIST:KLRHO", "BIST:KLSYN", "BIST:KMPUR", "BIST:KNFRT",
    "BIST:KONKA", "BIST:KONTR", "BIST:KONYA", "BIST:KORDS", "BIST:KOZAA",
    "BIST:KOZAL", "BIST:KRDMA", "BIST:KRDMB", "BIST:KRDMD", "BIST:KRGYO",
    "BIST:KRONT", "BIST:KRPLS", "BIST:KRSTL", "BIST:KRTEK", "BIST:KRVGD",
    "BIST:KSTUR", "BIST:KTSKR", "BIST:KUTPO", "BIST:KUVVA", "BIST:KUYAS",
    "BIST:KZBGY", "BIST:LIDER", "BIST:LIDFA", "BIST:LINK", "BIST:LKMNH",
    "BIST:LOGO", "BIST:LUKSK", "BIST:MAALT", "BIST:MAGEN", "BIST:MAKIM",
    "BIST:MAKTK", "BIST:MANAS", "BIST:MARKA", "BIST:MARTI", "BIST:MAVI",
    "BIST:MEDTR", "BIST:MEGAP", "BIST:MEPET", "BIST:MERCN", "BIST:MERIT",
    "BIST:MERKO", "BIST:METRO", "BIST:METUR", "BIST:MGROS", "BIST:MIATK",
    "BIST:MIPAZ", "BIST:MMCAS", "BIST:MNDRS", "BIST:MOBTL", "BIST:MPARK",
    "BIST:MRGYO", "BIST:MRSHL", "BIST:MSGYO", "BIST:MTRKS", "BIST:MTRYO",
    "BIST:MZHLD", "BIST:NATEN", "BIST:NETAS", "BIST:NIBAS", "BIST:NTGAZ",
    "BIST:NTHOL", "BIST:NUGYO", "BIST:NUHCM", "BIST:OBASE", "BIST:ODAS",
    "BIST:ORCAY", "BIST:ORGE", "BIST:ORMA", "BIST:OSMEN", "BIST:OSTIM",
    "BIST:OTKAR", "BIST:OTTO", "BIST:OYAKC", "BIST:OYAYO", "BIST:OYLUM",
    "BIST:OYYAT", "BIST:OZGYO", "BIST:OZKGY", "BIST:OZRDN", "BIST:PAGYO",
    "BIST:PAMEL", "BIST:PAPIL", "BIST:PARSN", "BIST:PCILT", "BIST:PEGYO",
    "BIST:PEKGY", "BIST:PENGD", "BIST:PENTA", "BIST:PETKM", "BIST:PETUN",
    "BIST:PGSUS", "BIST:PINSU", "BIST:PKART", "BIST:PKENT", "BIST:PNLSN",
    "BIST:PNSUT", "BIST:POLHO", "BIST:POLTK", "BIST:PRDGS", "BIST:PRKAB",
    "BIST:PRKME", "BIST:PRZMA", "BIST:PSDTC", "BIST:PSGYO", "BIST:QNBFB",
    "BIST:QNBFL", "BIST:QUAGR", "BIST:RALYH", "BIST:RAYSG", "BIST:RHEAG",
    "BIST:RNPOL", "BIST:RODRG", "BIST:ROYAL", "BIST:RTALB", "BIST:RUBNS",
    "BIST:RYGYO", "BIST:RYSAS", "BIST:SAFKR", "BIST:SAHOL", "BIST:SAMAT",
    "BIST:SANEL", "BIST:SANFM", "BIST:SANKO", "BIST:SARKY", "BIST:SASA",
    "BIST:SAYAS", "BIST:SEGYO", "BIST:SEKFK", "BIST:SEKUR", "BIST:SELEC",
    "BIST:SELGD", "BIST:SELVA", "BIST:SEYKM", "BIST:SILVR", "BIST:SISE",
    "BIST:SKBNK", "BIST:SKTAS", "BIST:SMART", "BIST:SMRTG", "BIST:SNGYO",
    "BIST:SNKRN", "BIST:SNPAM", "BIST:SODSN", "BIST:SOKM", "BIST:SONME",
    "BIST:SRVGY", "BIST:SUMAS", "BIST:SUNTK", "BIST:SUWEN", "BIST:TATGD",
    "BIST:TAVHL", "BIST:TBORG", "BIST:TCELL", "BIST:TDGYO", "BIST:TEKTU",
    "BIST:TETMT", "BIST:TEZOL", "BIST:TGSAS", "BIST:THYAO", "BIST:TKFEN",
    "BIST:TKNSA", "BIST:TLMAN", "BIST:TMPOL", "BIST:TMSN", "BIST:TOASO",
    "BIST:TRCAS", "BIST:TRGYO", "BIST:TRILC", "BIST:TSGYO", "BIST:TSKB",
    "BIST:TSPOR", "BIST:TTKOM", "BIST:TTRAK", "BIST:TUCLK", "BIST:TUKAS",
    "BIST:TUPRS", "BIST:TUREX", "BIST:TURGG", "BIST:TURSG", "BIST:UFUK",
    "BIST:ULAS", "BIST:ULKER", "BIST:ULUFA", "BIST:ULUSE", "BIST:ULUUN",
    "BIST:UMPAS", "BIST:UNLU", "BIST:USAK", "BIST:UZERB", "BIST:VAKBN",
    "BIST:VAKFN", "BIST:VAKKO", "BIST:VANGD", "BIST:VBTYZ", "BIST:VERTU",
    "BIST:VERUS", "BIST:VESBE", "BIST:VESTL", "BIST:VKFYO", "BIST:VKGYO",
    "BIST:VKING", "BIST:YAPRK", "BIST:YATAS", "BIST:YAYLA", "BIST:YBTAS",
    "BIST:YEOTK", "BIST:YESIL", "BIST:YGGYO", "BIST:YGYO", "BIST:YKBNK",
    "BIST:YKSLN", "BIST:YONGA", "BIST:YUNSA", "BIST:YYAPI", "BIST:YYLGD",
    "BIST:ZEDUR", "BIST:ZOREN", "BIST:ZRGYO"
]


def send_telegram_photo(photo_path, caption):
    if not BOT_TOKEN or not CHAT_IDS:
        print("Telegram Bot Token veya Chat ID eksik!")
        return
    try:
        bot = telepot.Bot(BOT_TOKEN)
        for chat_id in CHAT_IDS:
            with open(photo_path, 'rb') as photo:
                bot.sendPhoto(chat_id,
                              photo,
                              caption=caption,
                              parse_mode='Markdown')
            time.sleep(0.5)
    except Exception as e:
        print(f"Telegram gönderim hatası: {e}")


def send_telegram_message(text):
    if not BOT_TOKEN or not CHAT_IDS:
        return
    try:
        bot = telepot.Bot(BOT_TOKEN)
        for chat_id in CHAT_IDS:
            bot.sendMessage(chat_id, text, parse_mode='Markdown')
    except Exception as e:
        print(f"Telegram mesaj hatası: {e}")


def run_scanner():
    print("=" * 70)
    print("HAFTALIK HACIM TARAYICISI (MA20 > MA100 + MERDİVEN + 150 MUM)")
    print("=" * 70)

    tv = TvDatafeed()
    bulunan_hisseler = []
    toplam_hisse = len(hisselerlist)
    baslangic_zamani = datetime.now()

    for idx, symbol in enumerate(hisselerlist, 1):
        print(f"[{idx}/{toplam_hisse}] {symbol} taranıyor...", end=" ")

        try:
            # Haftalık veri çek (150 bar)
            data = tv.get_hist(symbol=symbol,
                               exchange='BIST',
                               interval=Interval.in_weekly,
                               n_bars=150)

            if data is None or data.empty:
                print("Veri yok")
                continue

            if len(data) < 150:
                print("Yetersiz veri (<150)")
                continue

            # --- HACİM ORTALAMALARI (GÜNCEL: MA20 ve MA100) ---
            vol_avg_20 = data['volume'].tail(20).mean()
            vol_avg_100 = data['volume'].tail(100).mean()

            # KOŞUL 1: MA20 Hacim > MA100 Hacim
            if vol_avg_20 <= vol_avg_100:
                continue

            # --- ANA KONTROL (SON 3 MUM - MERDİVEN SİSTEMİ) ---
            son_3 = data.tail(3)

            # KOŞUL 2: Son 3 Mum Yeşil (Kapanış > Açılış)
            yesil_mumlar = all(son_3['close'] > son_3['open'])

            # --- HACİM MUMU RENGİ ---
            # Kullanıcı son hacim mumunun yeşil (Fiyat Artışı) olmasını istiyor
            son_mum_yesil = son_3['close'].iloc[-1] > son_3['open'].iloc[-1]

            # KOŞUL 3: Artan Hacim (V3 > V2 > V1)
            volumes = son_3['volume'].values
            if volumes[0] == 0: continue

            artis_yuzdesi = ((volumes[2] - volumes[0]) / volumes[0]) * 100

            hacim_artiyor = (volumes[2] > volumes[1]) and (volumes[1]
                                                           > volumes[0])
            pozitif_artis = artis_yuzdesi > 0

            # HEPSİ BİR ARADA: Yeşil Mumlar VE Artan Hacim VE Pozitif Artış VE Son Mum Yeşil
            if yesil_mumlar and hacim_artiyor and pozitif_artis and son_mum_yesil:

                # --- SERİ KONTROLÜ (Geçmişe dönük kontrol) ---
                seri_sayisi = 3
                tum_close = data['close'].tolist()
                tum_open = data['open'].tolist()
                tum_volume = data['volume'].tolist()
                limit = min(len(data), 20)

                for i in range(4, limit + 1):
                    curr_idx = -i
                    next_idx = -(i - 1)
                    if (tum_close[curr_idx]
                            > tum_open[curr_idx]) and (tum_volume[curr_idx]
                                                       < tum_volume[next_idx]):
                        seri_sayisi += 1
                    else:
                        break

                print(
                    f"!!! BULUNDU !!! (Sıra: {idx}, Seri: {seri_sayisi} Hafta)"
                )
                bulunan_hisseler.append(symbol)

                # --- GRAFİK OLUŞTURMA (150 MUM) ---
                photo_path = f"{symbol.replace(':', '_')}_haftalik.png"
                # tail(30) yerine tüm veriyi (150 mum) alıyoruz.
                df_plot = data.copy()

                plt.style.use('seaborn-v0_8-darkgrid')
                fig = plt.figure(figsize=(12, 8), facecolor='#f5f5f5')
                gs = fig.add_gridspec(3,
                                      1,
                                      height_ratios=[2.5, 1, 0.3],
                                      hspace=0.05)

                ax1 = fig.add_subplot(gs[0])
                ax2 = fig.add_subplot(gs[1], sharex=ax1)

                # Candlestick (Mum kalınlığı 150 veri için width=1)
                ohlc_data = list(
                    zip(mdates.date2num(df_plot.index.to_pydatetime()),
                        df_plot['open'], df_plot['high'], df_plot['low'],
                        df_plot['close']))
                candlestick_ohlc(ax1,
                                 ohlc_data,
                                 width=1,
                                 colorup='#26a69a',
                                 colordown='#ef5350',
                                 alpha=0.9)

                # --- FIBONACCI HESAPLAMA (Tüm Veri Üzerinden) ---
                fib_data = df_plot
                max_price = fib_data['high'].max()
                min_price = fib_data['low'].min()

                # Zirve ve Dip tarihlerinin indexlerini bul
                idx_max = fib_data['high'].idxmax()
                idx_min = fib_data['low'].idxmin()

                diff = max_price - min_price
                levels = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1]
                colors_fib = [
                    'gray', 'red', 'orange', 'green', 'gold', 'purple', 'gray'
                ]
                widths_fib = [1, 1, 1, 1, 2.5, 1, 1]

                uptrend = idx_max > idx_min

                for i, level in enumerate(levels):
                    if uptrend:
                        price_level = max_price - (diff * level)
                    else:
                        price_level = min_price + (diff * level)

                    ax1.axhline(price_level,
                                color=colors_fib[i],
                                alpha=0.5,
                                linestyle='--',
                                linewidth=widths_fib[i])
                    # Metni grafiğin en sağına yazdır
                    ax1.text(df_plot.index[-1],
                             price_level,
                             f'{level:.3f} - {price_level:.2f}',
                             color=colors_fib[i],
                             fontsize=9,
                             va='center',
                             ha='left',
                             fontweight='bold')

                # ------------------------------------------

                # Fiyat Etiketi
                last_price = df_plot['close'].iloc[-1]
                ax1.text(0.02,
                         0.95,
                         f'Fiyat: {last_price:.2f} TL',
                         transform=ax1.transAxes,
                         fontsize=14,
                         fontweight='bold',
                         color='black',
                         bbox=dict(facecolor='white', alpha=0.8))

                # Başlık
                trend_text = "YÜKSELİŞ (Dipten Tepeye)" if uptrend else "DÜŞÜŞ (Tepeden Dibe)"
                title_text = f'{symbol} - {seri_sayisi} Hafta Seri | Fib(150): {trend_text}'
                ax1.set_title(title_text,
                              fontsize=14,
                              fontweight='bold',
                              pad=15)
                ax1.set_ylabel('Fiyat', fontsize=11, fontweight='bold')
                ax1.grid(True, alpha=0.3)
                ax1.tick_params(labelbottom=False)

                # Hacim Grafiği (Genişlik 1 olarak ayarlandı)
                colors = [
                    '#26a69a' if df_plot['close'].iloc[i]
                    >= df_plot['open'].iloc[i] else '#ef5350'
                    for i in range(len(df_plot))
                ]
                ax2.bar(mdates.date2num(df_plot.index.to_pydatetime()),
                        df_plot['volume'],
                        width=1,
                        color=colors,
                        alpha=0.7)
                ax2.set_ylabel('Hacim', fontsize=11, fontweight='bold')
                ax2.xaxis.set_major_formatter(
                    mdates.DateFormatter('%m-%Y'))  # Tarih formatı

                plt.tight_layout()
                plt.savefig(photo_path,
                            dpi=150,
                            bbox_inches='tight',
                            facecolor='#f5f5f5')
                plt.close()

                # Mesaj
                if seri_sayisi > 3:
                    baslik = f"🔥 *DİKKAT: {seri_sayisi} HAFTADIR ARALIKSIZ ARTIŞ!* 🔥"
                else:
                    baslik = f"✅ *GÜÇLÜ ALICI SİNYALİ (3 HAFTA)*"

                ticker = symbol.split(':')[1]
                link = f"https://www.tradingview.com/chart/?symbol=BIST%3A{ticker}&interval=W"
                v = son_3['volume'].tolist()

                caption = (
                    f"{baslik}\n"
                    f"🏷️ *Hisse:* {symbol} (Sıra: {idx}/{toplam_hisse})\n"
                    f"💰 *Son Fiyat:* {last_price:.2f} TL\n"
                    f"📐 *Fib Trendi:* {trend_text}\n\n"
                    f"🚀 *TOPLAM HACİM ARTIŞI: %{artis_yuzdesi:.1f}*\n"
                    f"⚖️ *Hacim Ortalaması:* MA20 ({vol_avg_20:,.0f}) > MA100 ({vol_avg_100:,.0f}) ✅\n\n"
                    f"📊 *Hacim Detayları (Yeni -> Eski):*\n"
                    f"▪️ *Bu Hafta*: {v[2]:,.0f}\n"
                    f"▪️ 1 Hafta Önce: {v[1]:,.0f}\n"
                    f"▪️ 2 Hafta Önce: {v[0]:,.0f}\n\n"
                    f"🔗 [Grafik]({link})")

                send_telegram_photo(photo_path, caption)

                if os.path.exists(photo_path):
                    os.remove(photo_path)

                time.sleep(1)
            else:
                pass

        except Exception as e:
            print(f"Hata ({symbol}): {e}")
            continue

    # --- BİTİŞ ---
    gecen_sure = datetime.now() - baslangic_zamani

    print("\n" + "=" * 70)
    print("TARAMA TAMAMLANDI!")

    sonuc_mesaji = (f"🏁 *TARAMA TAMAMLANDI*\n"
                    f"⏱️ Süre: {gecen_sure}\n"
                    f"🎯 *Bulunan Hisse Sayısı: {len(bulunan_hisseler)}*\n")

    if bulunan_hisseler:
        sonuc_mesaji += f"📌 *Bulunanlar:*\n{', '.join(bulunan_hisseler)}"
    else:
        sonuc_mesaji += "❌ Kriterlere uygun hisse bulunamadı."

    send_telegram_message(sonuc_mesaji)
    print("Bitiş mesajı gönderildi.")
    print("=" * 70)


if __name__ == "__main__":
    run_scanner()
