# HisseAvcısı - BIST Hisse Takip ve Analiz Uygulaması

## Genel Bakış

HisseAvcısı, Borsa İstanbul (BIST) hisselerini takip etmek ve analiz etmek için tasarlanmış mobil öncelikli bir Progressive Web App'tir. Uygulama, TradingView üzerinden Python ile gerçek zamanlı hisse fiyatları ve teknik göstergeler sağlar, hedef fiyat alarmları, not tutma ve Google Gemini AI destekli analiz özellikleri sunar.

**Özellikler:**
- 345 BIST hissesi alfabetik sırayla
- TradingView'den Python ile OHLCV (Açılış, Yüksek, Düşük, Kapanış, Hacim) verileri
- RSI, MACD, SMA, Bollinger Bands gibi teknik göstergeler
- Al/Sat sinyalleri ve öneri sistemi
- Hedef fiyat alarmları
- AI destekli not analizi (Google Gemini)
- Koyu tema finansal terminal arayüzü
- Tam Türkçe arayüz

## Kullanıcı Tercihleri

- Tercih edilen iletişim stili: Basit, günlük dil
- Para birimi: Türk Lirası (₺)
- Dil: Türkçe

## Sistem Mimarisi

### Frontend Mimarisi
- **Framework**: React 18+ TypeScript, Vite ile paketlenmiş
- **Routing**: Wouter (hafif client-side routing)
- **State Yönetimi**: TanStack React Query
- **Styling**: Tailwind CSS, koyu tema (gray-950 arka plan)
- **UI Bileşenleri**: shadcn/ui (Radix UI üzerine kurulu)
- **Animasyonlar**: Framer Motion
- **Tasarım**: Mobile-first, finansal terminal estetiği

### Backend Mimarisi
- **Runtime**: Node.js + Express.js
- **Dil**: TypeScript (tsx ile development, esbuild ile production)
- **API Pattern**: RESTful, `shared/routes.ts`'de Zod şema doğrulaması
- **Python Bridge**: TradingView verileri için Python script çağırma

### Veri Depolama
- **Veritabanı**: PostgreSQL + Drizzle ORM
- **Şema**: `shared/schema.ts` - stocks, targets, stock_notes tabloları
- **Migrations**: drizzle-kit, `./migrations` klasörüne çıktı

### Hisse Verisi Entegrasyonu (TradingView)
- **Kaynak**: TradingView (tradingview-ta Python kütüphanesi)
- **Python Script**: `server/services/stock_data.py`
- **Sembol Formatı**: BIST hisseleri "BIST:SYMBOL" formatında
- **Çekilen Veriler**:
  - OHLCV (Open, High, Low, Close, Volume)
  - RSI, MACD, SMA20/50/200, EMA20
  - Bollinger Bands, ATR, ADX, CCI, Stochastic
  - Al/Sat/Nötr sinyalleri ve öneri

### AI Entegrasyonu
- **Sağlayıcı**: Google Gemini (Replit AI Integrations)
- **Model**: gemini-2.5-flash
- **Kullanım**: Not analizi ve yatırım önerileri

## API Endpoints

### Hisseler
- `GET /api/stocks` - Tüm hisseleri listele (alfabetik)
- `POST /api/stocks` - Yeni hisse ekle
- `GET /api/stocks/:id` - Hisse detayı
- `DELETE /api/stocks/:id` - Hisse sil
- `POST /api/stocks/:id/refresh` - Fiyat güncelle (TradingView'den)
- `GET /api/stocks/:id/candles` - OHLCV ve teknik göstergeler (TradingView'den)

### Hedefler
- `POST /api/stocks/:stockId/targets` - Hedef ekle
- `DELETE /api/targets/:id` - Hedef sil

### Notlar
- `POST /api/stocks/:stockId/notes` - Not ekle
- `POST /api/stocks/:stockId/analyze` - AI analizi

## Önemli Dosyalar

- `server/services/stock_data.py` - TradingView Python script
- `server/lib/python_bridge.ts` - Python çağrı köprüsü
- `server/data/bist_stocks.json` - 345 BIST hisse listesi
- `client/src/components/StockDetailOverlay.tsx` - Hisse detay ekranı
- `client/src/components/StockCard.tsx` - Hisse kartı
- `client/src/hooks/use-stocks.ts` - Veri çekme hook'ları
- `shared/schema.ts` - Veritabanı şeması

## Geliştirme Notları

### Server Başlatma
```bash
npm run dev
```

### Veritabanı
```bash
npm run db:push  # Şema senkronizasyonu
```

### Python Bağımlılıkları
- tradingview-ta (teknik analiz ve fiyat verileri)
- pandas (veri işleme)
- scipy (istatistiksel analiz, destek/direnç hesaplama)

## Gelişmiş Teknik Analiz

### Analiz Özellikleri
- **Destek/Direnç**: Pivot noktalarından otomatik S/R seviyeleri
- **Fibonacci**: Swing high/low'dan retracement seviyeleri
- **Order Blocks**: Smart Money Concepts - güçlü hacimli mumlar
- **Fair Value Gaps**: Fiyat dengesizlik bölgeleri
- **Hacim Profili**: POC ve Value Area hesaplama
- **Mum Formasyonları**: Hammer, Doji, Engulfing tespiti
- **Trend Analizi**: Lineer regresyon ile trend yönü ve gücü

### Gelişmiş Tarayıcı Endpoint'leri
- `GET /api/stocks/:id/advanced-analysis` - Tekil hisse analizi
- `POST /api/scanner/advanced` - Toplu analiz (maks 10 hisse)

## Bildirim Sistemi

### Telegram Bildirimleri
- **Bot Token**: Replit Secrets'ta `TELEGRAM_BOT_TOKEN` olarak saklanıyor
- **Chat ID'ler**: Veritabanında `app_settings` tablosunda JSON olarak
- **Ayarlar**: `/api/settings/telegram` endpoint'i ile yönetiliyor
- **Test**: `/api/settings/telegram/test` ile test bildirimi

### Tarayıcı Bildirimleri
- Web Push API kullanılıyor
- İzin durumu localStorage'da saklanıyor
- Alarm tetiklendiğinde otomatik bildirim

### WhatsApp Bildirimleri (Gelecekte)
- Twilio API ile entegrasyon planlanıyor
- Kullanıcı telefon numarası: 05074088850
- Twilio Account SID, Auth Token gerekli

## Son Değişiklikler

- Tarayıcı tüm 345 hisseyi tarıyor (limit kaldırıldı)
- Tarama sonuçlarında tarih/saat ve taranan hisse sayısı gösterimi (örn: "245/345 hisse")
- TradingView Sinyal bölümünde taranan/toplam hisse ve zaman damgası
- Gelişmiş alarm sistemi: Yüzdesel fark hesaplama, yakın/uzak gösterimi
- Alarm filtreleme: Tümü, Yakın (≤5%), Uzak (>5%), Yukarı, Aşağı
- Tarayıcı push bildirimleri eklendi
- Telegram ayarları UI'da düzenlenebilir (Chat ID ekleme/silme, açma/kapama)
- Alarm geçmişi görüntüleme
- 345 BIST hissesi alfabetik sıralamayla eklendi
- TradingView Python entegrasyonu tamamlandı
- OHLCV ve teknik göstergeler eklendi
- Grafik sekmesi eklendi (Al/Sat sinyalleri, OHLCV, göstergeler)
- Tüm UI metinleri Türkçe'ye çevrildi
- Para birimi ₺ olarak güncellendi
