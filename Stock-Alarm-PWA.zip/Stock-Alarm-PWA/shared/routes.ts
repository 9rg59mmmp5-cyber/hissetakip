import { z } from 'zod';
import { insertStockSchema, insertTargetSchema, insertStockNoteSchema, stocks, targets, stockNotes } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  stocks: {
    list: {
      method: 'GET' as const,
      path: '/api/stocks',
      responses: {
        200: z.array(z.custom<typeof stocks.$inferSelect & { targets: typeof targets.$inferSelect[] }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/stocks',
      input: z.object({ symbol: z.string(), name: z.string().optional() }),
      responses: {
        201: z.custom<typeof stocks.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/stocks/:id',
      responses: {
        200: z.custom<typeof stocks.$inferSelect & { targets: typeof targets.$inferSelect[], notes: typeof stockNotes.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/stocks/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    // New endpoint to force refresh price via Python
    refresh: {
      method: 'POST' as const,
      path: '/api/stocks/:id/refresh',
      responses: {
        200: z.object({ price: z.number() }),
        404: errorSchemas.notFound,
      },
    }
  },
  targets: {
    create: {
      method: 'POST' as const,
      path: '/api/stocks/:stockId/targets',
      input: insertTargetSchema.omit({ stockId: true }),
      responses: {
        201: z.custom<typeof targets.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/targets/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  notes: {
    create: {
      method: 'POST' as const,
      path: '/api/stocks/:stockId/notes',
      input: insertStockNoteSchema.omit({ stockId: true }),
      responses: {
        201: z.custom<typeof stockNotes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    analyze: { // Gemini analysis
      method: 'POST' as const,
      path: '/api/stocks/:stockId/notes/analyze',
      responses: {
        200: z.object({ analysis: z.string() }),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
