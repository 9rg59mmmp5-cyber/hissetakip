import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === TABLE DEFINITIONS ===

// Stores the list of stocks the user is tracking
export const stocks = pgTable("stocks", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(), // e.g. "THYAO", "AAPL", "BTC-USD"
  name: text("name").notNull(), // e.g. "Turk Hava Yollari"
  currentPrice: real("current_price"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Targets/Alarms for a specific stock
export const targets = pgTable("targets", {
  id: serial("id").primaryKey(),
  stockId: integer("stock_id").notNull().references(() => stocks.id),
  targetPrice: real("target_price").notNull(),
  note: text("note"), // "Buy when drops to this level"
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User notes/analysis for a stock
export const stockNotes = pgTable("stock_notes", {
  id: serial("id").primaryKey(),
  stockId: integer("stock_id").notNull().references(() => stocks.id),
  content: text("content").notNull(),
  aiAnalysis: text("ai_analysis"), // Summary/Analysis from Gemini
  createdAt: timestamp("created_at").defaultNow(),
});

// App settings including Telegram configuration
export const appSettings = pgTable("app_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Alarm notifications log
export const alarmNotifications = pgTable("alarm_notifications", {
  id: serial("id").primaryKey(),
  targetId: integer("target_id").notNull().references(() => targets.id),
  stockId: integer("stock_id").notNull().references(() => stocks.id),
  triggeredPrice: real("triggered_price").notNull(),
  notifiedAt: timestamp("notified_at").defaultNow(),
  channel: text("channel").notNull(), // "telegram" or "whatsapp"
});

// === RELATIONS ===
export const stocksRelations = relations(stocks, ({ many }) => ({
  targets: many(targets),
  notes: many(stockNotes),
}));

export const targetsRelations = relations(targets, ({ one }) => ({
  stock: one(stocks, {
    fields: [targets.stockId],
    references: [stocks.id],
  }),
}));

export const stockNotesRelations = relations(stockNotes, ({ one }) => ({
  stock: one(stocks, {
    fields: [stockNotes.stockId],
    references: [stocks.id],
  }),
}));

// === SCHEMAS & TYPES ===

export const insertStockSchema = createInsertSchema(stocks).omit({ id: true, lastUpdated: true, currentPrice: true });
export const insertTargetSchema = createInsertSchema(targets).omit({ id: true, createdAt: true });
export const insertStockNoteSchema = createInsertSchema(stockNotes).omit({ id: true, createdAt: true, aiAnalysis: true });
export const insertAppSettingSchema = createInsertSchema(appSettings).omit({ id: true, updatedAt: true });

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = z.infer<typeof insertStockSchema>;

export type Target = typeof targets.$inferSelect;
export type InsertTarget = z.infer<typeof insertTargetSchema>;

export type StockNote = typeof stockNotes.$inferSelect;
export type InsertStockNote = z.infer<typeof insertStockNoteSchema>;

export type AppSetting = typeof appSettings.$inferSelect;
export type InsertAppSetting = z.infer<typeof insertAppSettingSchema>;

export type AlarmNotification = typeof alarmNotifications.$inferSelect;

// API Types
export type StockWithDetails = Stock & {
  targets: Target[];
  notes: StockNote[];
};

export type CreateStockRequest = {
  symbol: string;
  name?: string;
};

export type UpdateStockPriceRequest = {
  price: number;
};

export * from "./models/chat";
