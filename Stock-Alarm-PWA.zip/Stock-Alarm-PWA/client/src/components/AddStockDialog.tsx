import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Search, Loader2 } from "lucide-react";
import { useCreateStock } from "@/hooks/use-stocks";
import { useToast } from "@/hooks/use-toast";

interface AddStockDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AddStockDialog({ isOpen, onClose }: AddStockDialogProps) {
  const [symbol, setSymbol] = useState("");
  const createStock = useCreateStock();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!symbol.trim()) return;

    createStock.mutate(
      { symbol: symbol.toUpperCase(), name: "Stock" }, // Name will be fetched by backend ideally
      {
        onSuccess: () => {
          toast({
            title: "Hisse Eklendi",
            description: `${symbol.toUpperCase()} takip listesine eklendi`,
          });
          setSymbol("");
          onClose();
        },
        onError: (error) => {
          toast({
            title: "Hata",
            description: error.message,
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-x-4 top-[20%] md:left-1/2 md:w-full md:max-w-md md:-translate-x-1/2 z-50 bg-gray-900 border border-gray-800 rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-white">Hisse Ekle</h2>
                <button 
                  onClick={onClose}
                  className="p-2 -mr-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm text-gray-400 font-medium ml-1">Sembol / Hisse Kodu</label>
                  <div className="relative">
                    <input
                      autoFocus
                      type="text"
                      value={symbol}
                      onChange={(e) => setSymbol(e.target.value)}
                      placeholder="örn. THYAO, AKBNK, GARAN"
                      className="w-full bg-gray-950 border border-gray-800 text-white text-lg font-mono rounded-xl px-4 py-3 pl-11 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-gray-700 uppercase"
                    />
                    <Search className="w-5 h-5 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                  <p className="text-xs text-gray-600 px-1">
                    BIST hisseleri desteklenmektedir (THYAO, AKBNK, vb.).
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={createStock.isPending || !symbol.trim()}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3.5 rounded-xl shadow-lg shadow-emerald-900/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-2 active:scale-[0.98]"
                >
                  {createStock.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Aranıyor...</span>
                    </>
                  ) : (
                    <span>Takibe Başla</span>
                  )}
                </button>
              </form>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
