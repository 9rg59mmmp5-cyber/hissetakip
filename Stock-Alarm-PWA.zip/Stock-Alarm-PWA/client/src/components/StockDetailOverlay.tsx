import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, RefreshCw, Share2, Target, 
  Trash2, Plus, Sparkles, Send, BrainCircuit,
  TrendingUp, TrendingDown, BarChart3, Activity, CandlestickChart as CandlestickIcon
} from "lucide-react";
import { useStock, useRefreshStock, useCreateTarget, useDeleteTarget, useCreateNote, useAnalyzeNotes, useStockCandles } from "@/hooks/use-stocks";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { CandlestickChart } from "./CandlestickChart";

interface StockDetailOverlayProps {
  stockId: number | null;
  onClose: () => void;
}

export function StockDetailOverlay({ stockId, onClose }: StockDetailOverlayProps) {
  const { data: stock, isLoading } = useStock(stockId || 0);
  const { data: candleData, isLoading: candlesLoading, refetch: refetchCandles } = useStockCandles(stockId);
  const refreshStock = useRefreshStock();
  const createTarget = useCreateTarget();
  const deleteTarget = useDeleteTarget();
  const createNote = useCreateNote();
  const analyzeNotes = useAnalyzeNotes();
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState<'chart' | 'targets' | 'notes'>('chart');
  const [targetPrice, setTargetPrice] = useState("");
  const [noteContent, setNoteContent] = useState("");

  useEffect(() => {
    setTargetPrice("");
    setNoteContent("");
    setActiveTab('chart');
  }, [stockId]);

  if (!stockId) return null;

  const handleRefresh = () => {
    refreshStock.mutate(stockId, {
      onSuccess: () => {
        refetchCandles();
        toast({ title: "Fiyat Güncellendi", description: "TradingView'den güncel veri alındı." });
      },
      onError: () => toast({ title: "Hata", description: "Fiyat alınamadı.", variant: "destructive" })
    });
  };

  const handleAddTarget = (e: React.FormEvent) => {
    e.preventDefault();
    const price = parseFloat(targetPrice);
    if (!price) return;
    const pctDiff = stock?.currentPrice 
      ? ((price - stock.currentPrice) / stock.currentPrice * 100).toFixed(1)
      : "0";
    createTarget.mutate({ stockId, data: { targetPrice: price, note: `Alarm: ${pctDiff}%` } }, {
      onSuccess: () => {
        setTargetPrice("");
        toast({ title: "Alarm Kuruldu", description: `₺${price} (${pctDiff}%) için alarm aktif` });
      }
    });
  };

  const handleDeleteTarget = (id: number) => {
    deleteTarget.mutate({ id, stockId }, {
      onSuccess: () => toast({ title: "Alarm Silindi" })
    });
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim()) return;
    createNote.mutate({ stockId, data: { content: noteContent } }, {
      onSuccess: () => {
        setNoteContent("");
        toast({ title: "Not Eklendi" });
      }
    });
  };

  const handleAnalysis = () => {
    analyzeNotes.mutate(stockId, {
      onSuccess: () => toast({ title: "AI Analizi Tamamlandı", description: "Analiz sonuçlarını görmek için notlar sekmesine bakın." })
    });
  };

  const getRecommendationColor = (rec: string) => {
    if (rec === "STRONG_BUY" || rec === "BUY") return "text-emerald-400";
    if (rec === "STRONG_SELL" || rec === "SELL") return "text-red-400";
    return "text-yellow-400";
  };

  const getRecommendationText = (rec: string) => {
    const map: Record<string, string> = {
      "STRONG_BUY": "Güçlü Al",
      "BUY": "Al",
      "NEUTRAL": "Nötr",
      "SELL": "Sat",
      "STRONG_SELL": "Güçlü Sat"
    };
    return map[rec] || rec;
  };

  return (
    <AnimatePresence>
      {stockId && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/90 z-40 backdrop-blur-sm"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 bg-gray-950 flex flex-col md:max-w-md md:left-1/2 md:-translate-x-1/2 md:border-x md:border-gray-800"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800 bg-gray-950">
              <button onClick={onClose} className="p-2 -ml-2 text-gray-400 hover:text-white rounded-full hover:bg-gray-900">
                <X className="w-6 h-6" />
              </button>
              <h2 className="text-lg font-bold text-white tracking-wider">{stock?.symbol}</h2>
              <button className="p-2 -mr-2 text-gray-400 hover:text-white rounded-full hover:bg-gray-900">
                <Share2 className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto pb-safe">
              {isLoading ? (
                <div className="flex justify-center py-20"><div className="animate-spin w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full" /></div>
              ) : stock ? (
                <div className="p-6 space-y-6">
                  
                  <div className="text-center space-y-2 py-2">
                    <p className="text-sm text-gray-500 font-medium tracking-wide uppercase">{stock.name}</p>
                    <h1 className="text-5xl font-mono font-bold text-white tracking-tight text-glow">
                      ₺{stock.currentPrice?.toFixed(2) ?? "---"}
                    </h1>
                    <div className="flex justify-center pt-2">
                      <button 
                        onClick={handleRefresh}
                        disabled={refreshStock.isPending}
                        className="flex items-center space-x-2 px-4 py-2 bg-emerald-500/10 text-emerald-400 rounded-full text-xs font-semibold hover:bg-emerald-500/20 transition-colors disabled:opacity-50"
                        data-testid="button-refresh-price"
                      >
                        <RefreshCw className={cn("w-3 h-3", refreshStock.isPending && "animate-spin")} />
                        <span>{refreshStock.isPending ? "Güncelleniyor..." : "Fiyatı Güncelle"}</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="flex p-1 bg-gray-900 rounded-xl mb-4">
                      <button
                        onClick={() => setActiveTab('chart')}
                        className={cn(
                          "flex-1 py-2 text-sm font-medium rounded-lg transition-all flex items-center justify-center gap-1",
                          activeTab === 'chart' ? "bg-gray-800 text-white shadow-sm" : "text-gray-500 hover:text-gray-300"
                        )}
                        data-testid="tab-chart"
                      >
                        <BarChart3 className="w-4 h-4" />
                        Grafik
                      </button>
                      <button
                        onClick={() => setActiveTab('targets')}
                        className={cn(
                          "flex-1 py-2 text-sm font-medium rounded-lg transition-all",
                          activeTab === 'targets' ? "bg-gray-800 text-white shadow-sm" : "text-gray-500 hover:text-gray-300"
                        )}
                        data-testid="tab-targets"
                      >
                        Alarmlar
                      </button>
                      <button
                        onClick={() => setActiveTab('notes')}
                        className={cn(
                          "flex-1 py-2 text-sm font-medium rounded-lg transition-all",
                          activeTab === 'notes' ? "bg-gray-800 text-white shadow-sm" : "text-gray-500 hover:text-gray-300"
                        )}
                        data-testid="tab-notes"
                      >
                        AI Notlar
                      </button>
                    </div>

                    <div className="min-h-[300px]">
                      {activeTab === 'chart' ? (
                        <div className="space-y-4">
                          {candlesLoading ? (
                            <div className="flex justify-center py-10">
                              <div className="animate-spin w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full" />
                            </div>
                          ) : candleData ? (
                            <>
                              {candleData.candles && candleData.candles.length > 0 && (
                                <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
                                  <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                                    <CandlestickIcon className="w-4 h-4" />
                                    100 Günlük Grafik
                                  </h3>
                                  <CandlestickChart candles={candleData.candles} height={280} />
                                </div>
                              )}

                              <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl p-4 border border-gray-800">
                                <div className="flex items-center justify-between mb-3">
                                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                                    <Activity className="w-4 h-4 text-blue-400" />
                                    TradingView Sinyal
                                  </h3>
                                  <span className={cn("text-lg font-bold", getRecommendationColor(candleData.indicators.recommendation))}>
                                    {getRecommendationText(candleData.indicators.recommendation)}
                                  </span>
                                </div>
                                
                                <div className="flex gap-2 mb-4">
                                  <div className="flex-1 bg-emerald-500/20 rounded-lg p-2 text-center">
                                    <p className="text-xs text-gray-400">Al</p>
                                    <p className="text-lg font-bold text-emerald-400">{candleData.indicators.buy_signals}</p>
                                  </div>
                                  <div className="flex-1 bg-yellow-500/20 rounded-lg p-2 text-center">
                                    <p className="text-xs text-gray-400">Nötr</p>
                                    <p className="text-lg font-bold text-yellow-400">{candleData.indicators.neutral_signals}</p>
                                  </div>
                                  <div className="flex-1 bg-red-500/20 rounded-lg p-2 text-center">
                                    <p className="text-xs text-gray-400">Sat</p>
                                    <p className="text-lg font-bold text-red-400">{candleData.indicators.sell_signals}</p>
                                  </div>
                                </div>
                              </div>

                              <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
                                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Günlük OHLCV</h3>
                                <div className="grid grid-cols-2 gap-3">
                                  <div className="bg-gray-800/50 rounded-lg p-3">
                                    <p className="text-xs text-gray-500">Açılış</p>
                                    <p className="text-lg font-mono font-bold text-white">₺{candleData.candle.open}</p>
                                  </div>
                                  <div className="bg-gray-800/50 rounded-lg p-3">
                                    <p className="text-xs text-gray-500">Kapanış</p>
                                    <p className="text-lg font-mono font-bold text-white">₺{candleData.candle.close}</p>
                                  </div>
                                  <div className="bg-gray-800/50 rounded-lg p-3">
                                    <p className="text-xs text-gray-500 flex items-center gap-1">
                                      <TrendingUp className="w-3 h-3 text-emerald-400" /> Yüksek
                                    </p>
                                    <p className="text-lg font-mono font-bold text-emerald-400">₺{candleData.candle.high}</p>
                                  </div>
                                  <div className="bg-gray-800/50 rounded-lg p-3">
                                    <p className="text-xs text-gray-500 flex items-center gap-1">
                                      <TrendingDown className="w-3 h-3 text-red-400" /> Düşük
                                    </p>
                                    <p className="text-lg font-mono font-bold text-red-400">₺{candleData.candle.low}</p>
                                  </div>
                                </div>
                                <div className="mt-3 bg-gray-800/50 rounded-lg p-3">
                                  <p className="text-xs text-gray-500">Hacim</p>
                                  <p className="text-lg font-mono font-bold text-blue-400">
                                    {candleData.candle.volume.toLocaleString('tr-TR')}
                                  </p>
                                </div>
                              </div>

                              <div className="bg-gray-900 rounded-xl p-4 border border-gray-800">
                                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Teknik Göstergeler</h3>
                                <div className="space-y-2">
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">RSI (14)</span>
                                    <span className={cn("font-mono font-medium", 
                                      candleData.indicators.rsi && candleData.indicators.rsi > 70 ? "text-red-400" :
                                      candleData.indicators.rsi && candleData.indicators.rsi < 30 ? "text-emerald-400" : "text-white"
                                    )}>
                                      {candleData.indicators.rsi ?? "—"}
                                    </span>
                                  </div>
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">MACD</span>
                                    <span className={cn("font-mono font-medium",
                                      candleData.indicators.macd && candleData.indicators.macd > 0 ? "text-emerald-400" : "text-red-400"
                                    )}>
                                      {candleData.indicators.macd ?? "—"}
                                    </span>
                                  </div>
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">SMA 20</span>
                                    <span className="font-mono font-medium text-white">₺{candleData.indicators.sma20 ?? "—"}</span>
                                  </div>
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">SMA 50</span>
                                    <span className="font-mono font-medium text-white">₺{candleData.indicators.sma50 ?? "—"}</span>
                                  </div>
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">Bollinger Üst</span>
                                    <span className="font-mono font-medium text-white">₺{candleData.indicators.bb_upper ?? "—"}</span>
                                  </div>
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">Bollinger Alt</span>
                                    <span className="font-mono font-medium text-white">₺{candleData.indicators.bb_lower ?? "—"}</span>
                                  </div>
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">ATR</span>
                                    <span className="font-mono font-medium text-white">{candleData.indicators.atr ?? "—"}</span>
                                  </div>
                                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                                    <span className="text-sm text-gray-400">ADX</span>
                                    <span className="font-mono font-medium text-white">{candleData.indicators.adx ?? "—"}</span>
                                  </div>
                                  <div className="flex justify-between items-center py-2">
                                    <span className="text-sm text-gray-400">Stochastic K/D</span>
                                    <span className="font-mono font-medium text-white">
                                      {candleData.indicators.stoch_k ?? "—"} / {candleData.indicators.stoch_d ?? "—"}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </>
                          ) : (
                            <div className="text-center py-10 text-gray-500">
                              Grafik verisi yüklenemedi. Fiyatı güncelleyerek tekrar deneyin.
                            </div>
                          )}
                        </div>
                      ) : activeTab === 'targets' ? (
                        <div className="space-y-6">
                          <div className="grid grid-cols-5 gap-2 mb-2">
                            {[-10, -5, -3, 3, 5, 10].map((pct) => {
                              const price = stock.currentPrice ? (stock.currentPrice * (1 + pct/100)).toFixed(2) : "0";
                              return (
                                <button
                                  key={pct}
                                  type="button"
                                  onClick={() => setTargetPrice(price)}
                                  className={cn(
                                    "py-2 px-1 rounded-lg text-xs font-medium transition-all",
                                    pct > 0 
                                      ? "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                                      : "bg-red-500/10 text-red-400 hover:bg-red-500/20"
                                  )}
                                  data-testid={`button-percent-${pct}`}
                                >
                                  {pct > 0 ? `+${pct}%` : `${pct}%`}
                                </button>
                              );
                            })}
                          </div>
                          
                          <form onSubmit={handleAddTarget} className="flex gap-3">
                            <div className="relative flex-1">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₺</span>
                              <input
                                type="number"
                                step="0.01"
                                placeholder="Alarm Fiyatı"
                                value={targetPrice}
                                onChange={(e) => setTargetPrice(e.target.value)}
                                className="w-full bg-gray-900 border border-gray-800 rounded-xl py-3 pl-7 pr-4 text-white focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-gray-600"
                                data-testid="input-target-price"
                              />
                              {targetPrice && stock.currentPrice && (
                                <span className={cn(
                                  "absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium",
                                  parseFloat(targetPrice) > stock.currentPrice ? "text-emerald-400" : "text-red-400"
                                )}>
                                  {((parseFloat(targetPrice) - stock.currentPrice) / stock.currentPrice * 100).toFixed(1)}%
                                </span>
                              )}
                            </div>
                            <button 
                              disabled={createTarget.isPending || !targetPrice}
                              className="bg-emerald-600 text-white p-3 rounded-xl hover:bg-emerald-500 disabled:opacity-50 transition-colors"
                              data-testid="button-add-target"
                            >
                              {createTarget.isPending ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Plus className="w-5 h-5" />}
                            </button>
                          </form>

                          <div className="space-y-3">
                            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Aktif Alarmlar</h3>
                            {stock.targets && stock.targets.length > 0 ? (
                              stock.targets.map((target) => {
                                const diff = stock.currentPrice 
                                  ? ((target.targetPrice - stock.currentPrice) / stock.currentPrice * 100)
                                  : 0;
                                const isAbove = diff > 0;
                                return (
                                  <div key={target.id} className="flex items-center justify-between bg-gray-900/50 border border-gray-800 p-4 rounded-xl group">
                                    <div className="flex items-center space-x-3">
                                      <div className={cn(
                                        "w-8 h-8 rounded-full flex items-center justify-center",
                                        isAbove ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"
                                      )}>
                                        {isAbove ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                                      </div>
                                      <div>
                                        <div className="flex items-center gap-2">
                                          <p className="text-white font-mono font-medium">₺{target.targetPrice}</p>
                                          <span className={cn(
                                            "text-xs font-medium px-1.5 py-0.5 rounded",
                                            isAbove ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"
                                          )}>
                                            {isAbove ? "+" : ""}{diff.toFixed(1)}%
                                          </span>
                                        </div>
                                        <p className="text-[10px] text-gray-500">{new Date(target.createdAt!).toLocaleDateString('tr-TR')}</p>
                                      </div>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                      <div className={cn("w-2 h-2 rounded-full", target.isActive ? "bg-emerald-500" : "bg-gray-700")} />
                                      <button 
                                        onClick={() => handleDeleteTarget(target.id)}
                                        className="p-2 text-gray-600 hover:text-red-400 transition-colors"
                                        data-testid={`button-delete-target-${target.id}`}
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </button>
                                    </div>
                                  </div>
                                );
                              })
                            ) : (
                              <div className="text-center py-8 text-gray-600 text-sm">
                                Aktif alarm yok. Yukarıdan alarm ekleyin.
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div className="bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border border-indigo-500/20 rounded-xl p-4">
                            <div className="flex items-start justify-between">
                              <div className="space-y-1">
                                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                                  <Sparkles className="w-4 h-4 text-purple-400" />
                                  Gemini Analiz
                                </h3>
                                <p className="text-xs text-gray-400 leading-relaxed max-w-[240px]">
                                  Notlarınızı ve son fiyat hareketlerini analiz ederek yatırım önerisi alın.
                                </p>
                              </div>
                              <button 
                                onClick={handleAnalysis}
                                disabled={analyzeNotes.isPending}
                                className="p-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-white transition-colors disabled:opacity-50"
                                data-testid="button-analyze"
                              >
                                {analyzeNotes.isPending ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <BrainCircuit className="w-4 h-4" />}
                              </button>
                            </div>
                            
                            {stock.notes?.some(n => n.aiAnalysis) && (
                              <div className="mt-4 pt-4 border-t border-indigo-500/10">
                                <p className="text-sm text-indigo-200/80 italic">
                                  "{stock.notes.find(n => n.aiAnalysis)?.aiAnalysis}"
                                </p>
                              </div>
                            )}
                          </div>

                          <form onSubmit={handleAddNote} className="space-y-3">
                            <textarea
                              value={noteContent}
                              onChange={(e) => setNoteContent(e.target.value)}
                              placeholder="Gözlemlerinizi yazın..."
                              className="w-full h-24 bg-gray-900 border border-gray-800 rounded-xl p-4 text-sm text-white focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 resize-none placeholder:text-gray-600"
                              data-testid="textarea-note"
                            />
                            <div className="flex justify-end">
                              <button 
                                disabled={createNote.isPending || !noteContent.trim()}
                                className="flex items-center space-x-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50"
                                data-testid="button-save-note"
                              >
                                {createNote.isPending ? <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Send className="w-3 h-3" />}
                                <span>Notu Kaydet</span>
                              </button>
                            </div>
                          </form>

                          <div className="space-y-4">
                            {stock.notes && stock.notes.length > 0 ? (
                              stock.notes.map((note) => (
                                <div key={note.id} className="bg-gray-900/30 p-4 rounded-xl border border-gray-800/50">
                                  <p className="text-sm text-gray-300 leading-relaxed">{note.content}</p>
                                  <p className="text-[10px] text-gray-600 mt-2 text-right">
                                    {new Date(note.createdAt!).toLocaleString('tr-TR')}
                                  </p>
                                </div>
                              ))
                            ) : (
                              <div className="text-center py-8 text-gray-600 text-sm">
                                Henüz not yok. Yukarıya bir şeyler yazın.
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
