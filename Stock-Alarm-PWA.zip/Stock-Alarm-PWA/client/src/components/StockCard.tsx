import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { type Stock, type Target } from "@shared/schema";

interface StockCardProps {
  stock: Stock & { targets?: Target[] };
  onClick: () => void;
}

export function StockCard({ stock, onClick }: StockCardProps) {
  // Determine if stock is near a target (e.g., within 5%)
  const activeTargets = stock.targets?.filter(t => t.isActive) || [];
  const isOpportunity = activeTargets.some(target => 
    stock.currentPrice && stock.currentPrice <= target.targetPrice * 1.05
  );

  const priceChange = 0.5; // This would normally come from API if tracked day-over-day
  const isUp = priceChange >= 0;

  return (
    <motion.div
      layoutId={`stock-card-${stock.id}`}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="relative overflow-hidden rounded-2xl bg-gray-900 border border-gray-800/50 p-5 shadow-lg hover:border-gray-700 transition-colors cursor-pointer group"
    >
      {/* Background Gradient for "Opportunity" */}
      {isOpportunity && (
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/5 to-transparent pointer-events-none" />
      )}

      <div className="flex justify-between items-start relative z-10">
        <div className="flex flex-col">
          <div className="flex items-center space-x-2">
            <h3 className="text-lg font-bold text-white tracking-wide">{stock.symbol}</h3>
            {isOpportunity && (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/20">
                ALIM FIRSATI
              </span>
            )}
          </div>
          <p className="text-sm text-gray-400 font-medium truncate max-w-[120px] sm:max-w-xs">
            {stock.name}
          </p>
        </div>

        <div className="flex flex-col items-end">
          <div className="flex items-center space-x-1">
            <span className={cn(
              "text-2xl font-mono font-bold tracking-tight text-glow",
              isUp ? "text-white" : "text-white"
            )}>
              ₺{stock.currentPrice?.toFixed(2) ?? "---"}
            </span>
          </div>
          <div className={cn(
            "flex items-center text-xs font-medium mt-1",
            isUp ? "text-emerald-500" : "text-red-500"
          )}>
            {isUp ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
            <span>{isUp ? "+" : ""}{priceChange}%</span>
          </div>
        </div>
      </div>
      
      {/* Decorative Chevron */}
      <div className="absolute right-4 bottom-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <ArrowRight className="w-4 h-4 text-gray-600" />
      </div>
    </motion.div>
  );
}
