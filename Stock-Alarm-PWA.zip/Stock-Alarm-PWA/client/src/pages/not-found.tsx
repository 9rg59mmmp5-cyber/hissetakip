import { Link } from "wouter";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-gray-950 px-4 text-center">
      <div className="w-20 h-20 bg-gray-900 rounded-full flex items-center justify-center mb-6 border border-gray-800">
        <AlertCircle className="w-10 h-10 text-red-500" />
      </div>
      <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">404</h1>
      <p className="text-gray-400 mb-8 max-w-xs mx-auto">
        The page you are looking for does not exist or has been moved.
      </p>

      <Link href="/">
        <button className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl transition-colors shadow-lg shadow-emerald-900/20">
          Back to Market
        </button>
      </Link>
    </div>
  );
}
