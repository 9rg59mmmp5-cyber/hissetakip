import { useState, useEffect } from "react";
import { 
  Settings as SettingsIcon, Bell, RefreshCw, Clock, Send, Loader2,
  CheckCircle, XCircle, Smartphone, MessageCircle
} from "lucide-react";
import { SiTelegram } from "react-icons/si";
import { BottomNav } from "@/components/BottomNav";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

interface TelegramSettings {
  enabled: boolean;
  chatIds: string[];
}

interface AutoRefreshSettings {
  enabled: boolean;
  intervalMinutes: number;
}

interface PeriodicTelegramSettings {
  enabled: boolean;
  intervalHours: number;
  scanType: string;
}

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [telegramEnabled, setTelegramEnabled] = useState(true);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(false);
  const [autoRefreshInterval, setAutoRefreshInterval] = useState(30);
  const [periodicTelegramEnabled, setPeriodicTelegramEnabled] = useState(false);
  const [periodicTelegramInterval, setPeriodicTelegramInterval] = useState(4);
  const [periodicScanType, setPeriodicScanType] = useState("best_signals");

  const { data: telegramSettings } = useQuery<TelegramSettings>({
    queryKey: ['/api/settings/telegram'],
  });

  useEffect(() => {
    if (telegramSettings) {
      setTelegramEnabled(telegramSettings.enabled);
    }
  }, [telegramSettings]);

  const testTelegramMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/settings/telegram/test", { method: "POST" });
      if (!res.ok) throw new Error("Test başarısız");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Telegram Test", description: "Test mesajı gönderildi" });
    },
    onError: () => {
      toast({ title: "Hata", description: "Telegram test mesajı gönderilemedi", variant: "destructive" });
    }
  });

  const updateTelegramMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      const res = await fetch("/api/settings/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled })
      });
      if (!res.ok) throw new Error("Güncelleme başarısız");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings/telegram'] });
      toast({ title: "Ayarlar Güncellendi" });
    }
  });

  const saveAutoRefreshMutation = useMutation({
    mutationFn: async (settings: AutoRefreshSettings) => {
      const res = await fetch("/api/settings/auto-refresh", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error("Kayıt başarısız");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Otomatik Güncelleme Ayarlandı" });
    }
  });

  const savePeriodicTelegramMutation = useMutation({
    mutationFn: async (settings: PeriodicTelegramSettings) => {
      const res = await fetch("/api/settings/periodic-telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error("Kayıt başarısız");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Periyodik Telegram Ayarlandı" });
    }
  });

  const handleTelegramToggle = () => {
    const newValue = !telegramEnabled;
    setTelegramEnabled(newValue);
    updateTelegramMutation.mutate(newValue);
  };

  const handleSaveAutoRefresh = () => {
    saveAutoRefreshMutation.mutate({
      enabled: autoRefreshEnabled,
      intervalMinutes: autoRefreshInterval
    });
  };

  const handleSavePeriodicTelegram = () => {
    savePeriodicTelegramMutation.mutate({
      enabled: periodicTelegramEnabled,
      intervalHours: periodicTelegramInterval,
      scanType: periodicScanType
    });
  };

  const sendAlarmsMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/telegram/send-alarms", { method: "POST" });
      if (!res.ok) throw new Error("Gönderim başarısız");
      return res.json();
    },
    onSuccess: (data) => {
      toast({ 
        title: "Alarmlar Gönderildi", 
        description: `${data.count} aktif alarm Telegram'a gönderildi` 
      });
    },
    onError: () => {
      toast({ 
        title: "Hata", 
        description: "Alarmlar gönderilemedi", 
        variant: "destructive" 
      });
    }
  });

  return (
    <div className="min-h-screen bg-gray-950 pb-24">
      <header className="sticky top-0 z-30 bg-gray-950/90 backdrop-blur-md border-b border-gray-800">
        <div className="px-4 py-4">
          <div className="flex items-center gap-3">
            <SettingsIcon className="w-6 h-6 text-emerald-500" />
            <h1 className="text-xl font-bold text-white tracking-tight">Ayarlar</h1>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 space-y-6">
        <div className="bg-gray-900 rounded-2xl border border-gray-800 overflow-hidden">
          <div className="p-4 border-b border-gray-800 flex items-center gap-3">
            <SiTelegram className="w-5 h-5 text-blue-400" />
            <h2 className="font-semibold text-white">Telegram Bildirimleri</h2>
          </div>
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white font-medium">Bildirimleri Aktif Et</p>
                <p className="text-xs text-gray-500">Alarmlar Telegram'a gönderilsin</p>
              </div>
              <button
                onClick={handleTelegramToggle}
                className={cn(
                  "w-12 h-6 rounded-full transition-colors relative",
                  telegramEnabled ? "bg-emerald-500" : "bg-gray-700"
                )}
                data-testid="toggle-telegram"
              >
                <div className={cn(
                  "absolute top-1 w-4 h-4 bg-white rounded-full transition-transform",
                  telegramEnabled ? "translate-x-7" : "translate-x-1"
                )} />
              </button>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => testTelegramMutation.mutate()}
                disabled={testTelegramMutation.isPending || !telegramEnabled}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-xl text-white font-medium flex items-center justify-center gap-2 transition-colors"
                data-testid="button-test-telegram"
              >
                {testTelegramMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                Test
              </button>
              <button
                onClick={() => sendAlarmsMutation.mutate()}
                disabled={sendAlarmsMutation.isPending || !telegramEnabled}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-xl text-white font-medium flex items-center justify-center gap-2 transition-colors"
                data-testid="button-send-alarms"
              >
                {sendAlarmsMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Bell className="w-4 h-4" />
                )}
                Alarmları Gönder
              </button>
            </div>
          </div>
        </div>

        <div className="bg-gray-900 rounded-2xl border border-gray-800 overflow-hidden">
          <div className="p-4 border-b border-gray-800 flex items-center gap-3">
            <RefreshCw className="w-5 h-5 text-purple-400" />
            <h2 className="font-semibold text-white">Otomatik Fiyat Güncelleme</h2>
          </div>
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white font-medium">Otomatik Güncelleme</p>
                <p className="text-xs text-gray-500">Hisse fiyatları periyodik olarak güncellensin</p>
              </div>
              <button
                onClick={() => setAutoRefreshEnabled(!autoRefreshEnabled)}
                className={cn(
                  "w-12 h-6 rounded-full transition-colors relative",
                  autoRefreshEnabled ? "bg-emerald-500" : "bg-gray-700"
                )}
                data-testid="toggle-auto-refresh"
              >
                <div className={cn(
                  "absolute top-1 w-4 h-4 bg-white rounded-full transition-transform",
                  autoRefreshEnabled ? "translate-x-7" : "translate-x-1"
                )} />
              </button>
            </div>
            
            {autoRefreshEnabled && (
              <div className="space-y-2">
                <label className="text-sm text-gray-400">Güncelleme Aralığı (dakika)</label>
                <div className="flex gap-2">
                  {[15, 30, 60].map((min) => (
                    <button
                      key={min}
                      onClick={() => setAutoRefreshInterval(min)}
                      className={cn(
                        "flex-1 py-2 rounded-lg text-sm font-medium transition-colors",
                        autoRefreshInterval === min 
                          ? "bg-purple-500 text-white" 
                          : "bg-gray-800 text-gray-400 hover:text-white"
                      )}
                      data-testid={`interval-${min}`}
                    >
                      {min} dk
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            <button
              onClick={handleSaveAutoRefresh}
              disabled={saveAutoRefreshMutation.isPending}
              className="w-full py-3 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 rounded-xl text-white font-medium flex items-center justify-center gap-2 transition-colors"
              data-testid="button-save-auto-refresh"
            >
              {saveAutoRefreshMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4" />
              )}
              Kaydet
            </button>
          </div>
        </div>

        <div className="bg-gray-900 rounded-2xl border border-gray-800 overflow-hidden">
          <div className="p-4 border-b border-gray-800 flex items-center gap-3">
            <Clock className="w-5 h-5 text-amber-400" />
            <h2 className="font-semibold text-white">Periyodik Telegram Tarama</h2>
          </div>
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white font-medium">Periyodik Gönderim</p>
                <p className="text-xs text-gray-500">En iyi fırsatları otomatik Telegram'a gönder</p>
              </div>
              <button
                onClick={() => setPeriodicTelegramEnabled(!periodicTelegramEnabled)}
                className={cn(
                  "w-12 h-6 rounded-full transition-colors relative",
                  periodicTelegramEnabled ? "bg-emerald-500" : "bg-gray-700"
                )}
                data-testid="toggle-periodic-telegram"
              >
                <div className={cn(
                  "absolute top-1 w-4 h-4 bg-white rounded-full transition-transform",
                  periodicTelegramEnabled ? "translate-x-7" : "translate-x-1"
                )} />
              </button>
            </div>
            
            {periodicTelegramEnabled && (
              <>
                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Gönderim Aralığı (saat)</label>
                  <div className="flex gap-2">
                    {[2, 4, 8, 12].map((hr) => (
                      <button
                        key={hr}
                        onClick={() => setPeriodicTelegramInterval(hr)}
                        className={cn(
                          "flex-1 py-2 rounded-lg text-sm font-medium transition-colors",
                          periodicTelegramInterval === hr 
                            ? "bg-amber-500 text-white" 
                            : "bg-gray-800 text-gray-400 hover:text-white"
                        )}
                        data-testid={`periodic-${hr}`}
                      >
                        {hr} sa
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Tarama Tipi</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "best_signals", label: "En İyi Sinyaller" },
                      { value: "volume_surge", label: "Hacim Patlaması" },
                      { value: "rsi_oversold", label: "Aşırı Satım" },
                      { value: "macd_cross", label: "MACD Kesişim" }
                    ].map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => setPeriodicScanType(opt.value)}
                        className={cn(
                          "py-2 px-3 rounded-lg text-sm font-medium transition-colors",
                          periodicScanType === opt.value 
                            ? "bg-amber-500 text-white" 
                            : "bg-gray-800 text-gray-400 hover:text-white"
                        )}
                        data-testid={`scan-type-${opt.value}`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
            
            <button
              onClick={handleSavePeriodicTelegram}
              disabled={savePeriodicTelegramMutation.isPending}
              className="w-full py-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 rounded-xl text-white font-medium flex items-center justify-center gap-2 transition-colors"
              data-testid="button-save-periodic"
            >
              {savePeriodicTelegramMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4" />
              )}
              Kaydet
            </button>
          </div>
        </div>

        <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-800">
          <p className="text-xs text-gray-500 text-center">
            HisseAvcısı v1.0 - BIST Hisse Takip ve Analiz
          </p>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
