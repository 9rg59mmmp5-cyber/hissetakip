import { useState, useEffect } from "react";
import { Bell, Target, Settings, Send, Loader2, MessageCircle, History, Power, X, Plus, Filter, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Smartphone, Globe, Phone } from "lucide-react";
import { SiTelegram, SiWhatsapp } from "react-icons/si";
import { BottomNav } from "@/components/BottomNav";
import { useStocks } from "@/hooks/use-stocks";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface AlarmHistoryItem {
  id: number;
  triggeredPrice: number;
  channel: string;
  sentAt: string;
  stock: { symbol: string; name: string };
  target: { targetPrice: number; note: string | null };
}

type FilterType = "all" | "near" | "far" | "up" | "down";

export default function Notifications() {
  const { data: stocks } = useStocks();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [newChatId, setNewChatId] = useState("");
  const [filterType, setFilterType] = useState<FilterType>("all");
  const [browserNotifEnabled, setBrowserNotifEnabled] = useState(false);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>("default");

  useEffect(() => {
    if ("Notification" in window) {
      setNotifPermission(Notification.permission);
      const stored = localStorage.getItem("browserNotifEnabled");
      setBrowserNotifEnabled(stored === "true" && Notification.permission === "granted");
    }
  }, []);

  const requestBrowserNotification = async () => {
    if (!("Notification" in window)) {
      toast({ title: "Hata", description: "Tarayıcınız bildirimleri desteklemiyor", variant: "destructive" });
      return;
    }
    
    const permission = await Notification.requestPermission();
    setNotifPermission(permission);
    
    if (permission === "granted") {
      setBrowserNotifEnabled(true);
      localStorage.setItem("browserNotifEnabled", "true");
      new Notification("HisseAvcısı", {
        body: "Tarayıcı bildirimleri etkinleştirildi!",
        icon: "/favicon.ico"
      });
      toast({ title: "Başarılı", description: "Tarayıcı bildirimleri açıldı" });
    } else {
      toast({ title: "İzin Reddedildi", description: "Lütfen tarayıcı ayarlarından bildirimlere izin verin", variant: "destructive" });
    }
  };

  const toggleBrowserNotification = () => {
    if (browserNotifEnabled) {
      setBrowserNotifEnabled(false);
      localStorage.setItem("browserNotifEnabled", "false");
      toast({ title: "Bildirimler Kapatıldı" });
    } else {
      if (notifPermission === "granted") {
        setBrowserNotifEnabled(true);
        localStorage.setItem("browserNotifEnabled", "true");
        toast({ title: "Bildirimler Açıldı" });
      } else {
        requestBrowserNotification();
      }
    }
  };

  const { data: telegramSettings, refetch: refetchSettings } = useQuery({
    queryKey: ["/api/settings/telegram"],
    queryFn: async () => {
      const res = await fetch("/api/settings/telegram");
      if (!res.ok) throw new Error("Failed to fetch settings");
      return res.json() as Promise<{ enabled: boolean; chatIds: string[] }>;
    }
  });

  const { data: alarmHistory } = useQuery({
    queryKey: ["/api/alarm-history"],
    queryFn: async () => {
      const res = await fetch("/api/alarm-history");
      if (!res.ok) return [];
      return res.json() as Promise<AlarmHistoryItem[]>;
    }
  });

  const updateSettings = useMutation({
    mutationFn: async (settings: { chatIds?: string[]; enabled?: boolean }) => {
      const res = await fetch("/api/settings/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error("Failed to update settings");
      return res.json();
    },
    onSuccess: () => {
      refetchSettings();
      toast({
        title: "Ayarlar Güncellendi",
        description: "Telegram ayarları kaydedildi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Ayarlar kaydedilemedi",
        variant: "destructive",
      });
    }
  });

  const testTelegram = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/settings/telegram/test", { method: "POST" });
      if (!res.ok) throw new Error("Test failed");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Test Bildirimi Gönderildi",
          description: "Telegram'ı kontrol edin",
        });
      } else {
        toast({
          title: "Hata",
          description: "Test bildirimi gönderilemedi",
          variant: "destructive",
        });
      }
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Test bildirimi gönderilemedi",
        variant: "destructive",
      });
    }
  });

  const handleAddChatId = () => {
    if (!newChatId.trim()) return;
    const currentIds = telegramSettings?.chatIds || [];
    if (currentIds.includes(newChatId.trim())) {
      toast({ title: "Uyarı", description: "Bu Chat ID zaten ekli", variant: "destructive" });
      return;
    }
    updateSettings.mutate({ chatIds: [...currentIds, newChatId.trim()] });
    setNewChatId("");
  };

  const handleRemoveChatId = (idToRemove: string) => {
    const currentIds = telegramSettings?.chatIds || [];
    updateSettings.mutate({ chatIds: currentIds.filter(id => id !== idToRemove) });
  };

  const handleToggleEnabled = () => {
    updateSettings.mutate({ enabled: !telegramSettings?.enabled });
  };

  const allAlerts = stocks?.flatMap(stock => 
    (stock.targets || [])
      .filter(t => t.isActive)
      .map(target => {
        const current = stock.currentPrice || 0;
        const targetPrice = target.targetPrice;
        const hasPrice = current > 0;
        const diffPercent = hasPrice ? ((targetPrice - current) / current) * 100 : 0;
        const absDiff = Math.abs(diffPercent);
        const isUp = diffPercent > 0;
        const isNear = hasPrice ? absDiff <= 5 : false;
        return {
          id: target.id,
          symbol: stock.symbol,
          current,
          target: targetPrice,
          note: target.note,
          diffPercent,
          absDiff,
          isUp,
          isNear,
          hasPrice
        };
      })
  ).sort((a, b) => a.absDiff - b.absDiff) || [];

  const activeAlerts = allAlerts.filter(alert => {
    if (filterType === "all") return true;
    if (filterType === "near") return alert.absDiff <= 5;
    if (filterType === "far") return alert.absDiff > 5;
    if (filterType === "up") return alert.isUp;
    if (filterType === "down") return !alert.isUp;
    return true;
  });

  const nearCount = allAlerts.filter(a => a.absDiff <= 5).length;
  const farCount = allAlerts.filter(a => a.absDiff > 5).length;
  const upCount = allAlerts.filter(a => a.isUp).length;
  const downCount = allAlerts.filter(a => !a.isUp).length;

  return (
    <div className="min-h-screen pb-24 bg-gray-950">
      <header className="pt-12 pb-6 px-6 sticky top-0 z-30 bg-gray-950/80 backdrop-blur-md border-b border-gray-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Bell className="w-6 h-6 text-emerald-500" />
            <h1 className="text-2xl font-bold text-white">Alarmlar</h1>
          </div>
          <div className="flex items-center gap-1">
            <button 
              onClick={() => { setShowHistory(!showHistory); setShowSettings(false); }}
              data-testid="button-toggle-history"
              className={`p-2 rounded-lg transition-colors ${showHistory ? "text-amber-400 bg-amber-400/10" : "text-gray-400 hover:text-white"}`}
            >
              <History className="w-5 h-5" />
            </button>
            <button 
              onClick={() => { setShowSettings(!showSettings); setShowHistory(false); }}
              data-testid="button-toggle-settings"
              className={`p-2 rounded-lg transition-colors ${showSettings ? "text-blue-400 bg-blue-400/10" : "text-gray-400 hover:text-white"}`}
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="px-4 py-4 space-y-4">
        {showSettings && (
          <div className="space-y-4">
            <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-4 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <Globe className="w-5 h-5 text-blue-400" />
                Tarayıcı Bildirimleri
              </h3>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400 text-sm">Push Bildirimler</span>
                </div>
                <button
                  onClick={toggleBrowserNotification}
                  data-testid="button-toggle-browser-notif"
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    browserNotifEnabled 
                      ? "bg-emerald-600/20 text-emerald-400 border border-emerald-500/30" 
                      : "bg-gray-700/50 text-gray-400 border border-gray-600/30"
                  }`}
                >
                  <Power className="w-4 h-4" />
                  {browserNotifEnabled ? "Açık" : "Kapalı"}
                </button>
              </div>
              
              {notifPermission === "denied" && (
                <p className="text-xs text-amber-400 bg-amber-500/10 px-3 py-2 rounded-lg">
                  Tarayıcı bildirimleri engellendi. Lütfen tarayıcı ayarlarından izin verin.
                </p>
              )}
            </div>
            
            <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-4 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <SiTelegram className="w-5 h-5 text-[#0088cc]" />
                Telegram Ayarları
              </h3>
            
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-sm">Bildirimler</span>
                <button
                  onClick={handleToggleEnabled}
                  disabled={updateSettings.isPending}
                  data-testid="button-toggle-telegram"
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    telegramSettings?.enabled 
                      ? "bg-emerald-600/20 text-emerald-400 border border-emerald-500/30" 
                      : "bg-gray-700/50 text-gray-400 border border-gray-600/30"
                  }`}
                >
                  <Power className="w-4 h-4" />
                  {telegramSettings?.enabled ? "Açık" : "Kapalı"}
                </button>
              </div>
              
              <div className="space-y-2">
                <label className="text-gray-400 text-sm">Chat ID'ler</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newChatId}
                    onChange={(e) => setNewChatId(e.target.value)}
                    placeholder="Chat ID girin"
                    data-testid="input-chat-id"
                    className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm placeholder:text-gray-500 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    onClick={handleAddChatId}
                    disabled={!newChatId.trim() || updateSettings.isPending}
                    data-testid="button-add-chat-id"
                    className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-lg text-white"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
                
                {telegramSettings?.chatIds && telegramSettings.chatIds.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {telegramSettings.chatIds.map((chatId) => (
                      <div 
                        key={chatId}
                        className="flex items-center gap-1 px-2 py-1 bg-gray-800 rounded text-sm text-gray-300 font-mono"
                      >
                        {chatId}
                        <button
                          onClick={() => handleRemoveChatId(chatId)}
                          data-testid={`button-remove-chat-${chatId}`}
                          className="ml-1 text-gray-500 hover:text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
                <button
                  onClick={() => testTelegram.mutate()}
                  disabled={testTelegram.isPending || !telegramSettings?.chatIds?.length}
                  data-testid="button-test-telegram"
                  className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg font-medium text-white flex items-center justify-center gap-2 transition-all"
                >
                  {testTelegram.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  Test Bildirimi Gönder
                </button>
              </div>
            </div>
          </div>
        )}

        {showHistory && (
          <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-4 space-y-3">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <History className="w-5 h-5 text-amber-400" />
              Alarm Geçmişi
            </h3>
            {alarmHistory && alarmHistory.length > 0 ? (
              <div className="space-y-2">
                {alarmHistory.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                    <div>
                      <span className="font-semibold text-white">{item.stock?.symbol}</span>
                      <span className="text-gray-500 text-sm ml-2">₺{item.triggeredPrice?.toFixed(2)}</span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(item.sentAt).toLocaleDateString("tr-TR")}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-gray-500 text-sm">Henüz tetiklenen alarm yok</p>
              </div>
            )}
          </div>
        )}

        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-lg font-semibold text-white">Aktif Alarmlar</h2>
            <span className="text-sm text-gray-500">{activeAlerts.length} / {allAlerts.length} alarm</span>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setFilterType("all")}
              data-testid="filter-all"
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filterType === "all" ? "bg-blue-500 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
              }`}
            >
              Tümü ({allAlerts.length})
            </button>
            <button
              onClick={() => setFilterType("near")}
              data-testid="filter-near"
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filterType === "near" ? "bg-emerald-500 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
              }`}
            >
              Yakın ≤5% ({nearCount})
            </button>
            <button
              onClick={() => setFilterType("far")}
              data-testid="filter-far"
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filterType === "far" ? "bg-amber-500 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
              }`}
            >
              Uzak &gt;5% ({farCount})
            </button>
            <button
              onClick={() => setFilterType("up")}
              data-testid="filter-up"
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${
                filterType === "up" ? "bg-green-500 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
              }`}
            >
              <ArrowUpRight className="w-3 h-3" /> Yukarı ({upCount})
            </button>
            <button
              onClick={() => setFilterType("down")}
              data-testid="filter-down"
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${
                filterType === "down" ? "bg-red-500 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
              }`}
            >
              <ArrowDownRight className="w-3 h-3" /> Aşağı ({downCount})
            </button>
          </div>
        </div>

        {activeAlerts.length > 0 ? (
          <div className="space-y-3">
            {activeAlerts.map(alert => (
              <div key={alert.id} data-testid={`alert-card-${alert.id}`} className="bg-gray-900/80 border border-gray-800 rounded-xl p-4 flex items-start space-x-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  !alert.hasPrice ? "bg-gray-500/10 text-gray-500" :
                  alert.isUp ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                }`}>
                  {!alert.hasPrice ? <Target className="w-5 h-5" /> :
                   alert.isUp ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start gap-2">
                    <h3 className="font-bold text-white">{alert.symbol}</h3>
                    <div className="flex flex-col items-end gap-1">
                      {alert.hasPrice ? (
                        <>
                          <span className={`text-xs font-mono px-2 py-1 rounded shrink-0 flex items-center gap-1 ${
                            alert.isNear ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"
                          }`}>
                            {alert.isUp ? "+" : ""}{alert.diffPercent.toFixed(2)}%
                          </span>
                          <span className={`text-[10px] font-medium ${
                            alert.isNear ? "text-emerald-500" : "text-amber-500"
                          }`}>
                            {alert.isNear ? "YAKIN" : "UZAK"}
                          </span>
                        </>
                      ) : (
                        <span className="text-xs font-mono px-2 py-1 rounded bg-gray-600/20 text-gray-400">
                          Fiyat Yok
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-sm text-gray-400 mt-1 flex flex-wrap gap-x-2 gap-y-1">
                    <span>Alarm: <span className={`font-mono ${alert.hasPrice ? (alert.isUp ? "text-green-400" : "text-red-400") : "text-gray-300"}`}>₺{alert.target.toFixed(2)}</span></span>
                    <span className="text-gray-600">|</span>
                    <span>Güncel: <span className="text-gray-200 font-mono">{alert.hasPrice ? `₺${alert.current.toFixed(2)}` : "Güncelleniyor..."}</span></span>
                  </div>
                  {alert.note && (
                    <p className="text-xs text-gray-500 mt-2 truncate">{alert.note}</p>
                  )}
                  <div className="mt-3 w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        alert.isNear ? "bg-emerald-500" : "bg-amber-500"
                      }`}
                      style={{ width: `${Math.max(5, Math.min(100, 100 - alert.absDiff * 2))}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-gray-700" />
            </div>
            <h3 className="text-white font-medium">Aktif Alarm Yok</h3>
            <p className="text-gray-500 text-sm mt-2">
              Hisselerinize fiyat alarmı ekleyin
            </p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
