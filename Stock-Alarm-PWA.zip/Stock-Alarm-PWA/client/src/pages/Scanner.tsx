import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Search, Loader2, TrendingUp, TrendingDown, Volume2, BarChart3, 
  RefreshCw, XCircle, Target, Layers, GitBranch, CandlestickChart,
  ArrowUpRight, ArrowDownRight, Zap, Send
} from "lucide-react";
import { SiTelegram } from "react-icons/si";
import { useMutation, useQuery } from "@tanstack/react-query";
import { BottomNav } from "@/components/BottomNav";
import { useToast } from "@/hooks/use-toast";

interface ScanResult {
  stockId: number;
  symbol: string;
  name: string;
  currentPrice: number;
  signal: "AL" | "SAT" | "NÖTR";
  reasons: string[];
  volume?: number;
  volumeChange?: number;
  rsi?: number;
  macd?: number;
}

interface SignalResult {
  symbol: string;
  price: number;
  buySignals: number;
  sellSignals: number;
  neutralSignals: number;
  recommendation: string;
}

interface AdvancedResult {
  symbol: string;
  name: string;
  currentPrice: number;
  current_price: number;
  support_resistance: {
    support: number[];
    resistance: number[];
  };
  trend: {
    trend: string;
    strength: number;
    slope_pct: number;
  };
  fibonacci: {
    swing_high: number;
    swing_low: number;
    fib_50: number;
    fib_61: number;
  };
  order_blocks: {
    bullish_ob: Array<{ high: number; low: number; strength: string }>;
    bearish_ob: Array<{ high: number; low: number; strength: string }>;
  };
  fair_value_gaps: {
    bullish_fvg: Array<{ top: number; bottom: number; gap_size: number }>;
    bearish_fvg: Array<{ top: number; bottom: number; gap_size: number }>;
  };
  volume_profile: {
    poc: number | null;
    value_area_high: number | null;
    value_area_low: number | null;
  };
  candlestick_patterns: {
    patterns: Array<{ pattern: string; type: string; name_tr: string; index: number }>;
  };
  signal: {
    recommendation: string;
    score: number;
    signals: string[];
  };
  basicIndicators?: {
    rsi: number | null;
    macd: number | null;
    recommendation: string;
  };
}

interface ScanResponse {
  results: ScanResult[];
  scannedCount: number;
  matchCount: number;
  scanType: string;
  scanTime?: string;
  totalStocks?: number;
}

interface SignalResponse {
  results: SignalResult[];
  scannedCount: number;
  totalStocks?: number;
  scanTime?: string;
}

type ScanType = "volume_surge" | "green_candles" | "rsi_oversold" | "macd_cross";
type AdvancedScanType = "support_resistance" | "fibonacci" | "order_blocks" | "patterns" | "trend" | "fvg" | "volume_profile";

const SCAN_TYPES = [
  { id: "volume_surge" as ScanType, name: "Hacim Patlaması", icon: Volume2, description: "20 günlük hacim ort. > 100 günlük ort." },
  { id: "green_candles" as ScanType, name: "3 Yeşil Mum", icon: TrendingUp, description: "3 ardışık yeşil mum + artan fiyat" },
  { id: "rsi_oversold" as ScanType, name: "RSI Aşırı Satım", icon: BarChart3, description: "RSI < 30 aşırı satım bölgesi" },
  { id: "macd_cross" as ScanType, name: "MACD Kesişimi", icon: BarChart3, description: "MACD sinyal çizgisinin üzerinde" },
];

const ADVANCED_SCAN_TYPES = [
  { id: "support_resistance" as AdvancedScanType, name: "Destek/Direnç", icon: Layers, description: "Otomatik S/R seviyeleri" },
  { id: "fibonacci" as AdvancedScanType, name: "Fibonacci", icon: GitBranch, description: "Fib retracement seviyeleri" },
  { id: "order_blocks" as AdvancedScanType, name: "Order Block", icon: Target, description: "Smart Money blokları" },
  { id: "fvg" as AdvancedScanType, name: "FVG", icon: Layers, description: "Fair Value Gap bölgeleri" },
  { id: "volume_profile" as AdvancedScanType, name: "Hacim Profili", icon: BarChart3, description: "POC ve Value Area" },
  { id: "patterns" as AdvancedScanType, name: "Formasyonlar", icon: CandlestickChart, description: "Mum formasyonları" },
  { id: "trend" as AdvancedScanType, name: "Trend Gücü", icon: Zap, description: "Trend yönü ve gücü" },
];

export default function Scanner() {
  const [selectedScan, setSelectedScan] = useState<ScanType>("volume_surge");
  const [selectedAdvanced, setSelectedAdvanced] = useState<AdvancedScanType | null>(null);
  const [scanMode, setScanMode] = useState<"basic" | "advanced">("basic");
  const [selectedSymbols, setSelectedSymbols] = useState<string[]>([]);
  const { toast } = useToast();

  const { data: stocks } = useQuery<Array<{ id: number; symbol: string; name: string; currentPrice: number }>>({
    queryKey: ["/api/stocks"],
  });

  const scanMutation = useMutation({
    mutationFn: async (scanType: ScanType): Promise<ScanResponse> => {
      const res = await fetch(`/api/scanner/${scanType}`, { method: "POST" });
      if (!res.ok) throw new Error("Tarama başarısız");
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Tarama Tamamlandı",
        description: `${data.scannedCount} hisse tarandı, ${data.matchCount} sonuç bulundu`,
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Tarama sırasında bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const advancedMutation = useMutation({
    mutationFn: async (symbols: string[]): Promise<AdvancedResult[]> => {
      const res = await fetch("/api/scanner/advanced", { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbols })
      });
      if (!res.ok) throw new Error("Gelişmiş tarama başarısız");
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Gelişmiş Analiz Tamamlandı",
        description: `${data.length} hisse analiz edildi`,
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Gelişmiş analiz sırasında bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const telegramMutation = useMutation({
    mutationFn: async ({ scanType, symbols }: { scanType: string; symbols: string[] }): Promise<{ success: boolean; sentCount: number }> => {
      const res = await fetch("/api/scanner/send-telegram", { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scanType, symbols })
      });
      if (!res.ok) throw new Error("Telegram gönderimi başarısız");
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Telegram'a Gönderildi",
        description: `${data.sentCount} grafik gönderildi`,
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Telegram'a gönderim sırasında bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const bestSignalsMutation = useMutation({
    mutationFn: async (): Promise<SignalResponse> => {
      const res = await fetch("/api/scanner/best-signals", { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 20 })
      });
      if (!res.ok) throw new Error("Sinyal taraması başarısız");
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Sinyal Taraması Tamamlandı",
        description: `${data.scannedCount} hisse tarandı`,
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Sinyal taraması sırasında bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const sendSignalsTelegramMutation = useMutation({
    mutationFn: async (): Promise<{ success: boolean; count: number }> => {
      const res = await fetch("/api/telegram/send-best-signals", { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 10 })
      });
      if (!res.ok) throw new Error("Telegram gönderimi başarısız");
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Telegram'a Gönderildi",
        description: "En iyi sinyaller Telegram'a gönderildi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Telegram'a gönderim sırasında bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const handleScan = () => {
    if (scanMode === "basic") {
      scanMutation.mutate(selectedScan);
    } else {
      const symbolsToScan = selectedSymbols.length > 0 
        ? selectedSymbols 
        : (stocks?.slice(0, 5).map(s => s.symbol) || []);
      advancedMutation.mutate(symbolsToScan);
    }
  };

  const handleSendToTelegram = () => {
    const symbols = scanMode === "basic" 
      ? (scanMutation.data?.results.map(r => r.symbol) || [])
      : (advancedMutation.data?.map(r => r.symbol) || []);
    
    if (symbols.length === 0) {
      toast({
        title: "Hata",
        description: "Önce tarama yapın",
        variant: "destructive",
      });
      return;
    }
    
    telegramMutation.mutate({
      scanType: scanMode === "basic" ? selectedScan : (selectedAdvanced || "advanced"),
      symbols: symbols.slice(0, 5)
    });
  };

  const toggleSymbol = (symbol: string) => {
    setSelectedSymbols(prev => 
      prev.includes(symbol) 
        ? prev.filter(s => s !== symbol)
        : prev.length < 10 ? [...prev, symbol] : prev
    );
  };

  const getRecommendationColor = (rec: string) => {
    if (rec.includes("AL")) return "bg-emerald-600/20 text-emerald-400";
    if (rec.includes("SAT")) return "bg-red-600/20 text-red-400";
    return "bg-gray-600/20 text-gray-400";
  };

  const getTrendIcon = (trend: string) => {
    if (trend === "bullish") return <ArrowUpRight className="w-4 h-4 text-emerald-400" />;
    if (trend === "bearish") return <ArrowDownRight className="w-4 h-4 text-red-400" />;
    return <TrendingUp className="w-4 h-4 text-gray-400" />;
  };

  const filteredResults = advancedMutation.data?.filter(result => {
    if (!selectedAdvanced) return true;
    
    switch (selectedAdvanced) {
      case "support_resistance":
        return result.support_resistance?.support?.length > 0 || result.support_resistance?.resistance?.length > 0;
      case "fibonacci":
        return result.fibonacci?.fib_50 !== undefined;
      case "order_blocks":
        return (result.order_blocks?.bullish_ob?.length > 0) || (result.order_blocks?.bearish_ob?.length > 0);
      case "fvg":
        return (result.fair_value_gaps?.bullish_fvg?.length > 0) || (result.fair_value_gaps?.bearish_fvg?.length > 0);
      case "volume_profile":
        return result.volume_profile?.poc !== null;
      case "patterns":
        return result.candlestick_patterns?.patterns?.length > 0;
      case "trend":
        return result.trend?.strength > 50;
      default:
        return true;
    }
  }) || [];

  return (
    <div className="min-h-screen bg-gray-950 text-white pb-24">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-emerald-900/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-900/10 rounded-full blur-3xl" />
      </div>

      <header className="pt-12 pb-6 px-6 sticky top-0 z-30 bg-gray-950/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Tarayıcı
            </h1>
            <p className="text-sm text-gray-500 font-medium">Teknik Gösterge Taraması</p>
          </div>
          <Search className="w-6 h-6 text-emerald-500" />
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setScanMode("basic")}
            data-testid="button-mode-basic"
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              scanMode === "basic" 
                ? "bg-emerald-600 text-white" 
                : "bg-gray-800 text-gray-400"
            }`}
          >
            Temel Tarama
          </button>
          <button
            onClick={() => setScanMode("advanced")}
            data-testid="button-mode-advanced"
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              scanMode === "advanced" 
                ? "bg-purple-600 text-white" 
                : "bg-gray-800 text-gray-400"
            }`}
          >
            Gelişmiş Analiz
          </button>
        </div>
      </header>

      <main className="px-4 pt-4 space-y-4 relative z-10">
        {/* TradingView Sinyal Section */}
        <div className="p-4 bg-gray-900/70 rounded-xl border border-gray-800/50">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-400" />
              <span className="font-semibold text-white">TradingView Sinyal</span>
            </div>
            {bestSignalsMutation.data && (
              <div className="text-right">
                <span className="text-xs text-emerald-400 font-medium">
                  {bestSignalsMutation.data.scannedCount}/{bestSignalsMutation.data.totalStocks || bestSignalsMutation.data.scannedCount} hisse
                </span>
                {bestSignalsMutation.data.scanTime && (
                  <p className="text-[10px] text-gray-500">
                    {new Date(bestSignalsMutation.data.scanTime).toLocaleString('tr-TR')}
                  </p>
                )}
              </div>
            )}
          </div>
          
          {bestSignalsMutation.data ? (
            <>
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="bg-emerald-900/30 rounded-lg p-3 text-center border border-emerald-800/30">
                  <div className="text-xs text-gray-400 mb-1">Al</div>
                  <div className="text-2xl font-bold text-emerald-400">
                    {bestSignalsMutation.data.results.reduce((sum, r) => sum + r.buySignals, 0)}
                  </div>
                </div>
                <div className="bg-yellow-900/30 rounded-lg p-3 text-center border border-yellow-800/30">
                  <div className="text-xs text-gray-400 mb-1">Nötr</div>
                  <div className="text-2xl font-bold text-yellow-400">
                    {bestSignalsMutation.data.results.reduce((sum, r) => sum + r.neutralSignals, 0)}
                  </div>
                </div>
                <div className="bg-red-900/30 rounded-lg p-3 text-center border border-red-800/30">
                  <div className="text-xs text-gray-400 mb-1">Sat</div>
                  <div className="text-2xl font-bold text-red-400">
                    {bestSignalsMutation.data.results.reduce((sum, r) => sum + r.sellSignals, 0)}
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {bestSignalsMutation.data.results.slice(0, 10).map((result, idx) => (
                  <div 
                    key={result.symbol} 
                    data-testid={`signal-result-${result.symbol}`}
                    className="flex items-center justify-between p-2 bg-gray-800/50 rounded-lg"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500 w-4">{idx + 1}</span>
                      <span className="font-medium text-white">{result.symbol}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-emerald-400">Al:{result.buySignals}</span>
                      <span className="text-xs text-yellow-400">N:{result.neutralSignals}</span>
                      <span className="text-xs text-red-400">S:{result.sellSignals}</span>
                      <span className="font-mono text-sm text-gray-300">₺{result.price.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="text-sm text-gray-500 text-center py-4">
              En iyi al sinyallerini görmek için tarayın
            </p>
          )}
          
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => bestSignalsMutation.mutate()}
              disabled={bestSignalsMutation.isPending}
              data-testid="button-scan-signals"
              className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg text-sm font-medium text-white flex items-center justify-center gap-2"
            >
              {bestSignalsMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4" />
              )}
              En İyi Al Sinyalleri
            </button>
            <button
              onClick={() => sendSignalsTelegramMutation.mutate()}
              disabled={sendSignalsTelegramMutation.isPending || !bestSignalsMutation.data}
              data-testid="button-send-signals-telegram"
              className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 rounded-lg text-white flex items-center gap-2"
            >
              {sendSignalsTelegramMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <SiTelegram className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        {scanMode === "basic" ? (
          <>
            <div className="grid grid-cols-2 gap-3">
              {SCAN_TYPES.map((scan) => {
                const Icon = scan.icon;
                const isSelected = selectedScan === scan.id;
                return (
                  <motion.button
                    key={scan.id}
                    onClick={() => setSelectedScan(scan.id)}
                    whileTap={{ scale: 0.98 }}
                    data-testid={`button-scan-${scan.id}`}
                    className={`p-4 rounded-xl border transition-all text-left ${
                      isSelected
                        ? "bg-emerald-600/20 border-emerald-500/50 ring-1 ring-emerald-500/30"
                        : "bg-gray-900/50 border-gray-800/50 hover:border-gray-700"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className={`w-5 h-5 ${isSelected ? "text-emerald-400" : "text-gray-400"}`} />
                      <span className={`font-semibold ${isSelected ? "text-emerald-400" : "text-white"}`}>
                        {scan.name}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500">{scan.description}</p>
                  </motion.button>
                );
              })}
            </div>
          </>
        ) : (
          <>
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-gray-400">Analiz Türü</h3>
              <div className="flex flex-wrap gap-2">
                {ADVANCED_SCAN_TYPES.map((scan) => {
                  const Icon = scan.icon;
                  const isSelected = selectedAdvanced === scan.id;
                  return (
                    <button
                      key={scan.id}
                      onClick={() => setSelectedAdvanced(isSelected ? null : scan.id)}
                      data-testid={`button-advanced-${scan.id}`}
                      className={`px-3 py-2 rounded-lg border text-sm flex items-center gap-2 transition-all ${
                        isSelected
                          ? "bg-purple-600/20 border-purple-500/50 text-purple-400"
                          : "bg-gray-900/50 border-gray-800/50 text-gray-400"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {scan.name}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-gray-400">Hisse Seç (maks. 10)</h3>
                <span className="text-xs text-gray-500">{selectedSymbols.length}/10 seçili</span>
              </div>
              <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                {stocks?.slice(0, 30).map((stock) => {
                  const isSelected = selectedSymbols.includes(stock.symbol);
                  return (
                    <button
                      key={stock.id}
                      onClick={() => toggleSymbol(stock.symbol)}
                      data-testid={`button-symbol-${stock.symbol}`}
                      className={`px-2 py-1 rounded text-xs transition-all ${
                        isSelected
                          ? "bg-purple-600 text-white"
                          : "bg-gray-800 text-gray-400 hover:text-white"
                      }`}
                    >
                      {stock.symbol}
                    </button>
                  );
                })}
              </div>
              {selectedSymbols.length === 0 && (
                <p className="text-xs text-gray-500">Seçim yapılmazsa ilk 5 hisse analiz edilir</p>
              )}
            </div>
          </>
        )}

        <div className="flex gap-2">
          <button
            onClick={handleScan}
            disabled={scanMutation.isPending || advancedMutation.isPending}
            data-testid="button-start-scan"
            className={`flex-1 py-4 disabled:opacity-50 rounded-xl font-bold text-white flex items-center justify-center gap-2 transition-all ${
              scanMode === "basic" 
                ? "bg-emerald-600 hover:bg-emerald-500" 
                : "bg-purple-600 hover:bg-purple-500"
            }`}
          >
            {(scanMutation.isPending || advancedMutation.isPending) ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{scanMode === "basic" ? "Taranıyor..." : "Analiz..."}</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-5 h-5" />
                <span>{scanMode === "basic" ? "Tara" : "Analiz"}</span>
              </>
            )}
          </button>
          
          <button
            onClick={handleSendToTelegram}
            disabled={telegramMutation.isPending || (!scanMutation.data && !advancedMutation.data)}
            data-testid="button-send-telegram"
            className="px-6 py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl font-bold text-white flex items-center justify-center gap-2 transition-all"
          >
            {telegramMutation.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <SiTelegram className="w-5 h-5" />
                <span>Gönder</span>
              </>
            )}
          </button>
        </div>

        {scanMode === "basic" && scanMutation.data && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-lg font-semibold text-white">
                Sonuçlar ({scanMutation.data.matchCount})
              </h2>
              <div className="text-right">
                <span className="text-xs text-emerald-400">
                  {scanMutation.data.scannedCount}/{scanMutation.data.totalStocks || scanMutation.data.scannedCount} hisse
                </span>
                {scanMutation.data.scanTime && (
                  <p className="text-[10px] text-gray-500">
                    {new Date(scanMutation.data.scanTime).toLocaleString('tr-TR')}
                  </p>
                )}
              </div>
            </div>

            {scanMutation.data.results.length === 0 ? (
              <div className="p-8 text-center bg-gray-900/50 rounded-xl border border-gray-800/50">
                <XCircle className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-400">Bu kriterlere uyan hisse bulunamadı</p>
              </div>
            ) : (
              <div className="space-y-2">
                {scanMutation.data.results.map((result) => (
                  <motion.div
                    key={result.stockId}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    data-testid={`card-scan-result-${result.symbol}`}
                    className="p-4 bg-gray-900/50 rounded-xl border border-gray-800/50"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="font-bold text-white">{result.symbol}</span>
                        <span className="text-xs text-gray-500 ml-2">{result.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-emerald-400 font-mono">
                          ₺{result.currentPrice.toFixed(2)}
                        </span>
                        <span className={`px-2 py-1 rounded text-xs font-bold ${
                          result.signal === "AL" ? "bg-emerald-600/20 text-emerald-400" :
                          result.signal === "SAT" ? "bg-red-600/20 text-red-400" :
                          "bg-gray-600/20 text-gray-400"
                        }`}>
                          {result.signal}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {result.reasons.map((reason, i) => (
                        <span key={i} className="px-2 py-0.5 bg-gray-800 rounded text-xs text-gray-400">
                          {reason}
                        </span>
                      ))}
                    </div>
                    {(result.rsi !== undefined || result.volumeChange !== undefined) && (
                      <div className="flex gap-4 mt-2 text-xs text-gray-500">
                        {result.rsi !== undefined && <span>RSI: {result.rsi.toFixed(1)}</span>}
                        {result.volumeChange !== undefined && (
                          <span>Hacim Değişim: %{result.volumeChange.toFixed(0)}</span>
                        )}
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}

        {scanMode === "advanced" && advancedMutation.data && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-lg font-semibold text-white">
                Gelişmiş Analiz Sonuçları ({filteredResults.length})
              </h2>
            </div>

            {filteredResults.length === 0 ? (
              <div className="p-8 text-center bg-gray-900/50 rounded-xl border border-gray-800/50">
                <XCircle className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-400">Sonuç bulunamadı</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredResults.map((result) => (
                  <motion.div
                    key={result.symbol}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    data-testid={`card-advanced-${result.symbol}`}
                    className="p-4 bg-gray-900/50 rounded-xl border border-gray-800/50 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getTrendIcon(result.trend?.trend || "neutral")}
                        <span className="font-bold text-white">{result.symbol}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-emerald-400 font-mono">
                          ₺{(result.current_price || result.currentPrice || 0).toFixed(2)}
                        </span>
                        <span className={`px-2 py-1 rounded text-xs font-bold ${getRecommendationColor(result.signal?.recommendation || "NÖTR")}`}>
                          {result.signal?.recommendation || "NÖTR"}
                        </span>
                      </div>
                    </div>

                    {result.trend && (
                      <div className="flex items-center gap-4 text-xs">
                        <span className="text-gray-500">
                          Trend: <span className={result.trend.trend === "bullish" ? "text-emerald-400" : result.trend.trend === "bearish" ? "text-red-400" : "text-gray-400"}>
                            {result.trend.trend === "bullish" ? "Yükselen" : result.trend.trend === "bearish" ? "Düşen" : "Yatay"}
                          </span>
                        </span>
                        <span className="text-gray-500">
                          Güç: <span className="text-white">{result.trend.strength?.toFixed(0)}%</span>
                        </span>
                      </div>
                    )}

                    {result.support_resistance && (result.support_resistance.support?.length > 0 || result.support_resistance.resistance?.length > 0) && (
                      <div className="space-y-1">
                        {result.support_resistance.resistance?.length > 0 && (
                          <div className="flex items-center gap-2 text-xs">
                            <span className="text-red-400 w-16">Direnç:</span>
                            <div className="flex gap-1">
                              {result.support_resistance.resistance.slice(0, 3).map((r, i) => (
                                <span key={i} className="px-2 py-0.5 bg-red-900/30 rounded text-red-300 font-mono">
                                  ₺{r.toFixed(2)}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        {result.support_resistance.support?.length > 0 && (
                          <div className="flex items-center gap-2 text-xs">
                            <span className="text-emerald-400 w-16">Destek:</span>
                            <div className="flex gap-1">
                              {result.support_resistance.support.slice(0, 3).map((s, i) => (
                                <span key={i} className="px-2 py-0.5 bg-emerald-900/30 rounded text-emerald-300 font-mono">
                                  ₺{s.toFixed(2)}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {result.fibonacci && result.fibonacci.fib_50 && (
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-amber-400">Fibonacci:</span>
                        <span className="px-2 py-0.5 bg-amber-900/30 rounded text-amber-300 font-mono">
                          %50: ₺{result.fibonacci.fib_50.toFixed(2)}
                        </span>
                        {result.fibonacci.fib_61 && (
                          <span className="px-2 py-0.5 bg-amber-900/30 rounded text-amber-300 font-mono">
                            %61.8: ₺{result.fibonacci.fib_61.toFixed(2)}
                          </span>
                        )}
                      </div>
                    )}

                    {result.order_blocks && (result.order_blocks.bullish_ob?.length > 0 || result.order_blocks.bearish_ob?.length > 0) && (
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-purple-400">Order Blocks:</span>
                        {result.order_blocks.bullish_ob?.length > 0 && (
                          <span className="px-2 py-0.5 bg-emerald-900/30 rounded text-emerald-300">
                            {result.order_blocks.bullish_ob.length} Boğa OB
                          </span>
                        )}
                        {result.order_blocks.bearish_ob?.length > 0 && (
                          <span className="px-2 py-0.5 bg-red-900/30 rounded text-red-300">
                            {result.order_blocks.bearish_ob.length} Ayı OB
                          </span>
                        )}
                      </div>
                    )}

                    {result.fair_value_gaps && (result.fair_value_gaps.bullish_fvg?.length > 0 || result.fair_value_gaps.bearish_fvg?.length > 0) && (
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-cyan-400">FVG:</span>
                        {result.fair_value_gaps.bullish_fvg?.length > 0 && (
                          <span className="px-2 py-0.5 bg-cyan-900/30 rounded text-cyan-300">
                            {result.fair_value_gaps.bullish_fvg.length} Boğa FVG
                          </span>
                        )}
                        {result.fair_value_gaps.bearish_fvg?.length > 0 && (
                          <span className="px-2 py-0.5 bg-orange-900/30 rounded text-orange-300">
                            {result.fair_value_gaps.bearish_fvg.length} Ayı FVG
                          </span>
                        )}
                      </div>
                    )}

                    {result.volume_profile?.poc && (
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-pink-400">Hacim Profili:</span>
                        <span className="px-2 py-0.5 bg-pink-900/30 rounded text-pink-300 font-mono">
                          POC: ₺{result.volume_profile.poc.toFixed(2)}
                        </span>
                        {result.volume_profile.value_area_low && result.volume_profile.value_area_high && (
                          <span className="px-2 py-0.5 bg-gray-800 rounded text-gray-400 font-mono">
                            VA: ₺{result.volume_profile.value_area_low.toFixed(2)} - ₺{result.volume_profile.value_area_high.toFixed(2)}
                          </span>
                        )}
                      </div>
                    )}

                    {result.candlestick_patterns?.patterns?.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {result.candlestick_patterns.patterns.slice(-3).map((p, i) => (
                          <span 
                            key={i} 
                            className={`px-2 py-0.5 rounded text-xs ${
                              p.type === "bullish" ? "bg-emerald-900/30 text-emerald-300" :
                              p.type === "bearish" ? "bg-red-900/30 text-red-300" :
                              "bg-gray-800 text-gray-400"
                            }`}
                          >
                            {p.name_tr}
                          </span>
                        ))}
                      </div>
                    )}

                    {result.signal?.signals?.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-2 border-t border-gray-800">
                        {result.signal.signals.slice(0, 4).map((sig, i) => (
                          <span key={i} className="px-2 py-0.5 bg-gray-800 rounded text-xs text-gray-400">
                            {sig}
                          </span>
                        ))}
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
