import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Loader2, RefreshCw, CheckCircle } from "lucide-react";
import { useStocks, useBatchRefreshStocks } from "@/hooks/use-stocks";
import { StockCard } from "@/components/StockCard";
import { BottomNav } from "@/components/BottomNav";
import { AddStockDialog } from "@/components/AddStockDialog";
import { StockDetailOverlay } from "@/components/StockDetailOverlay";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { data: stocks, isLoading, isError } = useStocks();
  const batchRefresh = useBatchRefreshStocks();
  const { toast } = useToast();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedStockId, setSelectedStockId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const handleBatchRefresh = () => {
    batchRefresh.mutate(undefined, {
      onSuccess: (result) => {
        toast({
          title: "Fiyatlar Güncellendi",
          description: `${result.updated}/${result.total} hisse başarıyla güncellendi`,
        });
      },
      onError: () => {
        toast({
          title: "Hata",
          description: "Fiyatlar güncellenirken bir hata oluştu",
          variant: "destructive",
        });
      },
    });
  };

  const filteredStocks = stocks?.filter(stock => 
    stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) || 
    stock.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen pb-24 relative overflow-hidden">
      {/* Background ambient glow */}
      <div className="fixed -top-40 -right-40 w-96 h-96 bg-emerald-900/10 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed -bottom-40 -left-40 w-96 h-96 bg-blue-900/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <header className="pt-12 pb-6 px-6 sticky top-0 z-30 bg-gray-950/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Hisse<span className="text-emerald-500">Avcısı</span>
            </h1>
            <p className="text-sm text-gray-500 font-medium">Piyasa Görünümü</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleBatchRefresh}
              disabled={batchRefresh.isPending}
              data-testid="button-batch-refresh"
              className="flex items-center gap-2 px-3 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 rounded-lg text-emerald-400 text-sm font-medium transition-all disabled:opacity-50"
            >
              {batchRefresh.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Güncelleniyor...</span>
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4" />
                  <span>Güncelle</span>
                </>
              )}
            </button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-blue-500 border-2 border-gray-900 shadow-lg" />
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <input
            type="text"
            placeholder="Hisse ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
          />
          <Search className="w-4 h-4 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        </div>
      </header>

      {/* Content */}
      <main className="px-4 py-4 space-y-4">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-4">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
            <p className="text-gray-500 text-sm animate-pulse">Piyasa verileri yükleniyor...</p>
          </div>
        ) : isError ? (
          <div className="text-center py-20 px-6">
            <div className="bg-red-500/10 text-red-400 p-4 rounded-xl border border-red-500/20 mb-4">
              Hisseler yüklenemedi. Lütfen tekrar deneyin.
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-gray-800 rounded-lg text-white text-sm font-medium"
            >
              Tekrar Dene
            </button>
          </div>
        ) : filteredStocks?.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
            <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mb-2">
              <Search className="w-8 h-8 text-gray-600" />
            </div>
            <h3 className="text-lg font-medium text-white">Hisse bulunamadı</h3>
            <p className="text-gray-500 text-sm max-w-[200px]">
              {searchQuery ? "Farklı bir arama terimi deneyin" : "Hisse takip etmeye başlamak için + butonuna tıklayın"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <AnimatePresence mode="popLayout">
              {filteredStocks?.map((stock) => (
                <StockCard 
                  key={stock.id} 
                  stock={stock} 
                  onClick={() => setSelectedStockId(stock.id)} 
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </main>

      <BottomNav onAddClick={() => setIsAddOpen(true)} />
      
      <AddStockDialog 
        isOpen={isAddOpen} 
        onClose={() => setIsAddOpen(false)} 
      />

      <StockDetailOverlay
        stockId={selectedStockId}
        onClose={() => setSelectedStockId(null)}
      />
    </div>
  );
}
