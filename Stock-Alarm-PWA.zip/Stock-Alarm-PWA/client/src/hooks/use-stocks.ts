import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { 
  type Stock, 
  type StockWithDetails, 
  type CreateStockRequest, 
  type InsertTarget,
  type InsertStockNote,
  type Target,
  type StockNote
} from "@shared/schema";

// === STOCKS ===

export function useStocks() {
  return useQuery({
    queryKey: [api.stocks.list.path],
    queryFn: async () => {
      const res = await fetch(api.stocks.list.path);
      if (!res.ok) throw new Error("Failed to fetch stocks");
      return api.stocks.list.responses[200].parse(await res.json());
    },
  });
}

export function useStock(id: number) {
  return useQuery({
    queryKey: [api.stocks.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.stocks.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch stock details");
      return api.stocks.get.responses[200].parse(await res.json());
    },
    enabled: !isNaN(id),
  });
}

export function useCreateStock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateStockRequest) => {
      const res = await fetch(api.stocks.create.path, {
        method: api.stocks.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Invalid stock data");
        }
        throw new Error("Failed to create stock");
      }
      return api.stocks.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.stocks.list.path] });
    },
  });
}

export function useDeleteStock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.stocks.delete.path, { id });
      const res = await fetch(url, { method: api.stocks.delete.method });
      if (!res.ok) throw new Error("Failed to delete stock");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.stocks.list.path] });
    },
  });
}

export function useRefreshStock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.stocks.refresh.path, { id });
      const res = await fetch(url, { method: api.stocks.refresh.method });
      if (!res.ok) throw new Error("Failed to refresh stock price");
      return api.stocks.refresh.responses[200].parse(await res.json());
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: [api.stocks.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.stocks.get.path, id] });
    },
  });
}

export interface BatchRefreshResult {
  total: number;
  updated: number;
  failed: number;
  results: { symbol: string; price: number; error?: string }[];
}

export function useBatchRefreshStocks() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (): Promise<BatchRefreshResult> => {
      const res = await fetch("/api/stocks/batch-refresh", { method: "POST" });
      if (!res.ok) throw new Error("Failed to batch refresh stocks");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.stocks.list.path] });
    },
  });
}

// === TARGETS ===

export function useCreateTarget() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ stockId, data }: { stockId: number; data: Omit<InsertTarget, "stockId"> }) => {
      const url = buildUrl(api.targets.create.path, { stockId });
      const res = await fetch(url, {
        method: api.targets.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create target");
      return api.targets.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, { stockId }) => {
      queryClient.invalidateQueries({ queryKey: [api.stocks.get.path, stockId] });
      queryClient.invalidateQueries({ queryKey: [api.stocks.list.path] });
    },
  });
}

export function useDeleteTarget() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, stockId }: { id: number; stockId: number }) => {
      const url = buildUrl(api.targets.delete.path, { id });
      const res = await fetch(url, { method: api.targets.delete.method });
      if (!res.ok) throw new Error("Failed to delete target");
    },
    onSuccess: (_, { stockId }) => {
      queryClient.invalidateQueries({ queryKey: [api.stocks.get.path, stockId] });
    },
  });
}

// === NOTES ===

export function useCreateNote() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ stockId, data }: { stockId: number; data: Omit<InsertStockNote, "stockId"> }) => {
      const url = buildUrl(api.notes.create.path, { stockId });
      const res = await fetch(url, {
        method: api.notes.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create note");
      return api.notes.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, { stockId }) => {
      queryClient.invalidateQueries({ queryKey: [api.stocks.get.path, stockId] });
    },
  });
}

export function useAnalyzeNotes() {
  return useMutation({
    mutationFn: async (stockId: number) => {
      const url = buildUrl(api.notes.analyze.path, { stockId });
      const res = await fetch(url, { method: api.notes.analyze.method });
      if (!res.ok) throw new Error("Failed to analyze notes");
      return api.notes.analyze.responses[200].parse(await res.json());
    },
  });
}

// === CANDLE DATA ===

export interface CandleData {
  candle: {
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  };
  indicators: {
    sma20: number | null;
    sma50: number | null;
    sma200: number | null;
    ema20: number | null;
    rsi: number | null;
    macd: number | null;
    macd_signal: number | null;
    bb_upper: number | null;
    bb_lower: number | null;
    bb_middle: number | null;
    atr: number | null;
    adx: number | null;
    cci: number | null;
    stoch_k: number | null;
    stoch_d: number | null;
    recommendation: string;
    buy_signals: number;
    sell_signals: number;
    neutral_signals: number;
  };
}

export function useStockCandles(stockId: number | null) {
  return useQuery({
    queryKey: ["/api/stocks", stockId, "candles"],
    queryFn: async (): Promise<CandleData> => {
      const res = await fetch(`/api/stocks/${stockId}/candles`);
      if (!res.ok) throw new Error("Failed to fetch candle data");
      return res.json();
    },
    enabled: !!stockId,
    staleTime: 60000, // 1 minute cache
  });
}
