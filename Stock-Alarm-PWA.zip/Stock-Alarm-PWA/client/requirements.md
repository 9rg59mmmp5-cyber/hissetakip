## Packages
framer-motion | Complex page transitions and overlay animations
recharts | Sparklines and price charts
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'Inter'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
Mobile-first design approach is critical.
Dark mode is forced (bg-gray-950).
